from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import logging
import httpx
import json
import random
from datetime import datetime

# Configure logging
logger = logging.getLogger("sudarsansarthi.llm_assistant")

# Router for LLM endpoints
router = APIRouter()

# --- Pydantic Models ---

class HealthAssessmentRequest(BaseModel):
    symptoms: List[str] = Field(..., description="List of user symptoms")
    location: str = Field(..., description="User's location")
    temperature: float = Field(..., description="Current temperature")
    mobility_level: str = Field(..., description="Mobility level: low/medium/high")
    mental_state: Optional[str] = Field(None, description="User's mental state")

class HealthAssessmentResponse(BaseModel):
    summary: str = Field(..., description="Risk assessment summary")
    risk_level: str = Field(..., description="Risk level: Low/Moderate/High")
    suggested_actions: List[str] = Field(..., description="List of suggested actions")

# --- Mock LLM Implementation ---

class MockLLM:
    """Mock LLM class that generates plausible health assessments"""
    
    def __init__(self):
        self.risk_keywords = {
            "fever": ["high", "moderate"],
            "cough": ["moderate", "low"],
            "headache": ["low", "moderate"],
            "fatigue": ["low"],
            "shortness_of_breath": ["high"],
            "chest_pain": ["high"],
            "nausea": ["moderate"],
            "dizziness": ["moderate"]
        }
        
        self.action_templates = {
            "high": [
                "Seek immediate medical attention",
                "Monitor symptoms closely",
                "Avoid contact with others",
                "Stay hydrated and rest"
            ],
            "moderate": [
                "Monitor your symptoms",
                "Get adequate rest",
                "Stay hydrated",
                "Consider consulting a healthcare provider"
            ],
            "low": [
                "Continue monitoring symptoms",
                "Maintain good hygiene",
                "Get proper rest",
                "Stay hydrated"
            ]
        }
    
    async def generate_assessment(self, request: HealthAssessmentRequest) -> HealthAssessmentResponse:
        """Generate a mock health assessment"""
        
        # Analyze symptoms for risk level
        risk_scores = []
        for symptom in request.symptoms:
            symptom_lower = symptom.lower().replace(" ", "_")
            if symptom_lower in self.risk_keywords:
                risk_scores.extend(self.risk_keywords[symptom_lower])
        
        # Determine overall risk level
        if not risk_scores:
            risk_level = "low"
        elif "high" in risk_scores or request.temperature > 38.5:
            risk_level = "high"
        elif "moderate" in risk_scores or request.temperature > 37.5:
            risk_level = "moderate"
        else:
            risk_level = "low"
        
        # Generate summary
        symptom_count = len(request.symptoms)
        summary = f"Based on your {symptom_count} symptom(s) and current conditions in {request.location}, "
        
        if risk_level == "high":
            summary += "I'm concerned about your health status. "
        elif risk_level == "moderate":
            summary += "I recommend monitoring your condition carefully. "
        else:
            summary += "Your symptoms appear manageable at this time. "
        
        if request.temperature > 37.5:
            summary += f"Your elevated temperature of {request.temperature}°C requires attention. "
        
        # Get suggested actions
        suggested_actions = self.action_templates[risk_level].copy()
        
        # Add location-specific advice
        if "high" in request.mobility_level.lower():
            suggested_actions.append("Consider reducing mobility to minimize exposure")
        
        if request.mental_state and "stress" in request.mental_state.lower():
            suggested_actions.append("Practice stress-reduction techniques")
        
        return HealthAssessmentResponse(
            summary=summary,
            risk_level=risk_level.capitalize(),
            suggested_actions=suggested_actions
        )

# --- Real OpenAI LLM Implementation ---

class OpenAILLM:
    """Real OpenAI LLM implementation"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.openai.com/v1"
    
    async def generate_assessment(self, request: HealthAssessmentRequest) -> HealthAssessmentResponse:
        """Generate health assessment using OpenAI GPT-4"""
        
        prompt = f"""
        You are a professional health assistant. Analyze the following health data and provide a risk assessment:
        
        Symptoms: {', '.join(request.symptoms)}
        Location: {request.location}
        Temperature: {request.temperature}°C
        Mobility Level: {request.mobility_level}
        Mental State: {request.mental_state or 'Not specified'}
        
        Provide a response in the following JSON format:
        {{
            "summary": "Brief risk assessment summary",
            "risk_level": "Low/Moderate/High",
            "suggested_actions": ["action1", "action2", "action3"]
        }}
        
        Focus on:
        1. Symptom severity and combination
        2. Temperature implications
        3. Location-specific health risks
        4. Mobility and mental health considerations
        5. Practical preventive steps
        """
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": "gpt-4",
                        "messages": [
                            {"role": "system", "content": "You are a professional health assistant."},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.3,
                        "max_tokens": 500
                    },
                    timeout=30.0
                )
                
                if response.status_code == 200:
                    result = response.json()
                    content = result["choices"][0]["message"]["content"]
                    
                    # Parse JSON response
                    try:
                        assessment_data = json.loads(content)
                        return HealthAssessmentResponse(**assessment_data)
                    except json.JSONDecodeError:
                        # Fallback to mock if JSON parsing fails
                        logger.warning("Failed to parse OpenAI response, using mock fallback")
                        mock_llm = MockLLM()
                        return await mock_llm.generate_assessment(request)
                
                else:
                    logger.error(f"OpenAI API error: {response.status_code}")
                    raise HTTPException(status_code=500, detail="LLM service unavailable")
                    
        except Exception as e:
            logger.error(f"OpenAI API exception: {str(e)}")
            # Fallback to mock implementation
            mock_llm = MockLLM()
            return await mock_llm.generate_assessment(request)

# --- LLM Factory ---

def get_llm_instance(use_openai: bool = False, api_key: Optional[str] = None):
    """Factory function to get LLM instance"""
    if use_openai and api_key:
        return OpenAILLM(api_key)
    else:
        return MockLLM()

# --- FastAPI Endpoint ---

@router.post("/llm-risk-assistant", 
             response_model=HealthAssessmentResponse,
             tags=["LLM Assistant"],
             summary="Health Risk Assessment Chatbot",
             description="AI-powered health assistant that analyzes symptoms and provides risk assessment")
async def llm_risk_assistant(
    request: HealthAssessmentRequest = Body(...),
    use_openai: bool = False,
    api_key: Optional[str] = None
):
    """
    LLM-integrated chatbot endpoint for health risk assessment.
    
    - **symptoms**: List of user symptoms
    - **location**: User's location
    - **temperature**: Current temperature
    - **mobility_level**: Mobility level (low/medium/high)
    - **mental_state**: Optional mental state
    - **use_openai**: Whether to use real OpenAI API (default: False)
    - **api_key**: OpenAI API key (required if use_openai=True)
    """
    
    # Log incoming request
    logger.info(f"Health assessment request received: {request.dict()}")
    
    try:
        # Get LLM instance
        llm = get_llm_instance(use_openai, api_key)
        
        # Generate assessment
        assessment = await llm.generate_assessment(request)
        
        # Log response
        logger.info(f"Assessment generated: {assessment.dict()}")
        
        return assessment
        
    except Exception as e:
        logger.error(f"Error in health assessment: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Assessment failed: {str(e)}")

# --- Health Check Endpoint ---

@router.get("/llm-health", tags=["LLM Assistant"])
async def llm_health_check():
    """Health check for LLM assistant service"""
    return {
        "status": "healthy",
        "service": "LLM Health Assistant",
        "timestamp": datetime.now().isoformat(),
        "available_models": ["mock", "openai-gpt4"]
    }

# Example usage:
# To use this module in your main FastAPI app:
# from llm_assistant import router as llm_router
# app.include_router(llm_router, prefix="/api") 