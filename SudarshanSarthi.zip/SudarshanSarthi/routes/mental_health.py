from fastapi import APIRouter, Body
from services.mental_health_service import analyze_mental_health
from pydantic import BaseModel

class MentalHealthRequest(BaseModel):
    text: str
    user_id: str

router = APIRouter()

@router.post("/", summary="Analyze text tone and estimate mental state", response_model=dict)
def analyze_mental_health_endpoint(request: MentalHealthRequest = Body(...)):
    """Detect tone of text and estimate mental health state."""
    return analyze_mental_health(request.text, request.user_id) 