from fastapi import APIRouter, Query
from services.cat_service import get_cat_images
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get cat images for mood improvement", response_model=dict)
def get_cat_mood(
    mood: Optional[str] = Query("happy", description="Mood type (happy, sad, stressed)"),
    count: Optional[int] = Query(3, description="Number of cat images to return")
):
    """Returns cat image links from Cat API for mood improvement."""
    return get_cat_images(mood, count) 