from fastapi import APIRouter, Query
from services.disease_service import predict_disease
from typing import Optional, List

router = APIRouter()

@router.get("/", summary="Predict disease based on location and context", response_model=dict)
def predict_disease_endpoint(
    lat: float = Query(..., description="Latitude of the location"),
    lon: float = Query(..., description="Longitude of the location"),
    symptoms: Optional[str] = Query(None, description="Comma-separated symptoms"),
    age: Optional[int] = Query(None, description="Age of the person"),
    context: Optional[str] = Query(None, description="Additional context or notes"),
):
    """
    Returns disease prediction based on location, symptoms, and context.
    """
    return predict_disease(lat=lat, lon=lon, symptoms=symptoms, age=age, context=context) 