from fastapi import APIRouter, Query
from services.weather_service import get_weather_disease_risk
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get disease risk based on weather and pollution", response_model=dict)
def weather_risk(
    lat: float = Query(..., description="Latitude of the location"),
    lon: float = Query(..., description="Longitude of the location"),
    city: Optional[str] = Query(None, description="City name (optional)"),
):
    """
    Returns disease risk estimation based on current weather and pollution data for a given location.
    """
    return get_weather_disease_risk(lat=lat, lon=lon, city=city) 