from fastapi import APIRouter, Body
from services.fake_news_service import classify_news
from pydantic import BaseModel
from typing import Optional

class NewsRequest(BaseModel):
    title: str
    content: str
    source: Optional[str] = None

router = APIRouter()

@router.post("/", summary="Classify if health news is fake", response_model=dict)
def fake_news_detection(request: NewsRequest = Body(...)):
    """POST endpoint to classify if health news is fake or misleading."""
    return classify_news(request.title, request.content, request.source) 