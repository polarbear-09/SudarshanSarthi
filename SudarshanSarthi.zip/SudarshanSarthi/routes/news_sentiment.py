from fastapi import APIRouter, Query
from services.news_service import analyze_news_sentiment
from typing import Optional

router = APIRouter()

@router.get("/", summary="Analyze health news sentiment", response_model=dict)
def news_sentiment(
    topic: Optional[str] = Query("health", description="Topic to analyze (default: health)"),
    region: Optional[str] = Query(None, description="Region/country code (optional)"),
):
    """
    Returns sentiment analysis and summary of recent health news for a given topic/region.
    """
    return analyze_news_sentiment(topic=topic, region=region) 