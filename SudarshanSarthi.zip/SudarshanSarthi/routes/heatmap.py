from fastapi import APIRouter, Query
from services.heatmap_service import get_heatmap_data
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get area-level outbreak risk for map visualization", response_model=dict)
def get_heatmap(
    lat: float = Query(..., description="Center latitude"),
    lon: float = Query(..., description="Center longitude"),
    zoom: Optional[int] = Query(10, description="Map zoom level")
):
    """Fetches area-level outbreak risk data for heatmap visualization."""
    return get_heatmap_data(lat, lon, zoom) 