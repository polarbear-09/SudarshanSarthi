from fastapi import APIRouter, Body
from services.translate_service import translate_text
from pydantic import BaseModel
from typing import Optional

class TranslateRequest(BaseModel):
    text: str
    target_language: str
    source_language: Optional[str] = "auto"

router = APIRouter()

@router.post("/", summary="Translate text to user's language", response_model=dict)
def translate_endpoint(request: TranslateRequest = Body(...)):
    """Translate given text to user's preferred language."""
    return translate_text(request.text, request.target_language, request.source_language) 