from fastapi import APIRouter, Query
from services.calendar_service import get_preventive_calendar
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get weekly preventive calendar", response_model=dict)
def get_preventive_calendar_endpoint(
    week_start: Optional[str] = Query(None, description="Week start date (YYYY-MM-DD)")
):
    """Returns weekly calendar with prevention tips and health reminders."""
    return get_preventive_calendar(week_start) 