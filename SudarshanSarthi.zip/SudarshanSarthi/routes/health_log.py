from fastapi import APIRouter, Body, Query
from services.health_log_service import get_health_log, create_health_log
from typing import Optional
from pydantic import BaseModel

class HealthLogEntry(BaseModel):
    user_id: str
    symptoms: list
    temperature: Optional[float] = None
    notes: Optional[str] = None

router = APIRouter()

@router.get("/", summary="Get health log entries", response_model=dict)
def get_health_log_endpoint(
    user_id: str = Query(..., description="User ID"),
    days: Optional[int] = Query(7, description="Number of days to retrieve")
):
    """Get health log entries for a user."""
    return get_health_log(user_id, days)

@router.post("/", summary="Create health log entry", response_model=dict)
def create_health_log_endpoint(entry: HealthLogEntry = Body(...)):
    """Create a new health log entry."""
    return create_health_log(entry) 