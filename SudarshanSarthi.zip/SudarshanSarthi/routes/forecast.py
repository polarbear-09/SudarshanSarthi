from fastapi import APIRouter, Query
from services.forecast_service import get_outbreak_forecast
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get outbreak forecast timeline", response_model=dict)
def get_forecast(
    location: str = Query(..., description="Location name or coordinates"),
    days: Optional[int] = Query(30, description="Forecast period in days")
):
    """Returns outbreak forecast in JSON timeline format."""
    return get_outbreak_forecast(location, days) 