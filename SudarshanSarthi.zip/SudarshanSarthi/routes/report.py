from fastapi import APIRouter, Body
from services.report_service import create_report
from typing import List, Optional
from pydantic import BaseModel

class ReportRequest(BaseModel):
    user_id: str
    symptoms: List[str]
    location: str
    severity: str = "medium"
    notes: Optional[str] = None
    contact_info: Optional[str] = None

router = APIRouter()

@router.post("/", summary="Report symptoms or health events", response_model=dict)
def report_symptoms(report: ReportRequest = Body(...)):
    """
    POST endpoint for users to report symptoms or health events.
    """
    return create_report(report) 