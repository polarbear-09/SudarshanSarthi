from fastapi import APIRouter, Query
from services.notification_service import get_local_alerts
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get local risk alerts and notifications", response_model=dict)
def get_notifications(
    lat: float = Query(..., description="Latitude"),
    lon: float = Query(..., description="Longitude"),
    radius_km: Optional[float] = Query(10.0, description="Alert radius in kilometers")
):
    """Fetch local risk alerts and notifications for the user's area."""
    return get_local_alerts(lat, lon, radius_km) 