from fastapi import APIRouter, Body
from services.speech_service import convert_speech_to_text
from pydantic import BaseModel

class SpeechRequest(BaseModel):
    audio_data: str  # Base64 encoded audio
    language: str = "en"

router = APIRouter()

@router.post("/", summary="Convert speech to text", response_model=dict)
def speech_to_text(request: SpeechRequest = Body(...)):
    """Convert audio speech to text using speech recognition."""
    return convert_speech_to_text(request.audio_data, request.language) 