from fastapi import APIRouter, Query
from services.story_service import get_story_mode_data
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get guided character-based walkthrough data", response_model=dict)
def get_story_mode(
    user_id: str = Query(..., description="User ID"),
    chapter: Optional[int] = Query(1, description="Story chapter number")
):
    """Returns guided character-based walkthrough data for new users."""
    return get_story_mode_data(user_id, chapter) 