from fastapi import APIRouter, Query
from services.mobility_service import get_mobility_risk
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get mobility and density-based spread risk", response_model=dict)
def mobility_risk(
    lat: float = Query(..., description="Latitude of the location"),
    lon: float = Query(..., description="Longitude of the location"),
    radius_km: Optional[float] = Query(5.0, description="Radius in kilometers to analyze"),
):
    """
    Returns mobility and population density-based disease spread risk estimation.
    """
    return get_mobility_risk(lat=lat, lon=lon, radius_km=radius_km) 