from fastapi import APIRouter, Query
from services.widget_service import get_dashboard_widgets
from typing import Optional

router = APIRouter()

@router.get("/", summary="Get data for custom dashboard widgets", response_model=dict)
def get_widgets(
    user_id: str = Query(..., description="User ID"),
    widget_types: Optional[str] = Query("all", description="Comma-separated widget types")
):
    """Returns data for custom dashboard widgets."""
    return get_dashboard_widgets(user_id, widget_types) 