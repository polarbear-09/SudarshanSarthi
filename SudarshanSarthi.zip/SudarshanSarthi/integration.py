from fastapi import FastAPI, Request, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import logging
import uuid

# Configure structured logging
logging.basicConfig(
    format='%(asctime)s %(levelname)s %(message)s',
    level=logging.INFO
)
logger = logging.getLogger("sudarsansarthi.integration")

app = FastAPI(title="SudarshanSarthi Integration API", version="1.0.0")

# Enable CORS for all origins (development only)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Models ---

class LocationRequest(BaseModel):
    lat: float
    lon: float

class NewsRequest(BaseModel):
    title: str
    content: str
    source: Optional[str] = None

class SymptomsRequest(BaseModel):
    user_id: str
    symptoms: List[str]
    temperature: Optional[float] = None
    notes: Optional[str] = None

class VoiceQueryRequest(BaseModel):
    audio_data: str  # base64
    language: Optional[str] = "en"

class MentalHealthRequest(BaseModel):
    user_id: str
    text: str

class HealthEventReport(BaseModel):
    user_id: str
    event_type: str
    description: str
    location: Optional[str] = None
    timestamp: Optional[str] = None

class NewsVerificationRequest(BaseModel):
    title: str
    content: str
    source: Optional[str] = None

# --- Logging Middleware ---
@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"Incoming request: {request.method} {request.url}")
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response

# --- Endpoints ---

@app.get("/api/predict-location-risk", tags=["Prediction"])
async def predict_location_risk(lat: float, lon: float):
    """Location-based disease prediction."""
    return {
        "location": {"lat": lat, "lon": lon},
        "predicted_diseases": ["Dengue", "Malaria"],
        "risk_level": "medium",
        "confidence": 0.78
    }

@app.get("/api/weather-pollution-risk", tags=["Environment"])
async def weather_pollution_risk(lat: float, lon: float):
    """Get environmental risk based on location."""
    return {
        "location": {"lat": lat, "lon": lon},
        "temperature": 32,
        "humidity": 70,
        "pm25": 110,
        "risk_factor": "high",
        "recommendations": ["Wear a mask", "Avoid outdoor exercise"]
    }

@app.get("/api/news-sentiment", tags=["NLP"])
async def news_sentiment(title: str, content: str):
    """Health news sentiment analyzer using NLP."""
    return {
        "title": title,
        "sentiment": "negative",
        "confidence": 0.81,
        "summary": "The news indicates rising health concerns."
    }

@app.get("/api/mobility-risk", tags=["Mobility"])
async def mobility_risk(lat: float, lon: float):
    """Predict mobility-related disease risk."""
    return {
        "location": {"lat": lat, "lon": lon},
        "mobility_score": 0.65,
        "density": 2200,
        "risk": "medium",
        "hotspots": [
            {"lat": lat+0.01, "lon": lon+0.01, "risk": "high"}
        ]
    }

@app.get("/api/prevention-tips", tags=["Prevention"])
async def prevention_tips():
    """Get preventive tips."""
    return {
        "tips": [
            "Wash hands frequently",
            "Avoid crowded places",
            "Stay hydrated",
            "Get enough sleep"
        ]
    }

@app.get("/api/outbreak-forecast", tags=["Forecast"])
async def outbreak_forecast(location: str, days: int = 14):
    """Outbreak timeline visualization."""
    return {
        "location": location,
        "timeline": [
            {"date": f"2024-07-{i+1:02d}", "predicted_cases": 100 + i*5, "risk": "medium"} for i in range(days)
        ]
    }

@app.get("/api/heatmap-data", tags=["Heatmap"])
async def heatmap_data(lat: float, lon: float, zoom: int = 10):
    """Community alert heatmap data."""
    return {
        "center": {"lat": lat, "lon": lon},
        "zoom": zoom,
        "points": [
            {"lat": lat+0.01, "lon": lon+0.01, "intensity": 0.8},
            {"lat": lat-0.01, "lon": lon-0.01, "intensity": 0.5}
        ]
    }

@app.post("/api/log-symptoms", tags=["Symptoms"])
async def log_symptoms(data: SymptomsRequest):
    """User logs symptoms."""
    return {
        "log_id": str(uuid.uuid4()),
        "status": "logged",
        "entry": data.dict()
    }

@app.get("/api/symptom-risk", tags=["Prediction"])
async def symptom_risk(symptoms: str):
    """Disease prediction from symptoms."""
    symptom_list = [s.strip() for s in symptoms.split(",")]
    return {
        "symptoms": symptom_list,
        "predicted_diseases": ["Flu", "COVID-19"],
        "risk_level": "high",
        "confidence": 0.82
    }

@app.get("/api/send-alert", tags=["Alerts"])
async def send_alert(user_id: str, message: str):
    """Trigger push notification."""
    return {
        "user_id": user_id,
        "message": message,
        "status": "sent",
        "timestamp": "2024-07-05T12:00:00Z"
    }

@app.post("/api/voice-query", tags=["Voice"])
async def voice_query(data: VoiceQueryRequest):
    """Receive speech-to-text input."""
    return {
        "text": "I have a headache and fever.",
        "language": data.language,
        "confidence": 0.88
    }

@app.get("/api/cached-data", tags=["Cache"])
async def cached_data(user_id: str):
    """Offline cache data loader."""
    return {
        "user_id": user_id,
        "cached": True,
        "data": {
            "last_sync": "2024-07-01T10:00:00Z",
            "health_logs": [
                {"date": "2024-07-01", "symptoms": ["cough"]}
            ]
        }
    }

@app.get("/api/cat-mood", tags=["Fun"])
async def cat_mood(mood: Optional[str] = "happy", count: int = 3):
    """Fetch cat images using external Cat API."""
    return {
        "mood": mood,
        "images": [
            "https://cataas.com/cat/says/hello",
            "https://cataas.com/cat/says/relax",
            "https://cataas.com/cat/says/smile"
        ][:count]
    }

@app.get("/api/danger-radius", tags=["Safety"])
async def danger_radius(lat: float, lon: float):
    """Check if user is in danger zone."""
    return {
        "location": {"lat": lat, "lon": lon},
        "in_danger_zone": True,
        "risk_level": "high"
    }

@app.post("/api/mental-health-tone", tags=["Mental Health"])
async def mental_health_tone(data: MentalHealthRequest):
    """Tone detection from user input."""
    return {
        "user_id": data.user_id,
        "sentiment": "stressed",
        "confidence": 0.77,
        "recommendations": ["Take a break", "Practice mindfulness"]
    }

@app.get("/api/risk-cards", tags=["Dashboard"])
async def risk_cards():
    """Disease-specific risk cards."""
    return {
        "cards": [
            {"disease": "COVID-19", "risk": "high", "icon": "🦠"},
            {"disease": "Dengue", "risk": "medium", "icon": "🦟"}
        ]
    }

@app.get("/api/calendar-suggestions", tags=["Calendar"])
async def calendar_suggestions(user_id: str):
    """AI-based preventive calendar data."""
    return {
        "user_id": user_id,
        "calendar": [
            {"date": "2024-07-05", "tip": "Drink water"},
            {"date": "2024-07-06", "tip": "Exercise"}
        ]
    }

@app.post("/api/report-health-event", tags=["Community"])
async def report_health_event(data: HealthEventReport):
    """Community health reports."""
    return {
        "report_id": str(uuid.uuid4()),
        "status": "received",
        "event": data.dict()
    }

@app.post("/api/news-verification", tags=["NLP"])
async def news_verification(data: NewsVerificationRequest):
    """Fake news checker."""
    return {
        "classification": "likely_real",
        "confidence": 0.91,
        "recommendations": ["Verify with official sources"]
    }

@app.get("/api/widgets", tags=["Dashboard"])
async def widgets(user_id: str):
    """User's custom dashboard widget data."""
    return {
        "user_id": user_id,
        "widgets": [
            {"type": "health_summary", "status": "good"},
            {"type": "outbreak_stats", "risk": "medium"}
        ]
    } 