from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Server settings
    HOST: str = "0.0.0.0"
    PORT: int = 8001  # Changed from 8000 to avoid conflict
    DEBUG: bool = True
    
    # API settings
    API_V1_STR: str = "/api"
    PROJECT_NAME: str = "SudarshanSarthi Health Platform"
    
    # CORS settings
    BACKEND_CORS_ORIGINS: list = ["*"]
    
    # External API keys (configure in production)
    OPENWEATHER_API_KEY: Optional[str] = None
    NEWS_API_KEY: Optional[str] = None
    CAT_API_KEY: Optional[str] = None
    
    class Config:
        env_file = ".env"

settings = Settings() 