import logging
import logging.handlers
import json
import time
import traceback
from datetime import datetime
from typing import Dict, Any, Optional, Callable
from functools import wraps
import os

from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

try:
    from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
    TENACITY_AVAILABLE = True
except ImportError:
    TENACITY_AVAILABLE = False
    print("Warning: tenacity not installed. Retry decorators will not work.")

# --- Logger Configuration ---

def setup_logger(name: str = "sudarshan_logger") -> logging.Logger:
    """Setup structured logger with console and file handlers"""
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler (INFO+)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    
    # File handler with rotation (weekly or >1MB)
    file_handler = logging.handlers.RotatingFileHandler(
        filename="logs/server.log",
        maxBytes=1024*1024,  # 1MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    
    # Add handlers to logger
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger

# Global logger instance
logger = setup_logger("sudarshan_logger")

# --- Error Classes ---

class SudarshanAPIError(Exception):
    """Custom API error class"""
    def __init__(self, message: str, status_code: int = 500, details: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)

class GoogleSheetsError(Exception):
    """Google Sheets specific error"""
    pass

class ExternalAPIError(Exception):
    """External API error"""
    pass

# --- Global Exception Handlers ---

async def validation_error_handler(request: Request, exc: RequestValidationError):
    """Handle request validation errors"""
    error_details = []
    for error in exc.errors():
        error_details.append({
            "field": " -> ".join(str(loc) for loc in error["loc"]),
            "message": error["msg"],
            "type": error["type"]
        })
    
    logger.warning(f"Validation error: {error_details}")
    
    return JSONResponse(
        status_code=422,
        content={
            "error": "Validation Error",
            "detail": "Request data validation failed",
            "status": 422,
            "timestamp": datetime.now().isoformat(),
            "errors": error_details
        }
    )

async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    logger.warning(f"HTTP error {exc.status_code}: {exc.detail}")
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTP Error",
            "detail": exc.detail,
            "status": exc.status_code,
            "timestamp": datetime.now().isoformat()
        }
    )

async def sudarshan_api_error_handler(request: Request, exc: SudarshanAPIError):
    """Handle custom API errors"""
    logger.error(f"API error {exc.status_code}: {exc.message}", extra=exc.details)
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "API Error",
            "detail": exc.message,
            "status": exc.status_code,
            "timestamp": datetime.now().isoformat(),
            **exc.details
        }
    )

async def generic_exception_handler(request: Request, exc: Exception):
    """Handle generic exceptions"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "detail": "An unexpected error occurred",
            "status": 500,
            "timestamp": datetime.now().isoformat()
        }
    )

# --- Retry Decorator ---

def retry_operation(
    max_attempts: int = 3,
    start_wait: float = 1.0,
    max_wait: float = 10.0,
    retry_exceptions: tuple = (Exception,)
):
    """Retry decorator with exponential backoff"""
    
    if not TENACITY_AVAILABLE:
        def no_retry_decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                logger.warning(f"Retry decorator used but tenacity not available for {func.__name__}")
                return func(*args, **kwargs)
            return wrapper
        return no_retry_decorator
    
    def decorator(func: Callable) -> Callable:
        @retry(
            stop=stop_after_attempt(max_attempts),
            wait=wait_exponential(multiplier=start_wait, max=max_wait),
            retry=retry_if_exception_type(retry_exceptions),
            before_sleep=lambda retry_state: logger.warning(
                f"Retry {retry_state.attempt_number}/{max_attempts} for {func.__name__}: {retry_state.outcome.exception()}"
            )
        )
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Final failure after {max_attempts} attempts for {func.__name__}: {str(e)}")
                raise
        return wrapper
    return decorator

# --- Request Logging Middleware ---

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware to log all incoming requests"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next):
        # Start time
        start_time = time.time()
        
        # Get client IP
        client_ip = request.client.host if request.client else "unknown"
        
        # Log request details (excluding sensitive data)
        request_data = {
            "method": request.method,
            "url": str(request.url),
            "client_ip": client_ip,
            "user_agent": request.headers.get("user-agent", "unknown"),
            "query_params": dict(request.query_params),
        }
        
        # Log request body (excluding sensitive fields)
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body = await request.body()
                if body:
                    # Parse and filter sensitive data
                    body_dict = json.loads(body.decode())
                    filtered_body = self._filter_sensitive_data(body_dict)
                    request_data["body"] = filtered_body
            except:
                request_data["body"] = "[Unable to parse body]"
        
        logger.info(f"Request started: {json.dumps(request_data, default=str)}")
        
        # Process request
        try:
            response = await call_next(request)
            
            # Calculate duration
            duration = time.time() - start_time
            
            # Log response
            logger.info(
                f"Request completed: {request.method} {request.url.path} - "
                f"Status: {response.status_code} - Duration: {duration:.3f}s"
            )
            
            return response
            
        except Exception as e:
            # Calculate duration
            duration = time.time() - start_time
            
            # Log error
            logger.error(
                f"Request failed: {request.method} {request.url.path} - "
                f"Error: {str(e)} - Duration: {duration:.3f}s"
            )
            raise
    
    def _filter_sensitive_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Filter out sensitive data from request body"""
        sensitive_fields = {"password", "token", "api_key", "secret", "authorization"}
        filtered_data = {}
        
        for key, value in data.items():
            if key.lower() in sensitive_fields:
                filtered_data[key] = "[REDACTED]"
            elif isinstance(value, dict):
                filtered_data[key] = self._filter_sensitive_data(value)
            elif isinstance(value, list):
                filtered_data[key] = [
                    self._filter_sensitive_data(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                filtered_data[key] = value
        
        return filtered_data

# --- Utility Functions ---

def log_event(event_type: str, details: Dict[str, Any], level: str = "info"):
    """Log custom events"""
    log_data = {
        "event_type": event_type,
        "timestamp": datetime.now().isoformat(),
        **details
    }
    
    log_message = f"Event: {event_type} - {json.dumps(details, default=str)}"
    
    if level.lower() == "debug":
        logger.debug(log_message)
    elif level.lower() == "info":
        logger.info(log_message)
    elif level.lower() == "warning":
        logger.warning(log_message)
    elif level.lower() == "error":
        logger.error(log_message)
    else:
        logger.info(log_message)

def raise_api_error(message: str, status_code: int = 500, details: Optional[Dict] = None):
    """Unified function to raise API errors with logging"""
    logger.error(f"API Error {status_code}: {message}", extra=details or {})
    raise SudarshanAPIError(message, status_code, details)

def log_google_sheets_operation(operation: str, sheet_name: str, success: bool, error: Optional[str] = None):
    """Log Google Sheets operations"""
    log_data = {
        "operation": operation,
        "sheet_name": sheet_name,
        "success": success,
        "error": error
    }
    
    if success:
        logger.info(f"Google Sheets {operation} successful: {sheet_name}")
    else:
        logger.error(f"Google Sheets {operation} failed: {sheet_name} - {error}")

def log_external_api_call(api_name: str, endpoint: str, success: bool, duration: float, error: Optional[str] = None):
    """Log external API calls"""
    log_data = {
        "api_name": api_name,
        "endpoint": endpoint,
        "success": success,
        "duration": duration,
        "error": error
    }
    
    if success:
        logger.info(f"External API {api_name} call successful: {endpoint} ({duration:.3f}s)")
    else:
        logger.error(f"External API {api_name} call failed: {endpoint} ({duration:.3f}s) - {error}")

# --- Google Sheets Retry Decorators ---

@retry_operation(max_attempts=3, retry_exceptions=(GoogleSheetsError, ConnectionError))
def fetch_from_sheet(sheet_name: str, *args, **kwargs):
    """Fetch data from Google Sheets with retry"""
    try:
        # Your Google Sheets fetch logic here
        log_google_sheets_operation("fetch", sheet_name, True)
        return {"data": "mock_data"}  # Replace with actual implementation
    except Exception as e:
        log_google_sheets_operation("fetch", sheet_name, False, str(e))
        raise GoogleSheetsError(f"Failed to fetch from {sheet_name}: {str(e)}")

@retry_operation(max_attempts=3, retry_exceptions=(GoogleSheetsError, ConnectionError))
def write_to_sheet(sheet_name: str, data: Any, *args, **kwargs):
    """Write data to Google Sheets with retry"""
    try:
        # Your Google Sheets write logic here
        log_google_sheets_operation("write", sheet_name, True)
        return {"status": "success"}  # Replace with actual implementation
    except Exception as e:
        log_google_sheets_operation("write", sheet_name, False, str(e))
        raise GoogleSheetsError(f"Failed to write to {sheet_name}: {str(e)}")

# --- FastAPI Integration Functions ---

def setup_error_handlers(app: FastAPI):
    """Setup all error handlers for FastAPI app"""
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(SudarshanAPIError, sudarshan_api_error_handler)
    app.add_exception_handler(Exception, generic_exception_handler)
    
    logger.info("Error handlers configured for FastAPI app")

def setup_middleware(app: FastAPI):
    """Setup logging middleware for FastAPI app"""
    app.add_middleware(RequestLoggingMiddleware)
    logger.info("Request logging middleware configured")

def setup_logging_system(app: FastAPI):
    """Complete setup of logging and error handling system"""
    setup_error_handlers(app)
    setup_middleware(app)
    logger.info("Complete logging and error handling system configured")

# --- Example Usage ---

if __name__ == "__main__":
    # Example of how to use the logging system
    log_event("system_startup", {"version": "1.0.0", "environment": "development"})
    
    # Example of API error
    try:
        raise_api_error("Database connection failed", 503, {"database": "postgresql"})
    except SudarshanAPIError as e:
        print(f"Caught API error: {e.message}")
    
    # Example of external API call logging
    log_external_api_call("weather_api", "/current", True, 0.245)
    log_external_api_call("news_api", "/headlines", False, 5.123, "Timeout error") 