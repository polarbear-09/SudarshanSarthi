"""
API Fetcher Utility
Handles HTTP requests to external APIs with retry logic and error handling
"""

import httpx
import asyncio
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import json
from functools import wraps

logger = logging.getLogger(__name__)

class APIFetcher:
    """Utility class for making HTTP requests to external APIs"""
    
    def __init__(self, base_url: str = "", timeout: int = 30, max_retries: int = 3):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = None
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = httpx.AsyncClient(
            timeout=self.timeout,
            limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.aclose()
    
    async def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        retry_count: int = 0
    ) -> Dict[str, Any]:
        """Make HTTP request with retry logic"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}" if self.base_url else endpoint
        
        default_headers = {
            "Content-Type": "application/json",
            "User-Agent": "SudarshanSarthi-API/1.0"
        }
        if headers:
            default_headers.update(headers)
        
        try:
            response = await self.session.request(
                method=method,
                url=url,
                params=params,
                json=data,
                headers=default_headers
            )
            
            response.raise_for_status()
            return {
                "status": "success",
                "status_code": response.status_code,
                "data": response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
                "headers": dict(response.headers),
                "timestamp": datetime.now().isoformat()
            }
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code}: {e.response.text}")
            if retry_count < self.max_retries and e.response.status_code >= 500:
                await asyncio.sleep(2 ** retry_count)  # Exponential backoff
                return await self._make_request(method, endpoint, params, data, headers, retry_count + 1)
            
            return {
                "status": "error",
                "status_code": e.response.status_code,
                "error": f"HTTP {e.response.status_code}: {e.response.text}",
                "timestamp": datetime.now().isoformat()
            }
            
        except httpx.RequestError as e:
            logger.error(f"Request error: {e}")
            if retry_count < self.max_retries:
                await asyncio.sleep(2 ** retry_count)
                return await self._make_request(method, endpoint, params, data, headers, retry_count + 1)
            
            return {
                "status": "error",
                "error": f"Request failed: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {
                "status": "error",
                "error": f"Unexpected error: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    async def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Make GET request"""
        return await self._make_request("GET", endpoint, params=params, headers=headers)
    
    async def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Make POST request"""
        return await self._make_request("POST", endpoint, data=data, headers=headers)
    
    async def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Make PUT request"""
        return await self._make_request("PUT", endpoint, data=data, headers=headers)
    
    async def delete(self, endpoint: str, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Make DELETE request"""
        return await self._make_request("DELETE", endpoint, headers=headers)

class WeatherAPIFetcher(APIFetcher):
    """Specialized fetcher for weather API"""
    
    def __init__(self, api_key: str):
        super().__init__(base_url="https://api.openweathermap.org/data/2.5")
        self.api_key = api_key
    
    async def get_weather(self, city: str, country_code: str = "") -> Dict[str, Any]:
        """Get current weather for a city"""
        params = {
            "q": f"{city},{country_code}" if country_code else city,
            "appid": self.api_key,
            "units": "metric"
        }
        
        return await self.get("/weather", params=params)
    
    async def get_forecast(self, city: str, country_code: str = "") -> Dict[str, Any]:
        """Get 5-day weather forecast for a city"""
        params = {
            "q": f"{city},{country_code}" if country_code else city,
            "appid": self.api_key,
            "units": "metric"
        }
        
        return await self.get("/forecast", params=params)

class HealthAPIFetcher(APIFetcher):
    """Specialized fetcher for health-related APIs"""
    
    def __init__(self, api_key: str = ""):
        super().__init__(base_url="https://api.covid19api.com")
        self.api_key = api_key
    
    async def get_covid_summary(self) -> Dict[str, Any]:
        """Get global COVID-19 summary"""
        return await self.get("/summary")
    
    async def get_country_data(self, country: str) -> Dict[str, Any]:
        """Get COVID-19 data for a specific country"""
        return await self.get(f"/country/{country}")
    
    async def get_country_status(self, country: str, status: str = "confirmed") -> Dict[str, Any]:
        """Get COVID-19 status data for a country"""
        return await self.get(f"/country/{country}/status/{status}")

class NewsAPIFetcher(APIFetcher):
    """Specialized fetcher for news APIs"""
    
    def __init__(self, api_key: str):
        super().__init__(base_url="https://newsapi.org/v2")
        self.api_key = api_key
    
    async def get_health_news(self, country: str = "us", page_size: int = 20) -> Dict[str, Any]:
        """Get health-related news"""
        params = {
            "q": "health OR medical OR disease OR outbreak",
            "country": country,
            "pageSize": page_size,
            "apiKey": self.api_key,
            "sortBy": "publishedAt"
        }
        
        return await self.get("/everything", params=params)
    
    async def get_top_headlines(self, country: str = "us", category: str = "health") -> Dict[str, Any]:
        """Get top health headlines"""
        params = {
            "country": country,
            "category": category,
            "apiKey": self.api_key
        }
        
        return await self.get("/top-headlines", params=params)

# Utility functions
def with_retry(max_retries: int = 3, delay: float = 1.0):
    """Decorator for retrying async functions"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries:
                        await asyncio.sleep(delay * (2 ** attempt))  # Exponential backoff
                        logger.warning(f"Retry {attempt + 1}/{max_retries} for {func.__name__}: {e}")
                    else:
                        logger.error(f"Final attempt failed for {func.__name__}: {e}")
            
            raise last_exception
        return wrapper
    return decorator

async def fetch_multiple_apis(api_calls: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Fetch data from multiple APIs concurrently"""
    async with APIFetcher() as fetcher:
        tasks = []
        for call in api_calls:
            method = call.get("method", "GET")
            endpoint = call["endpoint"]
            params = call.get("params")
            data = call.get("data")
            headers = call.get("headers")
            
            task = fetcher._make_request(method, endpoint, params, data, headers)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        return {
            "status": "completed",
            "results": results,
            "timestamp": datetime.now().isoformat()
        }

# Example usage functions
async def get_health_data_for_location(city: str, weather_api_key: str) -> Dict[str, Any]:
    """Get comprehensive health data for a location"""
    weather_fetcher = WeatherAPIFetcher(weather_api_key)
    health_fetcher = HealthAPIFetcher()
    
    async with weather_fetcher, health_fetcher:
        weather_task = weather_fetcher.get_weather(city)
        covid_task = health_fetcher.get_covid_summary()
        
        weather_result, covid_result = await asyncio.gather(
            weather_task, covid_task, return_exceptions=True
        )
        
        return {
            "location": city,
            "weather": weather_result if not isinstance(weather_result, Exception) else {"error": str(weather_result)},
            "covid_data": covid_result if not isinstance(covid_result, Exception) else {"error": str(covid_result)},
            "timestamp": datetime.now().isoformat()
        } 