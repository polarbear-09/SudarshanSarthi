"""
Validators Utility
Handles data validation, sanitization, and input verification
"""

import re
import logging
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, date
from email_validator import validate_email, EmailNotValidError
import phonenumbers
from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

class ValidationError(Exception):
    """Custom validation error"""
    def __init__(self, message: str, field: str = None):
        self.message = message
        self.field = field
        super().__init__(self.message)

class DataValidator:
    """Main validator class for data validation and sanitization"""
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email address format"""
        try:
            validate_email(email)
            return True
        except EmailNotValidError:
            return False
    
    @staticmethod
    def validate_phone(phone: str, country_code: str = "IN") -> bool:
        """Validate phone number format"""
        try:
            parsed_number = phonenumbers.parse(phone, country_code)
            return phonenumbers.is_valid_number(parsed_number)
        except Exception:
            return False
    
    @staticmethod
    def validate_username(username: str) -> bool:
        """Validate username format"""
        # Username should be 3-20 characters, alphanumeric with underscores
        pattern = r'^[a-zA-Z0-9_]{3,20}$'
        return bool(re.match(pattern, username))
    
    @staticmethod
    def validate_password(password: str) -> Dict[str, Any]:
        """Validate password strength"""
        errors = []
        requirements = {
            "min_length": len(password) >= 8,
            "has_uppercase": bool(re.search(r'[A-Z]', password)),
            "has_lowercase": bool(re.search(r'[a-z]', password)),
            "has_digit": bool(re.search(r'\d', password)),
            "has_special": bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))
        }
        
        if not requirements["min_length"]:
            errors.append("Password must be at least 8 characters long")
        if not requirements["has_uppercase"]:
            errors.append("Password must contain at least one uppercase letter")
        if not requirements["has_lowercase"]:
            errors.append("Password must contain at least one lowercase letter")
        if not requirements["has_digit"]:
            errors.append("Password must contain at least one digit")
        if not requirements["has_special"]:
            errors.append("Password must contain at least one special character")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "strength_score": sum(requirements.values()) / len(requirements)
        }
    
    @staticmethod
    def validate_location(location: str) -> bool:
        """Validate location format"""
        # Basic location validation - should not be empty and contain valid characters
        if not location or len(location.strip()) < 2:
            return False
        
        # Should contain only letters, numbers, spaces, commas, and hyphens
        pattern = r'^[a-zA-Z0-9\s,\-\.]+$'
        return bool(re.match(pattern, location))
    
    @staticmethod
    def validate_temperature(temperature: float) -> bool:
        """Validate temperature value"""
        return -50 <= temperature <= 60  # Reasonable human body temperature range
    
    @staticmethod
    def validate_heart_rate(heart_rate: int) -> bool:
        """Validate heart rate value"""
        return 30 <= heart_rate <= 220  # Reasonable heart rate range
    
    @staticmethod
    def validate_blood_pressure(systolic: int, diastolic: int) -> bool:
        """Validate blood pressure values"""
        return (70 <= systolic <= 200 and 40 <= diastolic <= 130 and systolic > diastolic)
    
    @staticmethod
    def validate_date_range(start_date: Union[str, datetime, date], 
                           end_date: Union[str, datetime, date]) -> bool:
        """Validate date range"""
        try:
            if isinstance(start_date, str):
                start_date = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            if isinstance(end_date, str):
                end_date = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            
            return start_date <= end_date
        except Exception:
            return False
    
    @staticmethod
    def sanitize_string(text: str, max_length: int = 1000) -> str:
        """Sanitize string input"""
        if not text:
            return ""
        
        # Remove potentially dangerous characters
        sanitized = re.sub(r'[<>"\']', '', text)
        
        # Trim whitespace
        sanitized = sanitized.strip()
        
        # Limit length
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length]
        
        return sanitized
    
    @staticmethod
    def validate_symptoms(symptoms: List[str]) -> Dict[str, Any]:
        """Validate symptoms list"""
        valid_symptoms = [
            "fever", "cough", "fatigue", "headache", "body_aches",
            "sore_throat", "runny_nose", "congestion", "nausea",
            "vomiting", "diarrhea", "shortness_of_breath", "chest_pain",
            "loss_of_taste", "loss_of_smell", "rash", "itching"
        ]
        
        invalid_symptoms = []
        valid_symptoms_found = []
        
        for symptom in symptoms:
            if symptom.lower() in valid_symptoms:
                valid_symptoms_found.append(symptom.lower())
            else:
                invalid_symptoms.append(symptom)
        
        return {
            "is_valid": len(invalid_symptoms) == 0,
            "valid_symptoms": valid_symptoms_found,
            "invalid_symptoms": invalid_symptoms,
            "total_symptoms": len(valid_symptoms_found)
        }

class HealthDataValidator:
    """Specialized validator for health-related data"""
    
    @staticmethod
    def validate_health_record(data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate complete health record"""
        errors = []
        warnings = []
        
        # Required fields
        required_fields = ["user_id", "symptoms"]
        for field in required_fields:
            if field not in data or not data[field]:
                errors.append(f"Missing required field: {field}")
        
        # Validate user_id
        if "user_id" in data and data["user_id"]:
            if not DataValidator.validate_username(data["user_id"]):
                errors.append("Invalid user_id format")
        
        # Validate symptoms
        if "symptoms" in data and data["symptoms"]:
            symptom_validation = DataValidator.validate_symptoms(data["symptoms"])
            if not symptom_validation["is_valid"]:
                errors.extend([f"Invalid symptom: {symptom}" for symptom in symptom_validation["invalid_symptoms"]])
        
        # Validate temperature
        if "temperature" in data and data["temperature"] is not None:
            if not DataValidator.validate_temperature(data["temperature"]):
                errors.append("Temperature value out of valid range (-50 to 60°C)")
        
        # Validate heart rate
        if "heart_rate" in data and data["heart_rate"] is not None:
            if not DataValidator.validate_heart_rate(data["heart_rate"]):
                errors.append("Heart rate value out of valid range (30 to 220 bpm)")
        
        # Validate location
        if "location" in data and data["location"]:
            if not DataValidator.validate_location(data["location"]):
                warnings.append("Location format may be invalid")
        
        # Validate timestamp
        if "timestamp" in data and data["timestamp"]:
            try:
                if isinstance(data["timestamp"], str):
                    datetime.fromisoformat(data["timestamp"].replace('Z', '+00:00'))
            except ValueError:
                errors.append("Invalid timestamp format")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "validated_data": data
        }
    
    @staticmethod
    def validate_alert_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate alert data"""
        errors = []
        warnings = []
        
        # Required fields
        required_fields = ["alert_type", "severity", "title", "message"]
        for field in required_fields:
            if field not in data or not data[field]:
                errors.append(f"Missing required field: {field}")
        
        # Validate alert_type
        valid_alert_types = ["outbreak", "health", "emergency", "info"]
        if "alert_type" in data and data["alert_type"]:
            if data["alert_type"] not in valid_alert_types:
                errors.append(f"Invalid alert_type. Must be one of: {valid_alert_types}")
        
        # Validate severity
        valid_severities = ["low", "medium", "high", "critical"]
        if "severity" in data and data["severity"]:
            if data["severity"] not in valid_severities:
                errors.append(f"Invalid severity. Must be one of: {valid_severities}")
        
        # Validate title and message length
        if "title" in data and data["title"]:
            if len(data["title"]) > 200:
                errors.append("Title too long (max 200 characters)")
        
        if "message" in data and data["message"]:
            if len(data["message"]) > 1000:
                errors.append("Message too long (max 1000 characters)")
        
        # Validate case_count
        if "case_count" in data and data["case_count"] is not None:
            if not isinstance(data["case_count"], int) or data["case_count"] < 0:
                errors.append("Case count must be a non-negative integer")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "validated_data": data
        }

class UserDataValidator:
    """Specialized validator for user-related data"""
    
    @staticmethod
    def validate_user_registration(data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate user registration data"""
        errors = []
        warnings = []
        
        # Required fields
        required_fields = ["username", "email", "full_name", "password"]
        for field in required_fields:
            if field not in data or not data[field]:
                errors.append(f"Missing required field: {field}")
        
        # Validate username
        if "username" in data and data["username"]:
            if not DataValidator.validate_username(data["username"]):
                errors.append("Username must be 3-20 characters, alphanumeric with underscores only")
        
        # Validate email
        if "email" in data and data["email"]:
            if not DataValidator.validate_email(data["email"]):
                errors.append("Invalid email format")
        
        # Validate password
        if "password" in data and data["password"]:
            password_validation = DataValidator.validate_password(data["password"])
            if not password_validation["is_valid"]:
                errors.extend(password_validation["errors"])
        
        # Validate full_name
        if "full_name" in data and data["full_name"]:
            if len(data["full_name"].strip()) < 2:
                errors.append("Full name must be at least 2 characters long")
        
        # Validate role
        valid_roles = ["user", "admin", "healthcare_provider"]
        if "role" in data and data["role"]:
            if data["role"] not in valid_roles:
                errors.append(f"Invalid role. Must be one of: {valid_roles}")
        
        # Validate phone
        if "phone" in data and data["phone"]:
            if not DataValidator.validate_phone(data["phone"]):
                warnings.append("Phone number format may be invalid")
        
        # Validate location
        if "location" in data and data["location"]:
            if not DataValidator.validate_location(data["location"]):
                warnings.append("Location format may be invalid")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "validated_data": data
        }

# Utility functions
def validate_and_sanitize_input(data: Dict[str, Any], validator_class: type) -> Dict[str, Any]:
    """Generic function to validate and sanitize input data"""
    try:
        # Sanitize string fields
        for key, value in data.items():
            if isinstance(value, str):
                data[key] = DataValidator.sanitize_string(value)
        
        # Use appropriate validator
        if validator_class == HealthDataValidator:
            return HealthDataValidator.validate_health_record(data)
        elif validator_class == UserDataValidator:
            return UserDataValidator.validate_user_registration(data)
        elif validator_class == HealthDataValidator:
            return HealthDataValidator.validate_alert_data(data)
        else:
            return {"is_valid": True, "errors": [], "warnings": [], "validated_data": data}
    
    except Exception as e:
        logger.error(f"Validation error: {e}")
        return {
            "is_valid": False,
            "errors": [f"Validation failed: {str(e)}"],
            "warnings": [],
            "validated_data": data
        } 