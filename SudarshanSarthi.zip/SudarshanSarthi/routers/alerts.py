"""
Alerts Router
Handles outbreak alerts, notifications, and emergency communications
"""

from fastapi import APIRouter, HTTPException, Depends
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()

# Pydantic models for request/response
class Alert(BaseModel):
    alert_id: Optional[str] = None
    alert_type: str  # "outbreak", "health", "emergency", "info"
    severity: str  # "low", "medium", "high", "critical"
    title: str
    message: str
    location: Optional[str] = None
    affected_area: Optional[str] = None
    disease_name: Optional[str] = None
    case_count: Optional[int] = None
    timestamp: Optional[datetime] = None
    expires_at: Optional[datetime] = None

class AlertResponse(BaseModel):
    alert_id: str
    status: str
    message: str

# Mock data for development
MOCK_ALERTS = [
    {
        "alert_id": "alert_001",
        "alert_type": "outbreak",
        "severity": "high",
        "title": "COVID-19 Outbreak Alert",
        "message": "New COVID-19 cases detected in downtown area. Please take precautions.",
        "location": "Downtown",
        "affected_area": "2km radius",
        "disease_name": "COVID-19",
        "case_count": 15,
        "timestamp": "2024-01-15T10:00:00",
        "expires_at": "2024-01-22T10:00:00"
    },
    {
        "alert_id": "alert_002",
        "alert_type": "health",
        "severity": "medium",
        "title": "Flu Season Warning",
        "message": "Flu season is approaching. Get vaccinated and practice good hygiene.",
        "location": "City-wide",
        "affected_area": "Entire city",
        "disease_name": "Influenza",
        "case_count": None,
        "timestamp": "2024-01-15T09:00:00",
        "expires_at": "2024-01-30T09:00:00"
    }
]

@router.get("/alerts")
async def get_alerts(
    alert_type: Optional[str] = None,
    severity: Optional[str] = None,
    location: Optional[str] = None,
    active_only: bool = True
):
    """Get all alerts with optional filtering"""
    try:
        alerts = MOCK_ALERTS.copy()
        
        # Apply filters
        if alert_type:
            alerts = [alert for alert in alerts if alert["alert_type"] == alert_type]
        
        if severity:
            alerts = [alert for alert in alerts if alert["severity"] == severity]
        
        if location:
            alerts = [alert for alert in alerts if location.lower() in alert.get("location", "").lower()]
        
        if active_only:
            # Filter out expired alerts
            current_time = datetime.now()
            alerts = [
                alert for alert in alerts 
                if not alert.get("expires_at") or datetime.fromisoformat(alert["expires_at"]) > current_time
            ]
        
        return {
            "status": "success",
            "alerts": alerts,
            "count": len(alerts),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching alerts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/alerts/{alert_id}")
async def get_alert(alert_id: str):
    """Get a specific alert by ID"""
    try:
        alert = next((alert for alert in MOCK_ALERTS if alert["alert_id"] == alert_id), None)
        
        if not alert:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        return {
            "status": "success",
            "alert": alert,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching alert: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/alerts")
async def create_alert(alert: Alert):
    """Create a new alert"""
    try:
        # Generate alert ID if not provided
        if not alert.alert_id:
            alert.alert_id = f"alert_{len(MOCK_ALERTS) + 1:03d}"
        
        # Add timestamp if not provided
        if not alert.timestamp:
            alert.timestamp = datetime.now()
        
        # Convert to dict
        alert_dict = alert.dict()
        alert_dict["timestamp"] = alert_dict["timestamp"].isoformat()
        if alert_dict.get("expires_at"):
            alert_dict["expires_at"] = alert_dict["expires_at"].isoformat()
        
        # Add to mock data
        MOCK_ALERTS.append(alert_dict)
        
        logger.info(f"Created alert: {alert.alert_id}")
        
        return {
            "status": "success",
            "message": "Alert created successfully",
            "alert": alert_dict,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error creating alert: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.put("/alerts/{alert_id}")
async def update_alert(alert_id: str, alert_update: Alert):
    """Update an existing alert"""
    try:
        # Find existing alert
        alert_index = next((i for i, alert in enumerate(MOCK_ALERTS) if alert["alert_id"] == alert_id), None)
        
        if alert_index is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        # Update alert
        alert_dict = alert_update.dict()
        alert_dict["alert_id"] = alert_id  # Ensure ID doesn't change
        alert_dict["timestamp"] = alert_dict.get("timestamp", datetime.now()).isoformat()
        if alert_dict.get("expires_at"):
            alert_dict["expires_at"] = alert_dict["expires_at"].isoformat()
        
        MOCK_ALERTS[alert_index] = alert_dict
        
        logger.info(f"Updated alert: {alert_id}")
        
        return {
            "status": "success",
            "message": "Alert updated successfully",
            "alert": alert_dict,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating alert: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.delete("/alerts/{alert_id}")
async def delete_alert(alert_id: str):
    """Delete an alert"""
    try:
        # Find and remove alert
        alert_index = next((i for i, alert in enumerate(MOCK_ALERTS) if alert["alert_id"] == alert_id), None)
        
        if alert_index is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        deleted_alert = MOCK_ALERTS.pop(alert_index)
        
        logger.info(f"Deleted alert: {alert_id}")
        
        return {
            "status": "success",
            "message": "Alert deleted successfully",
            "alert_id": alert_id,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting alert: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/alerts/outbreak/active")
async def get_active_outbreak_alerts():
    """Get all active outbreak alerts"""
    try:
        current_time = datetime.now()
        outbreak_alerts = [
            alert for alert in MOCK_ALERTS
            if alert["alert_type"] == "outbreak" and
            (not alert.get("expires_at") or datetime.fromisoformat(alert["expires_at"]) > current_time)
        ]
        
        return {
            "status": "success",
            "outbreak_alerts": outbreak_alerts,
            "count": len(outbreak_alerts),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching outbreak alerts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/alerts/severity/{severity}")
async def get_alerts_by_severity(severity: str):
    """Get alerts by severity level"""
    try:
        severity_alerts = [alert for alert in MOCK_ALERTS if alert["severity"] == severity]
        
        return {
            "status": "success",
            "alerts": severity_alerts,
            "severity": severity,
            "count": len(severity_alerts),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching alerts by severity: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/alerts/broadcast")
async def broadcast_alert(alert: Alert):
    """Broadcast an alert to all connected WebSocket clients"""
    try:
        # Create the alert first
        if not alert.alert_id:
            alert.alert_id = f"alert_{len(MOCK_ALERTS) + 1:03d}"
        
        if not alert.timestamp:
            alert.timestamp = datetime.now()
        
        alert_dict = alert.dict()
        alert_dict["timestamp"] = alert_dict["timestamp"].isoformat()
        if alert_dict.get("expires_at"):
            alert_dict["expires_at"] = alert_dict["expires_at"].isoformat()
        
        # Add to mock data
        MOCK_ALERTS.append(alert_dict)
        
        # In production, this would broadcast via WebSocket
        # For now, just return success
        logger.info(f"Broadcasted alert: {alert.alert_id}")
        
        return {
            "status": "success",
            "message": "Alert broadcasted successfully",
            "alert": alert_dict,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error broadcasting alert: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/alerts/analytics")
async def get_alert_analytics():
    """Get analytics about alerts"""
    try:
        current_time = datetime.now()
        
        # Calculate analytics
        total_alerts = len(MOCK_ALERTS)
        active_alerts = len([
            alert for alert in MOCK_ALERTS
            if not alert.get("expires_at") or datetime.fromisoformat(alert["expires_at"]) > current_time
        ])
        
        severity_distribution = {}
        type_distribution = {}
        
        for alert in MOCK_ALERTS:
            severity = alert["severity"]
            alert_type = alert["alert_type"]
            
            severity_distribution[severity] = severity_distribution.get(severity, 0) + 1
            type_distribution[alert_type] = type_distribution.get(alert_type, 0) + 1
        
        analytics = {
            "total_alerts": total_alerts,
            "active_alerts": active_alerts,
            "expired_alerts": total_alerts - active_alerts,
            "severity_distribution": severity_distribution,
            "type_distribution": type_distribution,
            "last_updated": datetime.now().isoformat()
        }
        
        return {
            "status": "success",
            "analytics": analytics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching alert analytics: {e}")
        raise HTTPException(status_code=500, detail="Internal server error") 