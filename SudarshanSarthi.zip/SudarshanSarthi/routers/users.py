"""
Users Router
Handles user management, authentication, and user-related operations
"""

from fastapi import APIRouter, HTTPException, Depends
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from pydantic import BaseModel, EmailStr

logger = logging.getLogger(__name__)
router = APIRouter()

# Pydantic models for request/response
class User(BaseModel):
    user_id: Optional[str] = None
    username: str
    email: EmailStr
    full_name: str
    role: str = "user"  # "user", "admin", "healthcare_provider"
    location: Optional[str] = None
    phone: Optional[str] = None
    is_active: bool = True
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    full_name: str
    password: str
    role: str = "user"
    location: Optional[str] = None
    phone: Optional[str] = None

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    location: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None

class UserLogin(BaseModel):
    username: str
    password: str

class UserProfile(BaseModel):
    user_id: str
    username: str
    email: EmailStr
    full_name: str
    role: str
    location: Optional[str] = None
    phone: Optional[str] = None
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None

# Mock data for development
MOCK_USERS = [
    {
        "user_id": "user_001",
        "username": "john_doe",
        "email": "john.doe@example.com",
        "full_name": "John Doe",
        "role": "user",
        "location": "New York",
        "phone": "+1-555-0123",
        "is_active": True,
        "created_at": "2024-01-01T00:00:00",
        "last_login": "2024-01-15T10:30:00"
    },
    {
        "user_id": "user_002",
        "username": "admin_user",
        "email": "admin@sudarshan.com",
        "full_name": "Admin User",
        "role": "admin",
        "location": "Mumbai",
        "phone": "+91-98765-43210",
        "is_active": True,
        "created_at": "2024-01-01T00:00:00",
        "last_login": "2024-01-15T09:15:00"
    },
    {
        "user_id": "user_003",
        "username": "dr_smith",
        "email": "dr.smith@hospital.com",
        "full_name": "Dr. Sarah Smith",
        "role": "healthcare_provider",
        "location": "Delhi",
        "phone": "+91-98765-12345",
        "is_active": True,
        "created_at": "2024-01-05T00:00:00",
        "last_login": "2024-01-15T08:45:00"
    }
]

@router.get("/users")
async def get_users(
    role: Optional[str] = None,
    location: Optional[str] = None,
    active_only: bool = True
):
    """Get all users with optional filtering"""
    try:
        users = MOCK_USERS.copy()
        
        # Apply filters
        if role:
            users = [user for user in users if user["role"] == role]
        
        if location:
            users = [user for user in users if location.lower() in user.get("location", "").lower()]
        
        if active_only:
            users = [user for user in users if user["is_active"]]
        
        return {
            "status": "success",
            "users": users,
            "count": len(users),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching users: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/users/{user_id}")
async def get_user(user_id: str):
    """Get a specific user by ID"""
    try:
        user = next((user for user in MOCK_USERS if user["user_id"] == user_id), None)
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {
            "status": "success",
            "user": user,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/users")
async def create_user(user_data: UserCreate):
    """Create a new user"""
    try:
        # Check if username or email already exists
        existing_user = next(
            (user for user in MOCK_USERS 
             if user["username"] == user_data.username or user["email"] == user_data.email),
            None
        )
        
        if existing_user:
            raise HTTPException(status_code=400, detail="Username or email already exists")
        
        # Create new user
        new_user = {
            "user_id": f"user_{len(MOCK_USERS) + 1:03d}",
            "username": user_data.username,
            "email": user_data.email,
            "full_name": user_data.full_name,
            "role": user_data.role,
            "location": user_data.location,
            "phone": user_data.phone,
            "is_active": True,
            "created_at": datetime.now().isoformat(),
            "last_login": None
        }
        
        MOCK_USERS.append(new_user)
        
        logger.info(f"Created user: {new_user['user_id']}")
        
        return {
            "status": "success",
            "message": "User created successfully",
            "user": new_user,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.put("/users/{user_id}")
async def update_user(user_id: str, user_update: UserUpdate):
    """Update an existing user"""
    try:
        # Find existing user
        user_index = next((i for i, user in enumerate(MOCK_USERS) if user["user_id"] == user_id), None)
        
        if user_index is None:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update user fields
        update_data = user_update.dict(exclude_unset=True)
        for key, value in update_data.items():
            MOCK_USERS[user_index][key] = value
        
        logger.info(f"Updated user: {user_id}")
        
        return {
            "status": "success",
            "message": "User updated successfully",
            "user": MOCK_USERS[user_index],
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.delete("/users/{user_id}")
async def delete_user(user_id: str):
    """Delete a user (soft delete by setting is_active to False)"""
    try:
        # Find user
        user_index = next((i for i, user in enumerate(MOCK_USERS) if user["user_id"] == user_id), None)
        
        if user_index is None:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Soft delete
        MOCK_USERS[user_index]["is_active"] = False
        
        logger.info(f"Deleted user: {user_id}")
        
        return {
            "status": "success",
            "message": "User deleted successfully",
            "user_id": user_id,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/users/login")
async def login_user(login_data: UserLogin):
    """User login endpoint"""
    try:
        # Find user by username
        user = next((user for user in MOCK_USERS if user["username"] == login_data.username), None)
        
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        if not user["is_active"]:
            raise HTTPException(status_code=401, detail="Account is deactivated")
        
        # In production, verify password hash here
        # For now, just check if user exists
        
        # Update last login
        user["last_login"] = datetime.now().isoformat()
        
        logger.info(f"User logged in: {user['user_id']}")
        
        return {
            "status": "success",
            "message": "Login successful",
            "user": {
                "user_id": user["user_id"],
                "username": user["username"],
                "email": user["email"],
                "full_name": user["full_name"],
                "role": user["role"],
                "location": user["location"],
                "phone": user["phone"]
            },
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error during login: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/users/profile/{user_id}")
async def get_user_profile(user_id: str):
    """Get user profile information"""
    try:
        user = next((user for user in MOCK_USERS if user["user_id"] == user_id), None)
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Return profile without sensitive information
        profile = {
            "user_id": user["user_id"],
            "username": user["username"],
            "email": user["email"],
            "full_name": user["full_name"],
            "role": user["role"],
            "location": user["location"],
            "phone": user["phone"],
            "is_active": user["is_active"],
            "created_at": user["created_at"],
            "last_login": user["last_login"]
        }
        
        return {
            "status": "success",
            "profile": profile,
            "timestamp": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching user profile: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/users/analytics")
async def get_user_analytics():
    """Get analytics about users"""
    try:
        total_users = len(MOCK_USERS)
        active_users = len([user for user in MOCK_USERS if user["is_active"]])
        
        role_distribution = {}
        location_distribution = {}
        
        for user in MOCK_USERS:
            role = user["role"]
            location = user.get("location", "Unknown")
            
            role_distribution[role] = role_distribution.get(role, 0) + 1
            location_distribution[location] = location_distribution.get(location, 0) + 1
        
        analytics = {
            "total_users": total_users,
            "active_users": active_users,
            "inactive_users": total_users - active_users,
            "role_distribution": role_distribution,
            "location_distribution": location_distribution,
            "last_updated": datetime.now().isoformat()
        }
        
        return {
            "status": "success",
            "analytics": analytics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error fetching user analytics: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/users/search")
async def search_users(
    query: str,
    role: Optional[str] = None,
    location: Optional[str] = None
):
    """Search users by name, username, or email"""
    try:
        query_lower = query.lower()
        matching_users = []
        
        for user in MOCK_USERS:
            # Check if query matches name, username, or email
            if (query_lower in user["full_name"].lower() or
                query_lower in user["username"].lower() or
                query_lower in user["email"].lower()):
                
                # Apply additional filters
                if role and user["role"] != role:
                    continue
                if location and location.lower() not in user.get("location", "").lower():
                    continue
                
                matching_users.append(user)
        
        return {
            "status": "success",
            "users": matching_users,
            "query": query,
            "count": len(matching_users),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error searching users: {e}")
        raise HTTPException(status_code=500, detail="Internal server error") 