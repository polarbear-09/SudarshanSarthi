"""
SudarshanSarthi Backend API
FastAPI application for AI-powered health companion platform
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import logging
from typing import List
import json
from datetime import datetime
from config import settings
import os
from contextlib import asynccontextmanager

# Import logging and error handling system
from utils.errors_and_logging import setup_logging_system, logger

# Import all modules
from api import router as api_router
from integration import router as integration_router
from llm_assistant import router as llm_router
from realtime_ws import router as websocket_router
from admin_dashboard import router as admin_router

# --- Application Lifecycle ---

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting SudarshanSarthi Health Platform...")
    logger.info("Initializing all modules and services...")
    
    # Create necessary directories
    os.makedirs("logs", exist_ok=True)
    os.makedirs("static", exist_ok=True)
    
    logger.info("Application startup complete")
    
    yield
    
    # Shutdown
    logger.info("Shutting down SudarshanSarthi Health Platform...")
    logger.info("Cleanup complete")

# --- FastAPI Application ---

app = FastAPI(
    title="SudarshanSarthi Health Platform",
    description="A comprehensive health outbreak monitoring and management platform",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# --- CORS Configuration ---

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:8000", 
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
        "http://localhost:5000",
        "http://127.0.0.1:5000",
        "*"  # For development - restrict in production
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Static Files ---

# Mount static files directory
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

# --- Include All Routers ---

# API endpoints
app.include_router(api_router, prefix="/api/v1", tags=["Health API"])

# Integration endpoints  
app.include_router(integration_router, prefix="/integration", tags=["Integration"])

# LLM Assistant endpoints
app.include_router(llm_router, prefix="/llm", tags=["LLM Assistant"])

# WebSocket endpoints
app.include_router(websocket_router, prefix="/ws", tags=["WebSocket"])

# Admin Dashboard endpoints
app.include_router(admin_router, prefix="/admin", tags=["Admin Dashboard"])

# --- Setup Logging and Error Handling ---

setup_logging_system(app)

# --- Root Endpoint ---

@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with platform information"""
    return {
        "message": "Welcome to SudarshanSarthi Health Platform",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "admin": "/admin",
        "websocket": "/ws",
        "modules": {
            "health_api": "/api/v1",
            "integration": "/integration", 
            "llm_assistant": "/llm",
            "websocket": "/ws",
            "admin_dashboard": "/admin"
        }
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": "2024-07-06T12:00:00Z",
        "version": "1.0.0",
        "modules": {
            "api": "active",
            "integration": "active", 
            "llm_assistant": "active",
            "websocket": "active",
            "admin_dashboard": "active"
        }
    }

# --- Frontend Routes ---

@app.get("/dashboard", tags=["Frontend"])
async def dashboard():
    """Serve the main dashboard"""
    if os.path.exists("static/dashboard.html"):
        return FileResponse("static/dashboard.html")
    else:
        return {"error": "Dashboard not found"}

@app.get("/outbreak-map", tags=["Frontend"])
async def outbreak_map():
    """Serve the outbreak map page"""
    if os.path.exists("static/outbreak-map.html"):
        return FileResponse("static/outbreak-map.html")
    else:
        return {"error": "Outbreak map not found"}

@app.get("/feature-audit", tags=["Frontend"])
async def feature_audit():
    """Serve the feature audit page"""
    if os.path.exists("static/feature-audit.html"):
        return FileResponse("static/feature-audit.html")
    else:
        return {"error": "Feature audit not found"}

@app.get("/admin-panel", tags=["Frontend"])
async def admin_panel():
    """Serve the admin panel"""
    if os.path.exists("static/admin-panel.html"):
        return FileResponse("static/admin-panel.html")
    else:
        return {"error": "Admin panel not found"}

# --- Error Handlers ---

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Handle 404 errors"""
    logger.warning(f"404 error: {request.url}")
    return {
        "error": "Not Found",
        "message": "The requested resource was not found",
        "path": str(request.url.path)
    }

@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    """Handle 500 errors"""
    logger.error(f"500 error: {str(exc)}", exc_info=True)
    return {
        "error": "Internal Server Error", 
        "message": "An unexpected error occurred"
    }

# --- Main Entry Point ---

if __name__ == "__main__":
    logger.info("Starting SudarshanSarthi server...")
    
    # Run the application
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 