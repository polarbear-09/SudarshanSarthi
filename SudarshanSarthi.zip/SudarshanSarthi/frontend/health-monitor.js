// Health Monitor Application
class HealthMonitor {
    constructor() {
        this.healthData = this.loadHealthData();
        this.moodData = this.loadMoodData();
        this.chart = null;
        this.tooltip = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.initializeCharts();
        this.setupTooltips();
        this.loadCatImage();
        this.updateLastUpdated();
        this.hideLoading();
    }
    
    setupEventListeners() {
        // Refresh button
        document.getElementById('refresh-btn').addEventListener('click', () => {
            this.refreshData();
        });
        
        // Health log form
        document.getElementById('health-log-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.logSymptom();
        });
        
        // Severity slider
        const severitySlider = document.getElementById('symptom-severity');
        const severityValue = document.getElementById('severity-value');
        severitySlider.addEventListener('input', (e) => {
            severityValue.textContent = e.target.value;
        });
        
        // Mood buttons
        document.querySelectorAll('.mood-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.logMood(btn.dataset.mood);
            });
        });
        
        // New cat button
        document.getElementById('new-cat-btn').addEventListener('click', () => {
            this.loadCatImage();
        });
        
        // Forecast controls
        document.getElementById('forecast-disease').addEventListener('change', () => {
            this.updateForecast();
        });
        
        document.getElementById('forecast-period').addEventListener('change', () => {
            this.updateForecast();
        });
        
        // Risk card interactions
        document.querySelectorAll('.risk-card').forEach(card => {
            card.addEventListener('click', () => {
                this.showRiskDetails(card.dataset.disease);
            });
        });
    }
    
    setupTooltips() {
        this.tooltip = document.getElementById('tooltip');
        
        // Add tooltip functionality to risk cards
        document.querySelectorAll('.risk-card').forEach(card => {
            card.addEventListener('mouseenter', (e) => {
                this.showTooltip(e, this.getRiskTooltipContent(card.dataset.disease));
            });
            
            card.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        });
        
        // Add tooltip functionality to tip cards
        document.querySelectorAll('.tip-card').forEach(card => {
            card.addEventListener('mouseenter', (e) => {
                this.showTooltip(e, this.getTipTooltipContent(card));
            });
            
            card.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        });
    }
    
    showTooltip(event, content) {
        this.tooltip.innerHTML = content;
        this.tooltip.classList.add('show');
        
        const rect = event.target.getBoundingClientRect();
        const tooltipRect = this.tooltip.getBoundingClientRect();
        
        let left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
        let top = rect.top - tooltipRect.height - 10;
        
        // Adjust if tooltip goes off screen
        if (left < 10) left = 10;
        if (left + tooltipRect.width > window.innerWidth - 10) {
            left = window.innerWidth - tooltipRect.width - 10;
        }
        if (top < 10) {
            top = rect.bottom + 10;
        }
        
        this.tooltip.style.left = left + 'px';
        this.tooltip.style.top = top + 'px';
    }
    
    hideTooltip() {
        this.tooltip.classList.remove('show');
    }
    
    getRiskTooltipContent(disease) {
        const tooltips = {
            flu: `
                <strong>Influenza Risk Factors:</strong><br>
                • Seasonal patterns<br>
                • Community spread rate<br>
                • Weather conditions<br>
                • Vaccination coverage<br>
                <em>Updated every 6 hours</em>
            `,
            covid: `
                <strong>COVID-19 Risk Factors:</strong><br>
                • Local case rates<br>
                • Vaccination status<br>
                • Variant prevalence<br>
                • Community testing<br>
                <em>Updated every 4 hours</em>
            `,
            dengue: `
                <strong>Dengue Risk Factors:</strong><br>
                • Mosquito activity<br>
                • Rainfall patterns<br>
                • Temperature<br>
                • Standing water<br>
                <em>Updated every 2 hours</em>
            `,
            allergies: `
                <strong>Allergy Risk Factors:</strong><br>
                • Pollen count<br>
                • Air quality<br>
                • Weather conditions<br>
                • Seasonal patterns<br>
                <em>Updated every hour</em>
            `
        };
        return tooltips[disease] || 'Risk assessment based on multiple factors';
    }
    
    getTipTooltipContent(tipCard) {
        const priority = tipCard.querySelector('.tip-priority').textContent;
        const category = tipCard.querySelector('.tip-category').textContent;
        
        return `
            <strong>${tipCard.querySelector('h4').textContent}</strong><br>
            Priority: ${priority}<br>
            Category: ${category}<br>
            <em>Based on your location and current health data</em>
        `;
    }
    
    initializeCharts() {
        const ctx = document.getElementById('health-chart').getContext('2d');
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.getLast7Days(),
                datasets: [
                    {
                        label: 'Fever',
                        data: this.getSymptomData('fever'),
                        borderColor: '#e63946',
                        backgroundColor: 'rgba(230, 57, 70, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Cough',
                        data: this.getSymptomData('cough'),
                        borderColor: '#ffb703',
                        backgroundColor: 'rgba(255, 183, 3, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Fatigue',
                        data: this.getSymptomData('fatigue'),
                        borderColor: '#0077b6',
                        backgroundColor: 'rgba(0, 119, 182, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Healthy',
                        data: this.getSymptomData('none'),
                        borderColor: '#52b788',
                        backgroundColor: 'rgba(82, 183, 136, 0.1)',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 10,
                        ticks: {
                            stepSize: 2
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }
    
    getLast7Days() {
        const days = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            days.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
        }
        return days;
    }
    
    getSymptomData(symptom) {
        const data = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dayData = this.healthData[date.toISOString().split('T')[0]];
            
            if (dayData && dayData.symptom === symptom) {
                data.push(dayData.severity);
            } else {
                data.push(0);
            }
        }
        return data;
    }
    
    logSymptom() {
        const form = document.getElementById('health-log-form');
        const symptomType = document.getElementById('symptom-type').value;
        const severity = document.getElementById('symptom-severity').value;
        const notes = document.getElementById('symptom-notes').value;
        
        if (!symptomType) {
            this.showNotification('Please select a symptom type', 'error');
            return;
        }
        
        const today = new Date().toISOString().split('T')[0];
        const symptomData = {
            symptom: symptomType,
            severity: parseInt(severity),
            notes: notes,
            timestamp: new Date().toISOString()
        };
        
        this.healthData[today] = symptomData;
        this.saveHealthData();
        
        // Update chart
        this.updateChart();
        
        // Reset form
        form.reset();
        document.getElementById('severity-value').textContent = '5';
        
        this.showNotification('Symptom logged successfully!', 'success');
    }
    
    logMood(mood) {
        // Remove active class from all buttons
        document.querySelectorAll('.mood-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to clicked button
        event.target.closest('.mood-btn').classList.add('active');
        
        const today = new Date().toISOString().split('T')[0];
        this.moodData[today] = mood;
        this.saveMoodData();
        
        // Update mood history
        this.updateMoodHistory();
        
        // If stressed, show cat therapy
        if (mood === 'stressed') {
            this.loadCatImage();
            this.showNotification('Feeling stressed? Here\'s a cute cat to cheer you up!', 'info');
        }
        
        this.showNotification('Mood logged successfully!', 'success');
    }
    
    updateMoodHistory() {
        const moodHistory = document.querySelector('.mood-history');
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        
        // Clear existing history
        moodHistory.innerHTML = '';
        
        // Generate last 7 days
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dayKey = date.toISOString().split('T')[0];
            const mood = this.moodData[dayKey] || 'good';
            
            const dayElement = document.createElement('div');
            dayElement.className = 'mood-day';
            dayElement.innerHTML = `
                <span class="day">${days[date.getDay()]}</span>
                <i class="fas fa-${this.getMoodIcon(mood)} mood-icon ${mood}"></i>
            `;
            
            moodHistory.appendChild(dayElement);
        }
    }
    
    getMoodIcon(mood) {
        const icons = {
            great: 'laugh-beam',
            good: 'smile',
            okay: 'meh',
            stressed: 'tired',
            sick: 'sick'
        };
        return icons[mood] || 'smile';
    }
    
    async loadCatImage() {
        const catContainer = document.querySelector('.cat-container');
        const catLoading = document.getElementById('cat-loading');
        const catImage = document.getElementById('cat-image');
        const newCatBtn = document.getElementById('new-cat-btn');
        
        // Show loading
        catLoading.style.display = 'flex';
        catImage.style.display = 'none';
        newCatBtn.classList.add('loading');
        
        try {
            // Simulate API call with random cat images
            const catImages = [
                'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&h=300&fit=crop',
                'https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?w=400&h=300&fit=crop',
                'https://images.unsplash.com/photo-1529778873920-4da4926a72c2?w=400&h=300&fit=crop',
                'https://images.unsplash.com/photo-1574158622682-e40e69881006?w=400&h=300&fit=crop',
                'https://images.unsplash.com/photo-1495360010541-f48722b34f7d?w=400&h=300&fit=crop'
            ];
            
            const randomImage = catImages[Math.floor(Math.random() * catImages.length)];
            
            // Simulate loading delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            catImage.src = randomImage;
            catImage.onload = () => {
                catLoading.style.display = 'none';
                catImage.style.display = 'block';
                newCatBtn.classList.remove('loading');
            };
            
        } catch (error) {
            console.error('Error loading cat image:', error);
            catLoading.innerHTML = '<i class="fas fa-exclamation-triangle"></i><span>Failed to load cat image</span>';
            newCatBtn.classList.remove('loading');
        }
    }
    
    updateChart() {
        if (this.chart) {
            this.chart.data.datasets[0].data = this.getSymptomData('fever');
            this.chart.data.datasets[1].data = this.getSymptomData('cough');
            this.chart.data.datasets[2].data = this.getSymptomData('fatigue');
            this.chart.data.datasets[3].data = this.getSymptomData('none');
            this.chart.update();
        }
    }
    
    updateForecast() {
        const disease = document.getElementById('forecast-disease').value;
        const period = document.getElementById('forecast-period').value;
        
        // Simulate forecast update
        console.log(`Updating forecast for ${disease} over ${period} days`);
        
        // Update timeline points with new data
        this.updateTimelinePoints(disease, period);
    }
    
    updateTimelinePoints(disease, period) {
        const timelinePoints = document.querySelectorAll('.timeline-point');
        
        timelinePoints.forEach((point, index) => {
            const pointElement = point.querySelector('.point');
            const riskElement = point.querySelector('.risk');
            
            // Generate random risk levels based on disease
            const risks = ['Low', 'Medium', 'High'];
            const risk = risks[Math.floor(Math.random() * risks.length)];
            
            // Update point color
            pointElement.className = 'point';
            if (risk === 'Medium') pointElement.classList.add('medium');
            if (risk === 'High') pointElement.classList.add('high');
            
            // Update risk text
            riskElement.textContent = risk;
        });
    }
    
    showRiskDetails(disease) {
        const details = {
            flu: {
                title: 'Influenza Risk Details',
                description: 'Detailed analysis of flu risk factors in your area',
                recommendations: [
                    'Get vaccinated if not already',
                    'Practice good hand hygiene',
                    'Avoid close contact with sick people',
                    'Stay home if you feel unwell'
                ]
            },
            covid: {
                title: 'COVID-19 Risk Details',
                description: 'Comprehensive COVID-19 risk assessment',
                recommendations: [
                    'Wear masks in crowded areas',
                    'Maintain social distance',
                    'Get booster shots if eligible',
                    'Monitor for symptoms'
                ]
            },
            dengue: {
                title: 'Dengue Risk Details',
                description: 'Dengue fever risk analysis and prevention',
                recommendations: [
                    'Use mosquito repellent',
                    'Eliminate standing water',
                    'Wear long sleeves and pants',
                    'Use mosquito nets'
                ]
            },
            allergies: {
                title: 'Allergy Risk Details',
                description: 'Seasonal allergy risk assessment',
                recommendations: [
                    'Monitor pollen counts',
                    'Take antihistamines if needed',
                    'Keep windows closed',
                    'Use air purifiers'
                ]
            }
        };
        
        const detail = details[disease];
        if (detail) {
            this.showModal(detail.title, detail.description, detail.recommendations);
        }
    }
    
    showModal(title, description, recommendations) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <p>${description}</p>
                    <h4>Recommendations:</h4>
                    <ul>
                        ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add modal styles
        const modalStyles = `
            .modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            
            .modal-content {
                background: var(--bg-card);
                border-radius: var(--radius-lg);
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                animation: slideIn 0.3s ease;
            }
            
            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: var(--spacing-lg);
                border-bottom: 1px solid var(--border-color);
            }
            
            .modal-header h3 {
                margin: 0;
                color: var(--text-primary);
            }
            
            .modal-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: var(--text-secondary);
                padding: 0;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                transition: all var(--transition-fast);
            }
            
            .modal-close:hover {
                background: var(--shadow-light);
                color: var(--text-primary);
            }
            
            .modal-body {
                padding: var(--spacing-lg);
            }
            
            .modal-body h4 {
                color: var(--text-primary);
                margin-bottom: var(--spacing-sm);
            }
            
            .modal-body ul {
                list-style: none;
                padding: 0;
            }
            
            .modal-body li {
                padding: var(--spacing-xs) 0;
                color: var(--text-secondary);
                position: relative;
                padding-left: var(--spacing-md);
            }
            
            .modal-body li::before {
                content: '•';
                color: var(--primary-color);
                position: absolute;
                left: 0;
                font-weight: bold;
            }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes slideIn {
                from { transform: translateY(-50px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
        `;
        
        if (!document.getElementById('modal-styles')) {
            const style = document.createElement('style');
            style.id = 'modal-styles';
            style.textContent = modalStyles;
            document.head.appendChild(style);
        }
        
        // Close modal functionality
        modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.classList.contains('modal-close')) {
                modal.remove();
            }
        });
    }
    
    refreshData() {
        const refreshBtn = document.getElementById('refresh-btn');
        refreshBtn.classList.add('loading');
        
        // Simulate data refresh
        setTimeout(() => {
            this.updateLastUpdated();
            this.showNotification('Data refreshed successfully!', 'success');
            refreshBtn.classList.remove('loading');
        }, 2000);
    }
    
    updateLastUpdated() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        document.getElementById('last-updated').textContent = `Last updated: ${timeString}`;
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification-toast ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
    
    showLoading() {
        document.getElementById('loading-overlay').classList.add('show');
    }
    
    hideLoading() {
        setTimeout(() => {
            document.getElementById('loading-overlay').classList.remove('show');
        }, 1000);
    }
    
    // Data persistence
    loadHealthData() {
        const data = localStorage.getItem('healthData');
        return data ? JSON.parse(data) : {};
    }
    
    saveHealthData() {
        localStorage.setItem('healthData', JSON.stringify(this.healthData));
    }
    
    loadMoodData() {
        const data = localStorage.getItem('moodData');
        return data ? JSON.parse(data) : {};
    }
    
    saveMoodData() {
        localStorage.setItem('moodData', JSON.stringify(this.moodData));
    }
}

// Initialize Health Monitor when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const healthMonitor = new HealthMonitor();
    
    // Add notification styles
    const notificationStyles = `
        .notification-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            padding: var(--spacing-md);
            box-shadow: var(--shadow-dropdown);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform var(--transition-normal);
        }
        
        .notification-toast.show {
            transform: translateX(0);
        }
        
        .notification-toast.success {
            border-left: 4px solid var(--success-color);
        }
        
        .notification-toast.error {
            border-left: 4px solid var(--error-color);
        }
        
        .notification-toast.warning {
            border-left: 4px solid var(--warning-color);
        }
        
        .notification-toast.info {
            border-left: 4px solid var(--info-color);
        }
        
        .notification-toast i {
            color: var(--success-color);
        }
        
        .notification-toast.error i {
            color: var(--error-color);
        }
        
        .notification-toast.warning i {
            color: var(--warning-color);
        }
        
        .notification-toast.info i {
            color: var(--info-color);
        }
    `;
    
    const style = document.createElement('style');
    style.textContent = notificationStyles;
    document.head.appendChild(style);
}); 