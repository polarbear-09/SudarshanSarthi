// Feature data structure
const FEATURES = [
  // Core Features
  {
    group: 'core',
    icon: 'fa-house-medical',
    title: 'Landing Page',
    desc: 'Professional landing page with hero, about, features, team, vision, and sticky navbar.',
    page: 'index.html',
    location: 'Landing Page',
    components: ['.navbar', '.hero', '.about', '.features', '.vision', '.team', '.footer'],
    backend: false,
    ready: false,
    nav: true,
    id: 'feature-landing',
    apis: [],
    scripts: ['script.js'],
    figma: 'Landing/Hero',
    navPath: 'Landing',
    testCases: ['Navbar links work', 'Get Started navigates to dashboard'],
  },
  {
    group: 'core',
    icon: 'fa-tachometer-alt',
    title: 'Dashboard Layout',
    desc: 'Sticky sidebar, top navbar, slot-based main content, mobile menu, dynamic theming.',
    page: 'dashboard/dashboard.html',
    location: 'Dashboard',
    components: ['.sidebar', '.top-navbar', '.main-content', '.dashboard-footer'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-dashboard',
    apis: ['/api/theme'],
    scripts: ['dashboard.js'],
    figma: 'Dashboard/Layout',
    navPath: 'Dashboard',
    testCases: ['Sidebar links work', 'Dark mode persists'],
  },
  {
    group: 'core',
    icon: 'fa-heartbeat',
    title: 'Health Monitor',
    desc: 'Disease risk cards, health log, chart, outbreak forecast, preventive tips, mood interface.',
    page: 'health-monitor.html',
    location: 'Dashboard > Health Monitor',
    components: ['.risk-cards-grid', '.health-log-form', '.health-log-chart', '.forecast-timeline-visual', '.tips-scroll', '.mood-section'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-health-monitor',
    apis: ['/api/health', '/api/predictions'],
    scripts: ['health-monitor.js'],
    figma: 'Dashboard/Health Monitor',
    navPath: 'Dashboard > Health Monitor',
    testCases: ['Log symptom updates chart', 'Risk cards show tooltips'],
  },
  {
    group: 'core',
    icon: 'fa-map-marked-alt',
    title: 'Outbreak Map',
    desc: 'Interactive heatmap, mobility zones, GPS danger radius, global view, fake news widget, report modal.',
    page: 'outbreak-map.html',
    location: 'Dashboard > Outbreak Map',
    components: ['.map-placeholder', '.mobility-zones', '.danger-radius', '.global-view', '.fake-news-banner', '.report-modal'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-map',
    apis: ['/api/map', '/api/reports'],
    scripts: ['outbreak-map.js'],
    figma: 'Dashboard/Outbreak Map',
    navPath: 'Dashboard > Outbreak Map',
    testCases: ['Map loads with animation', 'Report modal submits'],
  },
  {
    group: 'core',
    icon: 'fa-microphone',
    title: 'Voice Assistant',
    desc: 'Speech-to-text, TTS preview, voice navigation, tone analyzer, conversation log, export.',
    page: 'voice-assistant.html',
    location: 'Dashboard > Voice Assistant',
    components: ['.voice-interface', '.voice-controls', '.voice-transcript', '.tone-analyzer'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-voice',
    apis: ['/api/voice', '/api/tone'],
    scripts: ['voice-assistant.js'],
    figma: 'Dashboard/Voice Assistant',
    navPath: 'Dashboard > Voice Assistant',
    testCases: ['Speech logs to panel', 'TTS preview works'],
  },
  {
    group: 'core',
    icon: 'fa-cog',
    title: 'User Settings',
    desc: 'Theme color picker, language dropdown, widget management, story mode, save with toast.',
    page: 'settings/settings.html',
    location: 'Settings',
    components: ['.settings-grid', '.color-picker', '.language-dropdown', '.widget-carousel', '.story-mode-modal'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-settings',
    apis: ['/api/user/settings', '/api/languages'],
    scripts: ['settings.js'],
    figma: 'Settings',
    navPath: 'Settings',
    testCases: ['Save triggers toast', 'Widget drag-and-drop works'],
  },
  {
    group: 'core',
    icon: 'fa-user-shield',
    title: 'Admin Panel',
    desc: 'Upload data, view reports, create alerts, AI insights, sidebar navigation.',
    page: 'admin/admin-dashboard.html',
    location: 'Admin Panel',
    components: ['.admin-sidebar', '.upload-form', '.reports-table', '.alert-modal', '.ai-insights'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-admin',
    apis: ['/api/admin/upload', '/api/admin/reports', '/api/admin/alerts'],
    scripts: ['admin-dashboard.js'],
    figma: 'Admin Panel',
    navPath: 'Admin Panel',
    testCases: ['Upload form submits', 'Alerts preview modal works'],
  },
  {
    group: 'core',
    icon: 'fa-biohazard',
    title: '404 Error Page',
    desc: 'Virus-themed animation, quarantine message, auto-redirect, home button.',
    page: '404.html',
    location: '404 Page',
    components: ['.virus-animation', '.error-message', '.home-btn', '.auto-redirect'],
    backend: false,
    ready: false,
    nav: true,
    id: 'feature-404',
    apis: [],
    scripts: ['js/404.js'],
    figma: '404',
    navPath: '404',
    testCases: ['Redirect countdown works', 'Home button navigates'],
  },
  // Bonus Challenges (examples)
  {
    group: 'bonus',
    icon: 'fa-spinner',
    title: 'Custom Loading Animation',
    desc: 'Animated loading screens with fun facts and progress bar.',
    page: 'index.html, dashboard.html, health-monitor.html',
    location: 'All Pages',
    components: ['#loading-screen', '#loading-overlay'],
    backend: false,
    ready: false,
    nav: true,
    id: 'feature-loading',
    apis: [],
    scripts: ['script.js', 'dashboard.js', 'health-monitor.js'],
    figma: 'Loading',
    navPath: 'All',
    testCases: ['Loading shows on route change'],
    bonus: 'easy',
  },
  {
    group: 'bonus',
    icon: 'fa-language',
    title: 'Language Switcher',
    desc: 'Dropdown to switch UI language, connected to backend API.',
    page: 'index.html, dashboard.html, settings.html',
    location: 'Navbar, Settings',
    components: ['.language-toggle', '.language-dropdown'],
    backend: true,
    ready: false,
    nav: true,
    id: 'feature-language',
    apis: ['/api/languages'],
    scripts: ['script.js', 'dashboard.js', 'settings.js'],
    figma: 'Language',
    navPath: 'Navbar, Settings',
    testCases: ['Language changes UI'],
    bonus: 'medium',
  },
  {
    group: 'bonus',
    icon: 'fa-moon',
    title: 'Dark Mode',
    desc: 'Dark mode toggle with localStorage persistence and dynamic theming.',
    page: 'index.html, dashboard.html, settings.html',
    location: 'Navbar, Settings',
    components: ['.theme-toggle', '[data-theme]'],
    backend: false,
    ready: false,
    nav: true,
    id: 'feature-darkmode',
    apis: [],
    scripts: ['script.js', 'dashboard.js', 'settings.js'],
    figma: 'Dark Mode',
    navPath: 'Navbar, Settings',
    testCases: ['Dark mode persists', 'Theme changes instantly'],
    bonus: 'easy',
  },
  {
    group: 'bonus',
    icon: 'fa-bolt',
    title: 'Global API Error Toast',
    desc: 'Animated toast for API errors with retry/dismiss and progress bar.',
    page: 'index.html, dashboard.html',
    location: 'Global',
    components: ['.api-error-toast'],
    backend: true,
    ready: false,
    nav: false,
    id: 'feature-api-toast',
    apis: ['/api/*'],
    scripts: ['script.js', 'dashboard.js'],
    figma: 'API Toast',
    navPath: 'Global',
    testCases: ['Toast appears on error', 'Retry works'],
    bonus: 'medium',
  },
  // Extra Features
  {
    group: 'extra',
    icon: 'fa-robot',
    title: 'LLM Bot Integration',
    desc: 'LLM-powered chatbot for health queries and support.',
    page: 'voice-assistant.html',
    location: 'Voice Assistant',
    components: ['.llm-bot', '.chat-panel'],
    backend: true,
    ready: false,
    nav: false,
    id: 'feature-llm-bot',
    apis: ['/api/llm'],
    scripts: ['voice-assistant.js'],
    figma: 'LLM Bot',
    navPath: 'Voice Assistant',
    testCases: ['Bot responds to queries'],
  },
];

// State
let featureState = {};

function loadFeatureState() {
  const saved = localStorage.getItem('featureAuditState');
  if (saved) {
    featureState = JSON.parse(saved);
  } else {
    FEATURES.forEach(f => featureState[f.id] = {
      backend: f.backend,
      ready: false,
      nav: f.nav
    });
  }
}
function saveFeatureState() {
  localStorage.setItem('featureAuditState', JSON.stringify(featureState));
}

function renderFeatures() {
  ['core', 'bonus', 'extra'].forEach(group => {
    const grid = document.getElementById(group === 'core' ? 'core-feature-grid' : group === 'bonus' ? 'bonus-feature-grid' : 'extra-feature-grid');
    grid.innerHTML = '';
    FEATURES.filter(f => f.group === group).forEach(f => {
      const state = featureState[f.id] || { backend: f.backend, ready: false, nav: f.nav };
      const card = document.createElement('div');
      card.className = 'feature-card' + (state.ready ? ' verified' : '');
      card.setAttribute('tabindex', '0');
      card.setAttribute('data-id', f.id);
      card.innerHTML = `
        <div class="feature-header">
          <span class="feature-icon"><i class="fas ${f.icon}"></i></span>
          <span class="feature-title">${f.title}</span>
        </div>
        <div class="feature-desc">${f.desc}</div>
        <div class="feature-meta">
          <span class="meta-tag blue" title="Page Location"><i class="fas fa-map-pin"></i> ${f.location}</span>
          <span class="meta-tag orange" title="Page"><i class="fas fa-file"></i> ${f.page}</span>
        </div>
        <div class="feature-components">
          ${f.components.map(c => `<span class="component-id" title="${c}">${c}</span>`).join(' ')}
        </div>
        <div class="feature-controls">
          <label class="toggle" title="Backend Dependency">
            <input type="checkbox" data-toggle="backend" ${state.backend ? 'checked' : ''}> Backend
          </label>
          <label class="toggle" title="Integration Ready">
            <input type="checkbox" data-toggle="ready" ${state.ready ? 'checked' : ''}> Integration Ready
          </label>
          <span class="toggle" title="Navigation Check">
            <i class="fas fa-route nav-check ${f.nav ? '' : 'false'}"></i> Nav
          </span>
        </div>
        <div class="feature-actions">
          <button class="feature-info" title="Show Details"><i class="fas fa-info-circle"></i></button>
        </div>
      `;
      // Event listeners
      card.querySelectorAll('input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', e => {
          const type = input.getAttribute('data-toggle');
          featureState[f.id][type] = input.checked;
          saveFeatureState();
          renderFeatures();
        });
      });
      card.querySelector('.feature-info').addEventListener('click', e => {
        showFeatureModal(f);
      });
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') showFeatureModal(f);
      });
      grid.appendChild(card);
    });
  });
}

function showFeatureModal(f) {
  const modal = document.getElementById('feature-modal');
  const body = document.getElementById('modal-body');
  body.innerHTML = `
    <h2><i class="fas ${f.icon}"></i> ${f.title}</h2>
    <p>${f.desc}</p>
    <div><strong>Page Location:</strong> ${f.location}</div>
    <div><strong>Page:</strong> ${f.page}</div>
    <div><strong>UI Components:</strong> ${f.components.map(c => `<span class='component-id'>${c}</span>`).join(' ')}</div>
    <div><strong>Backend APIs:</strong> ${f.apis.length ? f.apis.join(', ') : 'None'}</div>
    <div><strong>Related Scripts:</strong> ${f.scripts.join(', ')}</div>
    <div><strong>Figma/HTML Ref:</strong> ${f.figma}</div>
    <div><strong>Navigation Path:</strong> ${f.navPath}</div>
    <div><strong>Test Cases:</strong><ul>${f.testCases.map(tc => `<li>${tc}</li>`).join('')}</ul></div>
  `;
  modal.classList.add('show');
}

document.getElementById('modal-close').onclick = () => {
  document.getElementById('feature-modal').classList.remove('show');
};
window.onclick = function(event) {
  const modal = document.getElementById('feature-modal');
  if (event.target === modal) modal.classList.remove('show');
};

// Controls
function markAllVerified() {
  Object.keys(featureState).forEach(id => featureState[id].ready = true);
  saveFeatureState();
  renderFeatures();
}
function resetStatus() {
  Object.keys(featureState).forEach(id => featureState[id].ready = false);
  saveFeatureState();
  renderFeatures();
}
function exportReport() {
  const report = FEATURES.map(f => ({
    id: f.id,
    title: f.title,
    page: f.page,
    ready: featureState[f.id]?.ready || false,
    backend: featureState[f.id]?.backend || false,
    nav: f.nav,
    components: f.components,
    apis: f.apis,
    scripts: f.scripts
  }));
  const blob = new Blob([JSON.stringify(report, null, 2)], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'feature-audit-report.json';
  a.click();
  URL.revokeObjectURL(url);
}
document.getElementById('mark-all').onclick = markAllVerified;
document.getElementById('reset-status').onclick = resetStatus;
document.getElementById('export-report').onclick = exportReport;

// Search & Sort
function filterAndSortFeatures() {
  const search = document.getElementById('feature-search').value.toLowerCase();
  const sort = document.getElementById('feature-sort').value;
  let filtered = FEATURES.filter(f =>
    f.title.toLowerCase().includes(search) ||
    f.page.toLowerCase().includes(search) ||
    f.location.toLowerCase().includes(search)
  );
  if (sort === 'readiness') {
    filtered = filtered.sort((a, b) => (featureState[b.id]?.ready || false) - (featureState[a.id]?.ready || false));
  } else if (sort === 'backend') {
    filtered = filtered.sort((a, b) => (featureState[b.id]?.backend || false) - (featureState[a.id]?.backend || false));
  }
  // Re-render only filtered features
  ['core', 'bonus', 'extra'].forEach(group => {
    const grid = document.getElementById(group === 'core' ? 'core-feature-grid' : group === 'bonus' ? 'bonus-feature-grid' : 'extra-feature-grid');
    grid.innerHTML = '';
    filtered.filter(f => f.group === group).forEach(f => {
      const state = featureState[f.id] || { backend: f.backend, ready: false, nav: f.nav };
      const card = document.createElement('div');
      card.className = 'feature-card' + (state.ready ? ' verified' : '');
      card.setAttribute('tabindex', '0');
      card.setAttribute('data-id', f.id);
      card.innerHTML = `
        <div class="feature-header">
          <span class="feature-icon"><i class="fas ${f.icon}"></i></span>
          <span class="feature-title">${f.title}</span>
        </div>
        <div class="feature-desc">${f.desc}</div>
        <div class="feature-meta">
          <span class="meta-tag blue" title="Page Location"><i class="fas fa-map-pin"></i> ${f.location}</span>
          <span class="meta-tag orange" title="Page"><i class="fas fa-file"></i> ${f.page}</span>
        </div>
        <div class="feature-components">
          ${f.components.map(c => `<span class="component-id" title="${c}">${c}</span>`).join(' ')}
        </div>
        <div class="feature-controls">
          <label class="toggle" title="Backend Dependency">
            <input type="checkbox" data-toggle="backend" ${state.backend ? 'checked' : ''}> Backend
          </label>
          <label class="toggle" title="Integration Ready">
            <input type="checkbox" data-toggle="ready" ${state.ready ? 'checked' : ''}> Integration Ready
          </label>
          <span class="toggle" title="Navigation Check">
            <i class="fas fa-route nav-check ${f.nav ? '' : 'false'}"></i> Nav
          </span>
        </div>
        <div class="feature-actions">
          <button class="feature-info" title="Show Details"><i class="fas fa-info-circle"></i></button>
        </div>
      `;
      card.querySelectorAll('input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', e => {
          const type = input.getAttribute('data-toggle');
          featureState[f.id][type] = input.checked;
          saveFeatureState();
          filterAndSortFeatures();
        });
      });
      card.querySelector('.feature-info').addEventListener('click', e => {
        showFeatureModal(f);
      });
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') showFeatureModal(f);
      });
      grid.appendChild(card);
    });
  });
}
document.getElementById('feature-search').oninput = filterAndSortFeatures;
document.getElementById('feature-sort').onchange = filterAndSortFeatures;

// Sidebar collapse
const sidebar = document.getElementById('audit-sidebar');
document.getElementById('sidebar-toggle').onclick = () => {
  sidebar.classList.toggle('collapsed');
};

// Tooltip logic
const tooltip = document.getElementById('audit-tooltip');
document.body.addEventListener('mouseover', function(e) {
  if (e.target.classList.contains('component-id')) {
    tooltip.textContent = e.target.title;
    tooltip.classList.add('show');
    const rect = e.target.getBoundingClientRect();
    tooltip.style.top = (rect.bottom + window.scrollY + 8) + 'px';
    tooltip.style.left = (rect.left + window.scrollX) + 'px';
  }
});
document.body.addEventListener('mouseout', function(e) {
  if (e.target.classList.contains('component-id')) {
    tooltip.classList.remove('show');
  }
});

// Initial load
loadFeatureState();
renderFeatures();

</rewritten_file> 