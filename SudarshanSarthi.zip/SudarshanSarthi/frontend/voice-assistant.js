// Voice Assistant JavaScript
class VoiceAssistant {
    constructor() {
        this.isRecording = false;
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.currentUtterance = null;
        this.transcriptHistory = [];
        this.stressLevel = 45;
        this.initializeElements();
        this.setupEventListeners();
        this.initializeSpeechRecognition();
        this.loadSettings();
        this.startLoadingAnimation();
    }

    initializeElements() {
        // Core elements
        this.micButton = document.getElementById('micButton');
        this.transcriptContent = document.getElementById('transcriptContent');
        this.ttsInput = document.getElementById('ttsInput');
        this.voiceSelect = document.getElementById('voiceSelect');
        this.speedSlider = document.getElementById('speedSlider');
        this.speedValue = document.getElementById('speedValue');
        
        // Control buttons
        this.playTTS = document.getElementById('playTTS');
        this.pauseTTS = document.getElementById('pauseTTS');
        this.stopTTS = document.getElementById('stopTTS');
        this.testTTS = document.getElementById('testTTS');
        this.clearSpeech = document.getElementById('clearSpeech');
        this.copyTranscript = document.getElementById('copyTranscript');
        this.saveTranscript = document.getElementById('saveTranscript');
        this.refreshAnalysis = document.getElementById('refreshAnalysis');
        this.exportHistory = document.getElementById('exportHistory');
        
        // Settings elements
        this.voiceNavToggle = document.getElementById('voiceNavToggle');
        this.wakeWord = document.getElementById('wakeWord');
        this.sensitivitySlider = document.getElementById('sensitivitySlider');
        this.autoTranscribeToggle = document.getElementById('autoTranscribeToggle');
        
        // Analysis elements
        this.stressLevelElement = document.getElementById('stressLevel');
        this.stressLabelElement = document.getElementById('stressLabel');
        this.heartRateElement = document.getElementById('heartRate');
        this.breathingRateElement = document.getElementById('breathingRate');
        this.voicePitchElement = document.getElementById('voicePitch');
        this.speakingPaceElement = document.getElementById('speakingPace');
        this.moodInsightElement = document.getElementById('moodInsight');
        
        // UI elements
        this.loading = document.getElementById('loading');
        this.sidebarToggle = document.querySelector('.sidebar-toggle');
        this.sidebar = document.querySelector('.sidebar');
        this.themeToggle = document.querySelector('.theme-toggle');
    }

    setupEventListeners() {
        // Microphone controls
        this.micButton.addEventListener('click', () => this.toggleRecording());
        
        // TTS controls
        this.playTTS.addEventListener('click', () => this.playTTSAudio());
        this.pauseTTS.addEventListener('click', () => this.pauseTTSAudio());
        this.stopTTS.addEventListener('click', () => this.stopTTSAudio());
        this.testTTS.addEventListener('click', () => this.testTTSAudio());
        
        // Transcript controls
        this.clearSpeech.addEventListener('click', () => this.clearTranscript());
        this.copyTranscript.addEventListener('click', () => this.copyTranscriptToClipboard());
        this.saveTranscript.addEventListener('click', () => this.saveTranscriptToFile());
        
        // Settings controls
        this.voiceNavToggle.addEventListener('change', () => this.saveSettings());
        this.wakeWord.addEventListener('input', () => this.saveSettings());
        this.sensitivitySlider.addEventListener('input', () => this.saveSettings());
        this.autoTranscribeToggle.addEventListener('change', () => this.saveSettings());
        
        // Analysis controls
        this.refreshAnalysis.addEventListener('click', () => this.refreshAnalysisData());
        this.exportHistory.addEventListener('click', () => this.exportConversationHistory());
        
        // UI controls
        this.sidebarToggle.addEventListener('click', () => this.toggleSidebar());
        this.themeToggle.addEventListener('click', () => this.toggleTheme());
        
        // Speed control
        this.speedSlider.addEventListener('input', (e) => {
            this.speedValue.textContent = `${e.target.value}x`;
        });
        
        // Voice selection
        this.voiceSelect.addEventListener('change', () => this.updateVoiceSelection());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
        
        // Window events
        window.addEventListener('resize', () => this.handleResize());
    }

    initializeSpeechRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = true;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            
            this.recognition.onstart = () => {
                this.isRecording = true;
                this.updateMicButton(true);
                this.updateMicStatus('Listening...');
            };
            
            this.recognition.onresult = (event) => {
                let finalTranscript = '';
                let interimTranscript = '';
                
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }
                
                this.updateTranscript(finalTranscript, interimTranscript);
                
                if (finalTranscript) {
                    this.analyzeSpeech(finalTranscript);
                    this.saveToHistory(finalTranscript);
                }
            };
            
            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.updateMicStatus(`Error: ${event.error}`);
                this.stopRecording();
            };
            
            this.recognition.onend = () => {
                this.stopRecording();
            };
        } else {
            this.updateMicStatus('Speech recognition not supported');
            this.micButton.disabled = true;
        }
    }

    toggleRecording() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            this.startRecording();
        }
    }

    startRecording() {
        if (this.recognition) {
            this.recognition.start();
        }
    }

    stopRecording() {
        if (this.recognition) {
            this.recognition.stop();
        }
        this.isRecording = false;
        this.updateMicButton(false);
        this.updateMicStatus('Click to start recording');
    }

    updateMicButton(recording) {
        if (recording) {
            this.micButton.classList.add('recording');
            this.micButton.querySelector('.mic-icon i').className = 'fas fa-stop';
        } else {
            this.micButton.classList.remove('recording');
            this.micButton.querySelector('.mic-icon i').className = 'fas fa-microphone';
        }
    }

    updateMicStatus(status) {
        const statusElement = document.querySelector('.mic-status');
        if (statusElement) {
            statusElement.textContent = status;
        }
    }

    updateTranscript(final, interim = '') {
        if (final) {
            this.transcriptContent.innerHTML = `
                <div class="transcript-text">
                    <strong>Final:</strong> ${final}
                    ${interim ? `<br><em>Interim:</em> ${interim}` : ''}
                </div>
            `;
        } else if (interim) {
            this.transcriptContent.innerHTML = `
                <div class="transcript-text">
                    <em>Interim:</em> ${interim}
                </div>
            `;
        }
    }

    clearTranscript() {
        this.transcriptContent.innerHTML = `
            <div class="transcript-placeholder">
                <i class="fas fa-comment-dots"></i>
                <p>Your speech will appear here...</p>
            </div>
        `;
    }

    copyTranscriptToClipboard() {
        const text = this.transcriptContent.textContent;
        if (text && text !== 'Your speech will appear here...') {
            navigator.clipboard.writeText(text).then(() => {
                this.showNotification('Transcript copied to clipboard!', 'success');
            });
        }
    }

    saveTranscriptToFile() {
        const text = this.transcriptContent.textContent;
        if (text && text !== 'Your speech will appear here...') {
            const blob = new Blob([text], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `transcript-${new Date().toISOString().slice(0, 19)}.txt`;
            a.click();
            URL.revokeObjectURL(url);
            this.showNotification('Transcript saved!', 'success');
        }
    }

    // Text-to-Speech Functions
    playTTSAudio() {
        const text = this.ttsInput.value.trim();
        if (!text) {
            this.showNotification('Please enter text to convert to speech', 'warning');
            return;
        }

        if (this.synthesis.speaking) {
            this.synthesis.cancel();
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = this.getSelectedVoice();
        utterance.rate = parseFloat(this.speedSlider.value);
        utterance.pitch = 1;
        utterance.volume = 1;

        utterance.onstart = () => {
            this.playTTS.disabled = true;
            this.pauseTTS.disabled = false;
            this.stopTTS.disabled = false;
        };

        utterance.onend = () => {
            this.playTTS.disabled = false;
            this.pauseTTS.disabled = true;
            this.stopTTS.disabled = true;
        };

        this.currentUtterance = utterance;
        this.synthesis.speak(utterance);
    }

    pauseTTSAudio() {
        if (this.synthesis.speaking) {
            this.synthesis.pause();
            this.playTTS.disabled = false;
            this.pauseTTS.disabled = true;
        }
    }

    stopTTSAudio() {
        if (this.synthesis.speaking) {
            this.synthesis.cancel();
            this.playTTS.disabled = false;
            this.pauseTTS.disabled = true;
            this.stopTTS.disabled = true;
        }
    }

    testTTSAudio() {
        const testText = "Hello! This is a test of the text-to-speech system. How does it sound?";
        this.ttsInput.value = testText;
        this.playTTSAudio();
    }

    getSelectedVoice() {
        const voices = this.synthesis.getVoices();
        const selectedVoice = this.voiceSelect.value;
        return voices.find(voice => voice.lang === selectedVoice) || voices[0];
    }

    updateVoiceSelection() {
        // Populate voice options
        const voices = this.synthesis.getVoices();
        this.voiceSelect.innerHTML = '';
        
        voices.forEach(voice => {
            const option = document.createElement('option');
            option.value = voice.lang;
            option.textContent = `${voice.name} (${voice.lang})`;
            this.voiceSelect.appendChild(option);
        });
    }

    // Analysis Functions
    analyzeSpeech(text) {
        // Simulate stress level analysis based on text content
        const stressKeywords = ['stress', 'anxious', 'worried', 'tired', 'exhausted', 'overwhelmed'];
        const positiveKeywords = ['happy', 'good', 'great', 'excellent', 'relaxed', 'calm'];
        
        const lowerText = text.toLowerCase();
        let stressScore = this.stressLevel;
        
        stressKeywords.forEach(keyword => {
            if (lowerText.includes(keyword)) {
                stressScore += 10;
            }
        });
        
        positiveKeywords.forEach(keyword => {
            if (lowerText.includes(keyword)) {
                stressScore -= 5;
            }
        });
        
        // Add some randomness to make it more realistic
        stressScore += (Math.random() - 0.5) * 20;
        stressScore = Math.max(0, Math.min(100, stressScore));
        
        this.updateStressLevel(stressScore);
        this.updateHealthMetrics();
        this.updateMoodInsight(stressScore);
    }

    updateStressLevel(level) {
        this.stressLevel = Math.round(level);
        this.stressLevelElement.textContent = this.stressLevel;
        
        // Update stress label
        let label = 'Low Stress';
        if (this.stressLevel > 70) label = 'High Stress';
        else if (this.stressLevel > 40) label = 'Moderate Stress';
        
        this.stressLabelElement.textContent = label;
        
        // Update progress ring
        const circumference = 2 * Math.PI * 52;
        const offset = circumference - (this.stressLevel / 100) * circumference;
        const progressRing = document.querySelector('.progress-ring-circle-fill');
        if (progressRing) {
            progressRing.style.strokeDashoffset = offset;
        }
    }

    updateHealthMetrics() {
        // Simulate health metrics based on stress level
        const baseHeartRate = 60 + (this.stressLevel * 0.3);
        const baseBreathingRate = 12 + (this.stressLevel * 0.08);
        
        this.heartRateElement.textContent = `${Math.round(baseHeartRate)} BPM`;
        this.breathingRateElement.textContent = `${Math.round(baseBreathingRate)}/min`;
        
        // Update voice pitch based on stress
        const pitchLevels = ['Low', 'Normal', 'High'];
        const pitchIndex = Math.floor(this.stressLevel / 33);
        this.voicePitchElement.textContent = pitchLevels[pitchIndex];
        
        // Update speaking pace
        const paceLevels = ['Slow', 'Moderate', 'Fast'];
        const paceIndex = Math.floor(this.stressLevel / 33);
        this.speakingPaceElement.textContent = paceLevels[paceIndex];
    }

    updateMoodInsight(stressLevel) {
        let insight = '';
        let icon = 'fas fa-lightbulb';
        
        if (stressLevel > 70) {
            insight = 'Your voice patterns indicate high stress levels. Consider taking a break and practicing deep breathing exercises.';
            icon = 'fas fa-exclamation-triangle';
        } else if (stressLevel > 40) {
            insight = 'Your voice patterns suggest you\'re feeling slightly anxious. Consider taking a few deep breaths.';
            icon = 'fas fa-lightbulb';
        } else {
            insight = 'Your voice patterns indicate a calm and relaxed state. Keep up the good work!';
            icon = 'fas fa-smile';
        }
        
        this.moodInsightElement.innerHTML = `
            <i class="${icon}"></i>
            <span>${insight}</span>
        `;
    }

    refreshAnalysisData() {
        // Simulate refreshing analysis data
        this.showNotification('Analysis data refreshed!', 'success');
        
        // Add some variation to the metrics
        const variation = (Math.random() - 0.5) * 10;
        this.updateStressLevel(this.stressLevel + variation);
        this.updateHealthMetrics();
    }

    // Settings Functions
    saveSettings() {
        const settings = {
            voiceNavigation: this.voiceNavToggle.checked,
            wakeWord: this.wakeWord.value,
            sensitivity: this.sensitivitySlider.value,
            autoTranscribe: this.autoTranscribeToggle.checked
        };
        
        localStorage.setItem('voiceAssistantSettings', JSON.stringify(settings));
        this.showNotification('Settings saved!', 'success');
    }

    loadSettings() {
        const savedSettings = localStorage.getItem('voiceAssistantSettings');
        if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            this.voiceNavToggle.checked = settings.voiceNavigation;
            this.wakeWord.value = settings.wakeWord;
            this.sensitivitySlider.value = settings.sensitivity;
            this.autoTranscribeToggle.checked = settings.autoTranscribe;
        }
    }

    // History Functions
    saveToHistory(transcript) {
        const conversation = {
            timestamp: new Date().toISOString(),
            transcript: transcript,
            duration: Math.floor(Math.random() * 300) + 60, // 1-6 minutes
            tags: this.extractTags(transcript)
        };
        
        this.transcriptHistory.unshift(conversation);
        
        // Keep only last 50 conversations
        if (this.transcriptHistory.length > 50) {
            this.transcriptHistory = this.transcriptHistory.slice(0, 50);
        }
        
        localStorage.setItem('voiceAssistantHistory', JSON.stringify(this.transcriptHistory));
    }

    extractTags(text) {
        const tags = [];
        const lowerText = text.toLowerCase();
        
        const tagKeywords = {
            'sleep': ['sleep', 'tired', 'insomnia', 'rest'],
            'fatigue': ['fatigue', 'exhausted', 'tired', 'energy'],
            'allergies': ['allergies', 'sneeze', 'itchy', 'pollen'],
            'symptoms': ['symptoms', 'pain', 'ache', 'fever'],
            'fitness': ['fitness', 'exercise', 'workout', 'gym'],
            'workout': ['workout', 'exercise', 'training', 'fitness']
        };
        
        Object.entries(tagKeywords).forEach(([tag, keywords]) => {
            if (keywords.some(keyword => lowerText.includes(keyword))) {
                tags.push(tag);
            }
        });
        
        return tags;
    }

    exportConversationHistory() {
        const history = this.transcriptHistory;
        if (history.length === 0) {
            this.showNotification('No conversation history to export', 'warning');
            return;
        }
        
        const csvContent = this.convertToCSV(history);
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `conversation-history-${new Date().toISOString().slice(0, 10)}.csv`;
        a.click();
        URL.revokeObjectURL(url);
        this.showNotification('Conversation history exported!', 'success');
    }

    convertToCSV(history) {
        const headers = ['Date', 'Time', 'Transcript', 'Duration (seconds)', 'Tags'];
        const rows = history.map(conv => {
            const date = new Date(conv.timestamp);
            return [
                date.toLocaleDateString(),
                date.toLocaleTimeString(),
                `"${conv.transcript}"`,
                conv.duration,
                conv.tags.join(', ')
            ];
        });
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }

    // UI Functions
    toggleSidebar() {
        this.sidebar.classList.toggle('open');
    }

    toggleTheme() {
        document.body.classList.toggle('dark-mode');
        const icon = this.themeToggle.querySelector('i');
        if (document.body.classList.contains('dark-mode')) {
            icon.className = 'fas fa-sun';
        } else {
            icon.className = 'fas fa-moon';
        }
    }

    handleKeyboardShortcuts(e) {
        // Space bar to toggle recording (when not in input fields)
        if (e.code === 'Space' && !e.target.matches('input, textarea')) {
            e.preventDefault();
            this.toggleRecording();
        }
        
        // Ctrl/Cmd + Enter to play TTS
        if ((e.ctrlKey || e.metaKey) && e.code === 'Enter') {
            e.preventDefault();
            this.playTTSAudio();
        }
    }

    handleResize() {
        if (window.innerWidth > 768) {
            this.sidebar.classList.remove('open');
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        if (type === 'success') {
            notification.style.background = '#4caf50';
        } else if (type === 'warning') {
            notification.style.background = '#ff9800';
        } else if (type === 'error') {
            notification.style.background = '#f44336';
        } else {
            notification.style.background = '#2196f3';
        }
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    startLoadingAnimation() {
        setTimeout(() => {
            this.loading.classList.add('hidden');
            setTimeout(() => {
                this.loading.style.display = 'none';
            }, 500);
        }, 2000);
    }
}

// Initialize the voice assistant when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const voiceAssistant = new VoiceAssistant();
    
    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}); 