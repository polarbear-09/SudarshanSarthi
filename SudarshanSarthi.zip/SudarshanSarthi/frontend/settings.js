// Settings Page JavaScript
class SettingsManager {
    constructor() {
        this.currentStoryStep = 1;
        this.totalStorySteps = 3;
        this.widgetOrder = [];
        this.settings = this.loadSettings();
        this.init();
    }

    init() {
        this.hideLoading();
        this.setupEventListeners();
        this.initializeWidgets();
        this.setupDragAndDrop();
        this.initializeCarousel();
        this.applySettings();
    }

    hideLoading() {
        setTimeout(() => {
            const loading = document.getElementById('loading');
            loading.classList.add('hidden');
            setTimeout(() => {
                loading.style.display = 'none';
            }, 300);
        }, 1000);
    }

    setupEventListeners() {
        // Theme controls
        document.getElementById('darkModeToggle').addEventListener('change', (e) => {
            this.toggleDarkMode(e.target.checked);
        });

        // Color pickers
        document.getElementById('primaryColor').addEventListener('input', (e) => {
            this.updatePrimaryColor(e.target.value);
        });

        document.getElementById('accentColor').addEventListener('input', (e) => {
            this.updateAccentColor(e.target.value);
        });

        // Language selector
        document.getElementById('languageSelect').addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });

        // Story mode toggle
        document.getElementById('storyModeToggle').addEventListener('change', (e) => {
            this.toggleStoryMode(e.target.checked);
        });

        // Widget toggles
        document.querySelectorAll('.widget-controls input[type="checkbox"]').forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                this.toggleWidget(e.target.closest('.widget-item').dataset.widget, e.target.checked);
            });
        });

        // Notification toggles
        document.querySelectorAll('.notification-item input[type="checkbox"]').forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                this.toggleNotification(e.target.closest('.notification-item').querySelector('label').textContent, e.target.checked);
            });
        });
    }

    initializeWidgets() {
        // Initialize widget order
        this.widgetOrder = Array.from(document.querySelectorAll('.widget-item')).map(item => item.dataset.widget);
        
        // Update widget badges
        this.updateWidgetBadges();
    }

    setupDragAndDrop() {
        const widgetList = document.getElementById('widgetList');
        const widgets = widgetList.querySelectorAll('.widget-item');

        widgets.forEach(widget => {
            widget.addEventListener('dragstart', (e) => {
                e.target.classList.add('dragging');
                e.dataTransfer.setData('text/plain', widget.dataset.widget);
            });

            widget.addEventListener('dragend', (e) => {
                e.target.classList.remove('dragging');
            });
        });

        widgetList.addEventListener('dragover', (e) => {
            e.preventDefault();
            const draggingElement = widgetList.querySelector('.dragging');
            const siblings = [...widgetList.querySelectorAll('.widget-item:not(.dragging)')];
            const nextSibling = siblings.find(sibling => {
                const box = sibling.getBoundingClientRect();
                const offset = e.clientY - box.top - box.height / 2;
                return offset < 0;
            });

            widgetList.insertBefore(draggingElement, nextSibling);
        });

        widgetList.addEventListener('drop', (e) => {
            e.preventDefault();
            this.updateWidgetOrder();
        });
    }

    updateWidgetOrder() {
        this.widgetOrder = Array.from(document.querySelectorAll('.widget-item')).map(item => item.dataset.widget);
        this.updateWidgetBadges();
        this.updateCarousel();
    }

    updateWidgetBadges() {
        const activeWidgets = document.querySelectorAll('.widget-controls input[type="checkbox"]:checked').length;
        const badge = document.querySelector('#widget-management .widget-badge');
        badge.textContent = `${activeWidgets} Active`;
    }

    initializeCarousel() {
        this.updateCarousel();
    }

    updateCarousel() {
        const carouselContent = document.getElementById('carouselContent');
        const indicators = document.getElementById('carouselIndicators');
        const activeWidgets = Array.from(document.querySelectorAll('.widget-controls input[type="checkbox"]:checked'))
            .map(toggle => toggle.closest('.widget-item').dataset.widget);

        if (activeWidgets.length === 0) {
            carouselContent.innerHTML = '<p>No widgets active</p>';
            indicators.innerHTML = '';
            return;
        }

        // Create carousel content
        carouselContent.innerHTML = activeWidgets.map(widget => {
            const widgetData = this.getWidgetPreviewData(widget);
            return `
                <div class="widget-preview-slide" data-widget="${widget}">
                    <i class="${widgetData.icon}"></i>
                    <h4>${widgetData.title}</h4>
                    <p>${widgetData.description}</p>
                    <div class="preview-stats">
                        <div class="stat">
                            <span class="stat-value">${widgetData.stat1.value}</span>
                            <span class="stat-label">${widgetData.stat1.label}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">${widgetData.stat2.value}</span>
                            <span class="stat-label">${widgetData.stat2.label}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Create indicators
        indicators.innerHTML = activeWidgets.map((_, index) => 
            `<div class="indicator ${index === 0 ? 'active' : ''}" onclick="settingsManager.goToSlide(${index})"></div>`
        ).join('');

        // Show first slide
        this.showSlide(0);
    }

    getWidgetPreviewData(widget) {
        const data = {
            'health-monitor': {
                icon: 'fas fa-heartbeat',
                title: 'Health Monitor',
                description: 'Track your health metrics and get AI-powered insights',
                stat1: { value: 'Low', label: 'Risk Level' },
                stat2: { value: '85%', label: 'Health Score' }
            },
            'outbreak-map': {
                icon: 'fas fa-map-marked-alt',
                title: 'Outbreak Map',
                description: 'Real-time outbreak tracking and risk assessment',
                stat1: { value: '1,234', label: 'Active Cases' },
                stat2: { value: '5', label: 'Hotspots' }
            },
            'voice-assistant': {
                icon: 'fas fa-microphone',
                title: 'Voice Assistant',
                description: 'AI-powered voice interaction and health guidance',
                stat1: { value: 'Ready', label: 'Status' },
                stat2: { value: '24/7', label: 'Availability' }
            },
            'notifications': {
                icon: 'fas fa-bell',
                title: 'Notifications',
                description: 'Stay informed with personalized health alerts',
                stat1: { value: '3', label: 'Unread' },
                stat2: { value: 'Daily', label: 'Frequency' }
            },
            'quick-actions': {
                icon: 'fas fa-bolt',
                title: 'Quick Actions',
                description: 'Fast access to common health tasks',
                stat1: { value: '5', label: 'Actions' },
                stat2: { value: '2s', label: 'Avg Time' }
            }
        };
        return data[widget] || data['health-monitor'];
    }

    showSlide(index) {
        const slides = document.querySelectorAll('.widget-preview-slide');
        const indicators = document.querySelectorAll('.indicator');

        slides.forEach((slide, i) => {
            slide.style.display = i === index ? 'flex' : 'none';
        });

        indicators.forEach((indicator, i) => {
            indicator.classList.toggle('active', i === index);
        });
    }

    goToSlide(index) {
        this.showSlide(index);
    }

    previousPreview() {
        const activeWidgets = document.querySelectorAll('.widget-controls input[type="checkbox"]:checked');
        const currentIndex = Array.from(document.querySelectorAll('.indicator')).findIndex(indicator => indicator.classList.contains('active'));
        const newIndex = currentIndex > 0 ? currentIndex - 1 : activeWidgets.length - 1;
        this.showSlide(newIndex);
    }

    nextPreview() {
        const activeWidgets = document.querySelectorAll('.widget-controls input[type="checkbox"]:checked');
        const currentIndex = Array.from(document.querySelectorAll('.indicator')).findIndex(indicator => indicator.classList.contains('active'));
        const newIndex = currentIndex < activeWidgets.length - 1 ? currentIndex + 1 : 0;
        this.showSlide(newIndex);
    }

    toggleDarkMode(enabled) {
        document.documentElement.setAttribute('data-theme', enabled ? 'dark' : 'light');
        this.settings.darkMode = enabled;
        this.saveSettings();
    }

    updatePrimaryColor(color) {
        document.documentElement.style.setProperty('--primary-color', color);
        document.getElementById('primaryPreview').style.backgroundColor = color;
        document.querySelector('#primaryColor + .color-preview + .color-value').textContent = color;
        this.settings.primaryColor = color;
    }

    updateAccentColor(color) {
        document.documentElement.style.setProperty('--accent-color', color);
        document.getElementById('accentPreview').style.backgroundColor = color;
        document.querySelector('#accentColor + .color-preview + .color-value').textContent = color;
        this.settings.accentColor = color;
    }

    async changeLanguage(language) {
        try {
            // Simulate API call
            await this.simulateApiCall();
            
            // Update UI
            const badge = document.querySelector('#language-widget .widget-badge');
            const languageNames = {
                'en': 'English',
                'hi': 'हिंदी',
                'es': 'Español',
                'fr': 'Français',
                'de': 'Deutsch',
                'zh': '中文',
                'ja': '日本語'
            };
            badge.textContent = languageNames[language] || 'English';
            
            this.settings.language = language;
            this.saveSettings();
            
            this.showToast('Language changed successfully!', 'success');
        } catch (error) {
            this.showToast('Failed to change language. Please try again.', 'error');
        }
    }

    toggleStoryMode(enabled) {
        this.settings.storyMode = enabled;
        this.saveSettings();
        
        if (enabled) {
            this.showToast('Story mode enabled! Click "Start Tour" to begin.', 'success');
        }
    }

    toggleWidget(widgetName, enabled) {
        this.settings.widgets[widgetName] = enabled;
        this.updateWidgetBadges();
        this.updateCarousel();
        this.saveSettings();
    }

    toggleNotification(notificationType, enabled) {
        this.settings.notifications[notificationType] = enabled;
        this.saveSettings();
    }

    startStoryMode() {
        this.currentStoryStep = 1;
        this.showStoryModal();
        this.updateStoryContent();
    }

    resetStoryMode() {
        this.settings.storyProgress = 0;
        this.saveSettings();
        this.showToast('Story mode progress reset!', 'success');
    }

    showStoryModal() {
        const modal = document.getElementById('storyModal');
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    closeStoryModal() {
        const modal = document.getElementById('storyModal');
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }

    updateStoryContent() {
        const content = document.getElementById('storyContent');
        const progress = document.getElementById('storyProgress');
        const currentStepSpan = document.getElementById('currentStep');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');

        const progressPercentage = (this.currentStoryStep / this.totalStorySteps) * 100;
        progress.style.width = `${progressPercentage}%`;
        currentStepSpan.textContent = this.currentStep;

        const storyData = [
            {
                icon: 'fas fa-heartbeat',
                title: 'Welcome to SudarshanSarthi',
                description: 'Your AI-powered health companion. Let\'s take a quick tour to help you get started with monitoring your health and staying informed about outbreaks.'
            },
            {
                icon: 'fas fa-map-marked-alt',
                title: 'Track Outbreaks',
                description: 'Use our interactive outbreak map to see real-time data about disease spread in your area. Get alerts about nearby hotspots and stay informed.'
            },
            {
                icon: 'fas fa-microphone',
                title: 'Voice Assistant',
                description: 'Interact with our AI voice assistant for health guidance, symptom checking, and quick access to health information. Just speak naturally!'
            }
        ];

        const currentData = storyData[this.currentStoryStep - 1];
        content.innerHTML = `
            <i class="${currentData.icon}"></i>
            <h3>${currentData.title}</h3>
            <p>${currentData.description}</p>
        `;

        // Update button states
        prevBtn.style.display = this.currentStep === 1 ? 'none' : 'flex';
        nextBtn.innerHTML = this.currentStep === this.totalStorySteps ? 
            'Finish <i class="fas fa-check"></i>' : 
            'Next <i class="fas fa-chevron-right"></i>';
    }

    previousStoryStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.updateStoryContent();
        }
    }

    nextStoryStep() {
        if (this.currentStep < this.totalStorySteps) {
            this.currentStep++;
            this.updateStoryContent();
        } else {
            this.completeStoryMode();
        }
    }

    completeStoryMode() {
        this.settings.storyProgress = 100;
        this.saveSettings();
        this.closeStoryModal();
        this.showToast('Welcome tour completed! You\'re all set to use SudarshanSarthi.', 'success');
    }

    async simulateApiCall() {
        return new Promise((resolve) => {
            setTimeout(resolve, 500);
        });
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('successToast');
        const toastContent = toast.querySelector('.toast-content span');
        
        toastContent.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    closeToast() {
        const toast = document.getElementById('successToast');
        toast.classList.remove('show');
    }

    loadSettings() {
        const defaultSettings = {
            darkMode: true,
            primaryColor: '#4F46E5',
            accentColor: '#10B981',
            language: 'en',
            region: 'IN',
            timezone: 'Asia/Kolkata',
            storyMode: false,
            storyProgress: 0,
            widgets: {
                'health-monitor': true,
                'outbreak-map': true,
                'voice-assistant': true,
                'notifications': true,
                'quick-actions': false
            },
            notifications: {
                'Health Alerts': true,
                'Outbreak Updates': true,
                'Voice Assistant': false,
                'Weekly Reports': true
            }
        };

        const saved = localStorage.getItem('sudarshanSarthiSettings');
        return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
    }

    saveSettings() {
        localStorage.setItem('sudarshanSarthiSettings', JSON.stringify(this.settings));
    }

    applySettings() {
        // Apply dark mode
        document.getElementById('darkModeToggle').checked = this.settings.darkMode;
        this.toggleDarkMode(this.settings.darkMode);

        // Apply colors
        document.getElementById('primaryColor').value = this.settings.primaryColor;
        document.getElementById('accentColor').value = this.settings.accentColor;
        this.updatePrimaryColor(this.settings.primaryColor);
        this.updateAccentColor(this.settings.accentColor);

        // Apply language
        document.getElementById('languageSelect').value = this.settings.language;
        this.changeLanguage(this.settings.language);

        // Apply story mode
        document.getElementById('storyModeToggle').checked = this.settings.storyMode;

        // Apply widget states
        Object.entries(this.settings.widgets).forEach(([widget, enabled]) => {
            const toggle = document.querySelector(`[data-widget="${widget}"] input[type="checkbox"]`);
            if (toggle) {
                toggle.checked = enabled;
            }
        });

        // Apply notification states
        Object.entries(this.settings.notifications).forEach(([notification, enabled]) => {
            const toggle = document.querySelector(`.notification-item:has(label:contains("${notification}")) input[type="checkbox"]`);
            if (toggle) {
                toggle.checked = enabled;
            }
        });

        this.updateWidgetBadges();
        this.updateCarousel();
    }
}

// Global functions for HTML onclick handlers
function goBack() {
    window.history.back();
}

function saveSettings() {
    settingsManager.saveSettings();
    settingsManager.showToast('Settings saved successfully!', 'success');
}

function startStoryMode() {
    settingsManager.startStoryMode();
}

function resetStoryMode() {
    settingsManager.resetStoryMode();
}

function closeStoryModal() {
    settingsManager.closeStoryModal();
}

function previousStoryStep() {
    settingsManager.previousStoryStep();
}

function nextStoryStep() {
    settingsManager.nextStoryStep();
}

function closeToast() {
    settingsManager.closeToast();
}

function previousPreview() {
    settingsManager.previousPreview();
}

function nextPreview() {
    settingsManager.nextPreview();
}

function changeLanguage() {
    const select = document.getElementById('languageSelect');
    settingsManager.changeLanguage(select.value);
}

// Initialize settings manager when DOM is loaded
let settingsManager;
document.addEventListener('DOMContentLoaded', () => {
    settingsManager = new SettingsManager();
});

// Close modal when clicking outside
document.addEventListener('click', (e) => {
    const modal = document.getElementById('storyModal');
    if (e.target === modal) {
        settingsManager.closeStoryModal();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        settingsManager.closeStoryModal();
        settingsManager.closeToast();
    }
    
    if (e.key === 'ArrowLeft' && document.getElementById('storyModal').classList.contains('show')) {
        settingsManager.previousStoryStep();
    }
    
    if (e.key === 'ArrowRight' && document.getElementById('storyModal').classList.contains('show')) {
        settingsManager.nextStoryStep();
    }
}); 