// Outbreak Map Application
class OutbreakMap {
    constructor() {
        this.gpsEnabled = false;
        this.userLocation = null;
        this.heatmapZones = [];
        this.charts = {};
        this.fakeNewsActive = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.initializeHeatmap();
        this.initializeCharts();
        this.setupFakeNewsDetection();
        this.hideLoading();
        this.startRealTimeUpdates();
    }
    
    setupEventListeners() {
        // GPS toggle
        document.getElementById('gps-toggle').addEventListener('click', () => {
            this.toggleGPS();
        });
        
        document.getElementById('enable-gps-btn').addEventListener('click', () => {
            this.toggleGPS();
        });
        
        // Fullscreen toggle
        document.getElementById('fullscreen-toggle').addEventListener('click', () => {
            this.toggleFullscreen();
        });
        
        // Refresh map
        document.getElementById('refresh-map').addEventListener('click', () => {
            this.refreshMap();
        });
        
        // Report button
        document.getElementById('report-btn').addEventListener('click', () => {
            this.showReportModal();
        });
        
        // Modal controls
        document.getElementById('modal-close').addEventListener('click', () => {
            this.hideReportModal();
        });
        
        document.getElementById('cancel-report').addEventListener('click', () => {
            this.hideReportModal();
        });
        
        // Report form
        document.getElementById('report-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitReport();
        });
        
        // Fake news banner close
        document.getElementById('banner-close').addEventListener('click', () => {
            this.hideFakeNewsBanner();
        });
        
        // Zoom controls
        document.getElementById('zoom-in').addEventListener('click', () => {
            this.zoomMap(1.2);
        });
        
        document.getElementById('zoom-out').addEventListener('click', () => {
            this.zoomMap(0.8);
        });
        
        // Layer toggles
        document.getElementById('heatmap-layer').addEventListener('change', (e) => {
            this.toggleLayer('heatmap', e.target.checked);
        });
        
        document.getElementById('cases-layer').addEventListener('change', (e) => {
            this.toggleLayer('cases', e.target.checked);
        });
        
        document.getElementById('mobility-layer').addEventListener('change', (e) => {
            this.toggleLayer('mobility', e.target.checked);
        });
        
        // Close modal when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.hideReportModal();
            }
        });
    }
    
    initializeHeatmap() {
        const heatmapOverlay = document.getElementById('heatmap-overlay');
        
        // Create sample heatmap zones
        this.heatmapZones = [
            { x: 20, y: 30, radius: 80, risk: 'high', disease: 'COVID-19' },
            { x: 60, y: 20, radius: 60, risk: 'medium', disease: 'Flu' },
            { x: 80, y: 70, radius: 100, risk: 'critical', disease: 'Dengue' },
            { x: 30, y: 80, radius: 50, risk: 'low', disease: 'Allergies' },
            { x: 70, y: 50, radius: 70, risk: 'high', disease: 'COVID-19' }
        ];
        
        this.heatmapZones.forEach(zone => {
            const zoneElement = document.createElement('div');
            zoneElement.className = `heatmap-zone ${zone.risk}`;
            zoneElement.style.left = `${zone.x}%`;
            zoneElement.style.top = `${zone.y}%`;
            zoneElement.style.width = `${zone.radius}px`;
            zoneElement.style.height = `${zone.radius}px`;
            zoneElement.style.marginLeft = `-${zone.radius / 2}px`;
            zoneElement.style.marginTop = `-${zone.radius / 2}px`;
            
            // Add tooltip
            zoneElement.title = `${zone.disease} - ${zone.risk} risk zone`;
            
            // Add click event
            zoneElement.addEventListener('click', () => {
                this.showZoneDetails(zone);
            });
            
            heatmapOverlay.appendChild(zoneElement);
        });
    }
    
    initializeCharts() {
        // Air Travel Chart
        const airCtx = document.getElementById('air-travel-chart').getContext('2d');
        this.charts.airTravel = new Chart(airCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Flight Volume',
                    data: [120, 145, 132, 167, 189, 156, 134],
                    borderColor: '#e63946',
                    backgroundColor: 'rgba(230, 57, 70, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { display: false },
                    x: { display: false }
                },
                elements: {
                    point: { radius: 0 }
                }
            }
        });
        
        // Transport Chart
        const transportCtx = document.getElementById('transport-chart').getContext('2d');
        this.charts.transport = new Chart(transportCtx, {
            type: 'doughnut',
            data: {
                labels: ['Buses', 'Trains', 'Subway'],
                datasets: [{
                    data: [45, 30, 25],
                    backgroundColor: ['#ffb703', '#0077b6', '#52b788']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });
        
        // Shopping Chart
        const shoppingCtx = document.getElementById('shopping-chart').getContext('2d');
        this.charts.shopping = new Chart(shoppingCtx, {
            type: 'bar',
            data: {
                labels: ['Mall A', 'Mall B', 'Mall C', 'Mall D'],
                datasets: [{
                    label: 'Visitors',
                    data: [12000, 8900, 15600, 7800],
                    backgroundColor: '#48cae4'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { display: false },
                    x: { display: false }
                }
            }
        });
        
        // Density Chart
        const densityCtx = document.getElementById('density-chart').getContext('2d');
        this.charts.density = new Chart(densityCtx, {
            type: 'line',
            data: {
                labels: ['6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
                datasets: [{
                    label: 'Population Density',
                    data: [20, 85, 45, 60, 90, 30],
                    borderColor: '#0077b6',
                    backgroundColor: 'rgba(0, 119, 182, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { display: false },
                    x: { display: false }
                },
                elements: {
                    point: { radius: 0 }
                }
            }
        });
    }
    
    setupFakeNewsDetection() {
        // Simulate fake news detection
        setInterval(() => {
            if (Math.random() < 0.1) { // 10% chance every interval
                this.showFakeNewsBanner();
            }
        }, 30000); // Check every 30 seconds
    }
    
    showFakeNewsBanner() {
        if (!this.fakeNewsActive) {
            this.fakeNewsActive = true;
            document.getElementById('fake-news-banner').classList.add('show');
            
            // Auto-hide after 10 seconds
            setTimeout(() => {
                this.hideFakeNewsBanner();
            }, 10000);
        }
    }
    
    hideFakeNewsBanner() {
        this.fakeNewsActive = false;
        document.getElementById('fake-news-banner').classList.remove('show');
    }
    
    toggleGPS() {
        if (this.gpsEnabled) {
            this.disableGPS();
        } else {
            this.enableGPS();
        }
    }
    
    enableGPS() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    this.gpsEnabled = true;
                    this.updateGPSStatus(true);
                    this.updateDangerRadius();
                    this.showNotification('GPS enabled successfully!', 'success');
                },
                (error) => {
                    console.error('GPS Error:', error);
                    this.showNotification('Failed to enable GPS. Please check permissions.', 'error');
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        } else {
            this.showNotification('GPS not available on this device.', 'error');
        }
    }
    
    disableGPS() {
        this.gpsEnabled = false;
        this.userLocation = null;
        this.updateGPSStatus(false);
        this.showNotification('GPS disabled.', 'info');
    }
    
    updateGPSStatus(enabled) {
        const gpsToggle = document.getElementById('gps-toggle');
        const gpsStatus = document.getElementById('gps-status');
        const enableGpsBtn = document.getElementById('enable-gps-btn');
        
        if (enabled) {
            gpsToggle.classList.add('active');
            gpsStatus.classList.add('active');
            gpsStatus.innerHTML = '<i class="fas fa-circle"></i><span>GPS Active</span>';
            enableGpsBtn.innerHTML = '<i class="fas fa-location-slash"></i><span>Disable GPS</span>';
        } else {
            gpsToggle.classList.remove('active');
            gpsStatus.classList.remove('active');
            gpsStatus.innerHTML = '<i class="fas fa-circle"></i><span>GPS Disabled</span>';
            enableGpsBtn.innerHTML = '<i class="fas fa-location-arrow"></i><span>Enable GPS</span>';
        }
    }
    
    updateDangerRadius() {
        if (!this.userLocation) return;
        
        // Simulate proximity alerts based on user location
        const alerts = [
            {
                type: 'warning',
                title: 'High Risk Zone Nearby',
                message: 'You are within 2km of a confirmed outbreak zone',
                distance: '1.8km away'
            },
            {
                type: 'info',
                title: 'Testing Center Available',
                message: 'Free COVID-19 testing available at City Hospital',
                distance: '3.2km away'
            }
        ];
        
        this.updateProximityAlerts(alerts);
    }
    
    updateProximityAlerts(alerts) {
        const alertList = document.querySelector('.alert-list');
        alertList.innerHTML = '';
        
        alerts.forEach(alert => {
            const alertItem = document.createElement('div');
            alertItem.className = `alert-item ${alert.type}`;
            alertItem.innerHTML = `
                <div class="alert-icon ${alert.type}">
                    <i class="fas fa-${alert.type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
                </div>
                <div class="alert-content">
                    <h4>${alert.title}</h4>
                    <p>${alert.message}</p>
                    <span class="alert-distance">${alert.distance}</span>
                </div>
            `;
            alertList.appendChild(alertItem);
        });
    }
    
    toggleFullscreen() {
        const mapContainer = document.querySelector('.map-container');
        
        if (!document.fullscreenElement) {
            mapContainer.requestFullscreen().catch(err => {
                console.error('Error attempting to enable fullscreen:', err);
            });
        } else {
            document.exitFullscreen();
        }
    }
    
    refreshMap() {
        const refreshBtn = document.getElementById('refresh-map');
        refreshBtn.classList.add('loading');
        
        // Simulate map refresh
        setTimeout(() => {
            this.updateMapData();
            refreshBtn.classList.remove('loading');
            this.showNotification('Map data refreshed!', 'success');
        }, 2000);
    }
    
    updateMapData() {
        // Update heatmap zones with new data
        this.heatmapZones.forEach((zone, index) => {
            // Simulate data changes
            zone.radius += Math.random() * 20 - 10;
            zone.radius = Math.max(30, Math.min(120, zone.radius));
            
            const zoneElement = document.querySelectorAll('.heatmap-zone')[index];
            if (zoneElement) {
                zoneElement.style.width = `${zone.radius}px`;
                zoneElement.style.height = `${zone.radius}px`;
                zoneElement.style.marginLeft = `-${zone.radius / 2}px`;
                zoneElement.style.marginTop = `-${zone.radius / 2}px`;
            }
        });
        
        // Update charts
        Object.values(this.charts).forEach(chart => {
            chart.data.datasets[0].data = chart.data.datasets[0].data.map(() => 
                Math.floor(Math.random() * 200) + 50
            );
            chart.update();
        });
    }
    
    zoomMap(factor) {
        const mapImage = document.querySelector('.map-image');
        const currentScale = mapImage.style.transform.match(/scale\(([^)]+)\)/) || [null, 1];
        const newScale = parseFloat(currentScale[1]) * factor;
        
        // Limit zoom range
        const limitedScale = Math.max(0.5, Math.min(3, newScale));
        mapImage.style.transform = `scale(${limitedScale})`;
    }
    
    toggleLayer(layer, visible) {
        const heatmapOverlay = document.getElementById('heatmap-overlay');
        
        switch (layer) {
            case 'heatmap':
                heatmapOverlay.style.opacity = visible ? '1' : '0';
                break;
            case 'cases':
                // Toggle case markers
                this.toggleCaseMarkers(visible);
                break;
            case 'mobility':
                // Toggle mobility data
                this.toggleMobilityData(visible);
                break;
        }
    }
    
    toggleCaseMarkers(visible) {
        // Simulate case markers
        console.log(`Case markers ${visible ? 'shown' : 'hidden'}`);
    }
    
    toggleMobilityData(visible) {
        // Simulate mobility data
        console.log(`Mobility data ${visible ? 'shown' : 'hidden'}`);
    }
    
    showZoneDetails(zone) {
        const details = {
            'COVID-19': {
                cases: Math.floor(Math.random() * 1000) + 100,
                trend: 'increasing',
                recommendations: [
                    'Wear masks in public',
                    'Maintain social distance',
                    'Get vaccinated',
                    'Monitor symptoms'
                ]
            },
            'Flu': {
                cases: Math.floor(Math.random() * 500) + 50,
                trend: 'stable',
                recommendations: [
                    'Get flu shot',
                    'Wash hands frequently',
                    'Stay home if sick',
                    'Cover coughs and sneezes'
                ]
            },
            'Dengue': {
                cases: Math.floor(Math.random() * 200) + 20,
                trend: 'increasing',
                recommendations: [
                    'Use mosquito repellent',
                    'Eliminate standing water',
                    'Wear long sleeves',
                    'Use mosquito nets'
                ]
            },
            'Allergies': {
                cases: Math.floor(Math.random() * 300) + 30,
                trend: 'decreasing',
                recommendations: [
                    'Monitor pollen counts',
                    'Take antihistamines',
                    'Keep windows closed',
                    'Use air purifiers'
                ]
            }
        };
        
        const detail = details[zone.disease];
        if (detail) {
            this.showZoneModal(zone, detail);
        }
    }
    
    showZoneModal(zone, detail) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${zone.disease} Outbreak Zone</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="zone-details">
                        <div class="detail-item">
                            <span class="label">Risk Level:</span>
                            <span class="value ${zone.risk}">${zone.risk.toUpperCase()}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Active Cases:</span>
                            <span class="value">${detail.cases}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Trend:</span>
                            <span class="value ${detail.trend}">${detail.trend}</span>
                        </div>
                    </div>
                    <h4>Recommendations:</h4>
                    <ul>
                        ${detail.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add modal styles if not already present
        if (!document.getElementById('zone-modal-styles')) {
            const modalStyles = `
                .zone-details {
                    margin-bottom: var(--spacing-lg);
                }
                
                .detail-item {
                    display: flex;
                    justify-content: space-between;
                    padding: var(--spacing-sm) 0;
                    border-bottom: 1px solid var(--border-light);
                }
                
                .detail-item:last-child {
                    border-bottom: none;
                }
                
                .detail-item .label {
                    font-weight: 500;
                    color: var(--text-secondary);
                }
                
                .detail-item .value {
                    font-weight: 600;
                    color: var(--text-primary);
                }
                
                .detail-item .value.high {
                    color: var(--error-color);
                }
                
                .detail-item .value.medium {
                    color: var(--warning-color);
                }
                
                .detail-item .value.low {
                    color: var(--success-color);
                }
                
                .detail-item .value.increasing {
                    color: var(--error-color);
                }
                
                .detail-item .value.stable {
                    color: var(--warning-color);
                }
                
                .detail-item .value.decreasing {
                    color: var(--success-color);
                }
            `;
            
            const style = document.createElement('style');
            style.id = 'zone-modal-styles';
            style.textContent = modalStyles;
            document.head.appendChild(style);
        }
        
        // Close modal functionality
        modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.classList.contains('modal-close')) {
                modal.remove();
            }
        });
        
        setTimeout(() => modal.classList.add('show'), 10);
    }
    
    showReportModal() {
        const modal = document.getElementById('report-modal');
        modal.classList.add('show');
        
        // Set default date to today
        document.getElementById('case-date').value = new Date().toISOString().split('T')[0];
    }
    
    hideReportModal() {
        const modal = document.getElementById('report-modal');
        modal.classList.remove('show');
        
        // Reset form
        document.getElementById('report-form').reset();
    }
    
    submitReport() {
        const formData = {
            type: document.getElementById('case-type').value,
            location: document.getElementById('case-location').value,
            date: document.getElementById('case-date').value,
            description: document.getElementById('case-description').value,
            contact: document.getElementById('contact-info').value
        };
        
        // Validate required fields
        if (!formData.type || !formData.location || !formData.date) {
            this.showNotification('Please fill in all required fields.', 'error');
            return;
        }
        
        // Simulate API call
        console.log('Submitting report:', formData);
        
        // Show success message
        this.showNotification('Report submitted successfully! Thank you for helping keep the community safe.', 'success');
        
        // Hide modal
        this.hideReportModal();
        
        // Update map with new case
        this.addNewCaseToMap(formData);
    }
    
    addNewCaseToMap(caseData) {
        // Add new heatmap zone for the reported case
        const newZone = {
            x: Math.random() * 80 + 10, // Random position
            y: Math.random() * 80 + 10,
            radius: 40,
            risk: 'medium',
            disease: caseData.type
        };
        
        this.heatmapZones.push(newZone);
        
        // Create new zone element
        const heatmapOverlay = document.getElementById('heatmap-overlay');
        const zoneElement = document.createElement('div');
        zoneElement.className = `heatmap-zone ${newZone.risk}`;
        zoneElement.style.left = `${newZone.x}%`;
        zoneElement.style.top = `${newZone.y}%`;
        zoneElement.style.width = `${newZone.radius}px`;
        zoneElement.style.height = `${newZone.radius}px`;
        zoneElement.style.marginLeft = `-${newZone.radius / 2}px`;
        zoneElement.style.marginTop = `-${newZone.radius / 2}px`;
        zoneElement.title = `Reported ${caseData.type} case`;
        
        heatmapOverlay.appendChild(zoneElement);
        
        // Animate the new zone
        zoneElement.style.animation = 'heatmapPulse 1s ease-in-out 3';
    }
    
    startRealTimeUpdates() {
        // Update map data every 30 seconds
        setInterval(() => {
            this.updateMapData();
        }, 30000);
        
        // Update GPS location every minute if enabled
        setInterval(() => {
            if (this.gpsEnabled) {
                this.updateGPSLocation();
            }
        }, 60000);
    }
    
    updateGPSLocation() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    this.updateDangerRadius();
                },
                (error) => {
                    console.error('GPS update error:', error);
                }
            );
        }
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification-toast ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
    
    showLoading() {
        document.getElementById('loading-overlay').classList.add('show');
    }
    
    hideLoading() {
        setTimeout(() => {
            document.getElementById('loading-overlay').classList.remove('show');
        }, 1000);
    }
}

// Initialize Outbreak Map when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const outbreakMap = new OutbreakMap();
    
    // Add notification styles
    const notificationStyles = `
        .notification-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            padding: var(--spacing-md);
            box-shadow: var(--shadow-dropdown);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform var(--transition-normal);
        }
        
        .notification-toast.show {
            transform: translateX(0);
        }
        
        .notification-toast.success {
            border-left: 4px solid var(--success-color);
        }
        
        .notification-toast.error {
            border-left: 4px solid var(--error-color);
        }
        
        .notification-toast.warning {
            border-left: 4px solid var(--warning-color);
        }
        
        .notification-toast.info {
            border-left: 4px solid var(--info-color);
        }
        
        .notification-toast i {
            color: var(--success-color);
        }
        
        .notification-toast.error i {
            color: var(--error-color);
        }
        
        .notification-toast.warning i {
            color: var(--warning-color);
        }
        
        .notification-toast.info i {
            color: var(--info-color);
        }
    `;
    
    const style = document.createElement('style');
    style.textContent = notificationStyles;
    document.head.appendChild(style);
}); 