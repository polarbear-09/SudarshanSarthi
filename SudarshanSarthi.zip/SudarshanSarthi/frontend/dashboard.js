// Dashboard Application
class DashboardApp {
    constructor() {
        this.currentPage = 'home';
        this.currentTheme = localStorage.getItem('theme') || 'light';
        this.currentLanguage = localStorage.getItem('language') || 'en';
        this.isLoading = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.loadTheme();
        this.loadLanguage();
        this.setupRouting();
        this.updateWelcomeMessage();
        this.animateStats();
    }
    
    setupEventListeners() {
        // Sidebar toggle
        document.getElementById('sidebar-toggle').addEventListener('click', () => {
            this.toggleSidebar();
        });
        
        // Mobile menu toggle
        document.getElementById('mobile-menu-toggle').addEventListener('click', () => {
            this.toggleMobileMenu();
        });
        
        // Theme toggle
        document.getElementById('theme-toggle').addEventListener('click', () => {
            this.toggleTheme();
        });
        
        // Language selector
        document.getElementById('language-toggle').addEventListener('click', () => {
            this.toggleLanguageDropdown();
        });
        
        // Notification toggle
        document.getElementById('notification-toggle').addEventListener('click', () => {
            this.toggleNotificationDropdown();
        });
        
        // Profile toggle
        document.getElementById('profile-toggle').addEventListener('click', () => {
            this.toggleProfileDropdown();
        });
        
        // Voice assistant
        document.getElementById('voice-btn').addEventListener('click', () => {
            this.toggleVoiceAssistant();
        });
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            this.handleOutsideClick(e);
        });
        
        // Language options
        document.querySelectorAll('.language-option').forEach(option => {
            option.addEventListener('click', () => {
                this.changeLanguage(option.dataset.lang);
            });
        });
        
        // Mark all notifications as read
        document.querySelector('.mark-all-read').addEventListener('click', () => {
            this.markAllNotificationsRead();
        });
    }
    
    setupRouting() {
        // Navigation links - only handle internal routing for dashboard pages
        document.querySelectorAll('.nav-link[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                this.navigateToPage(page);
            });
        });
        
        // Handle browser back/forward
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.page) {
                this.loadPage(e.state.page, false);
            }
        });
        
        // Initial page load
        const hash = window.location.hash.slice(1) || 'home';
        this.navigateToPage(hash, false);
    }
    
    navigateToPage(page, updateHistory = true) {
        if (this.isLoading || page === this.currentPage) return;
        
        this.showLoading();
        
        setTimeout(() => {
            this.loadPage(page, updateHistory);
            this.hideLoading();
        }, 300);
    }
    
    loadPage(page, updateHistory = true) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => {
            p.style.display = 'none';
        });
        
        // Show target page
        const targetPage = document.getElementById(`${page}-page`);
        if (targetPage) {
            targetPage.style.display = 'block';
            this.currentPage = page;
            
            // Update active nav link
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            document.querySelector(`[data-page="${page}"]`).classList.add('active');
            
            // Update breadcrumb
            document.getElementById('current-page').textContent = this.getPageTitle(page);
            
            // Update URL
            if (updateHistory) {
                window.history.pushState({ page }, '', `#${page}`);
            }
            
            // Page-specific initialization
            this.initializePage(page);
        }
    }
    
    getPageTitle(page) {
        const titles = {
            'home': 'Home',
            'health-monitor': 'Health Monitor',
            'outbreak-map': 'Outbreak Map',
            'voice-assistant': 'Voice Assistant',
            'settings': 'Settings'
        };
        return titles[page] || 'Home';
    }
    
    initializePage(page) {
        switch (page) {
            case 'home':
                this.animateStats();
                break;
            case 'health-monitor':
                this.initializeHealthMonitor();
                break;
            case 'outbreak-map':
                this.initializeOutbreakMap();
                break;
            case 'voice-assistant':
                this.initializeVoiceAssistant();
                break;
            case 'settings':
                this.initializeSettings();
                break;
        }
    }
    
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('collapsed');
        
        // Save preference
        const isCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', isCollapsed);
    }
    
    toggleMobileMenu() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('show');
    }
    
    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.loadTheme();
        
        // Update theme from API
        this.updateThemeFromAPI();
    }
    
    loadTheme() {
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        localStorage.setItem('theme', this.currentTheme);
        
        // Update theme toggle icon
        const themeIcon = document.querySelector('#theme-toggle i');
        themeIcon.className = this.currentTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    async updateThemeFromAPI() {
        try {
            await fetch('/api/theme', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ theme: this.currentTheme })
            });
        } catch (error) {
            console.log('Theme API not available, using local storage only');
        }
    }
    
    toggleLanguageDropdown() {
        const dropdown = document.getElementById('language-dropdown');
        dropdown.classList.toggle('show');
        
        // Close other dropdowns
        this.closeOtherDropdowns('language-dropdown');
    }
    
    toggleNotificationDropdown() {
        const dropdown = document.getElementById('notification-dropdown');
        dropdown.classList.toggle('show');
        
        // Close other dropdowns
        this.closeOtherDropdowns('notification-dropdown');
    }
    
    toggleProfileDropdown() {
        const dropdown = document.getElementById('profile-dropdown');
        dropdown.classList.toggle('show');
        
        // Close other dropdowns
        this.closeOtherDropdowns('profile-dropdown');
    }
    
    closeOtherDropdowns(currentDropdown) {
        const dropdowns = ['language-dropdown', 'notification-dropdown', 'profile-dropdown'];
        dropdowns.forEach(id => {
            if (id !== currentDropdown) {
                document.getElementById(id).classList.remove('show');
            }
        });
    }
    
    handleOutsideClick(e) {
        const dropdowns = ['language-dropdown', 'notification-dropdown', 'profile-dropdown'];
        dropdowns.forEach(id => {
            const dropdown = document.getElementById(id);
            const toggle = document.getElementById(id.replace('-dropdown', '-toggle'));
            
            if (!dropdown.contains(e.target) && !toggle.contains(e.target)) {
                dropdown.classList.remove('show');
            }
        });
    }
    
    changeLanguage(lang) {
        this.currentLanguage = lang;
        localStorage.setItem('language', lang);
        
        // Update UI
        const languageToggle = document.getElementById('language-toggle');
        const flagIcon = languageToggle.querySelector('.flag-icon');
        const languageText = languageToggle.querySelector('.language-text');
        
        const languages = {
            'en': { flag: '🇺🇸', text: 'EN' },
            'es': { flag: '🇪🇸', text: 'ES' },
            'fr': { flag: '🇫🇷', text: 'FR' },
            'de': { flag: '🇩🇪', text: 'DE' },
            'hi': { flag: '🇮🇳', text: 'HI' }
        };
        
        flagIcon.textContent = languages[lang].flag;
        languageText.textContent = languages[lang].text;
        
        // Close dropdown
        document.getElementById('language-dropdown').classList.remove('show');
        
        // Update content (in a real app, this would load translations)
        this.updateContentLanguage(lang);
    }
    
    updateContentLanguage(lang) {
        // This would typically load translation files
        console.log(`Language changed to: ${lang}`);
        
        // Update welcome message based on language
        this.updateWelcomeMessage();
    }
    
    updateWelcomeMessage() {
        const now = new Date();
        const hour = now.getHours();
        const userName = 'Dr. Sarah Chen';
        
        let greeting;
        if (hour < 12) {
            greeting = this.currentLanguage === 'es' ? '¡Buenos días' : 
                      this.currentLanguage === 'fr' ? 'Bonjour' :
                      this.currentLanguage === 'de' ? 'Guten Morgen' :
                      this.currentLanguage === 'hi' ? 'सुप्रभात' : 'Good morning';
        } else if (hour < 18) {
            greeting = this.currentLanguage === 'es' ? '¡Buenas tardes' :
                      this.currentLanguage === 'fr' ? 'Bon après-midi' :
                      this.currentLanguage === 'de' ? 'Guten Tag' :
                      this.currentLanguage === 'hi' ? 'नमस्कार' : 'Good afternoon';
        } else {
            greeting = this.currentLanguage === 'es' ? '¡Buenas noches' :
                      this.currentLanguage === 'fr' ? 'Bonsoir' :
                      this.currentLanguage === 'de' ? 'Guten Abend' :
                      this.currentLanguage === 'hi' ? 'शुभ संध्या' : 'Good evening';
        }
        
        const welcomeMessage = document.getElementById('welcome-message');
        welcomeMessage.textContent = `${greeting}, ${userName}!`;
        
        // Update date
        const dateOptions = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        const dateString = now.toLocaleDateString(this.getLocaleFromLang(), dateOptions);
        document.getElementById('welcome-date').textContent = `Today is ${dateString}`;
    }
    
    getLocaleFromLang() {
        const locales = {
            'en': 'en-US',
            'es': 'es-ES',
            'fr': 'fr-FR',
            'de': 'de-DE',
            'hi': 'hi-IN'
        };
        return locales[this.currentLanguage] || 'en-US';
    }
    
    markAllNotificationsRead() {
        document.querySelectorAll('.notification-item').forEach(item => {
            item.classList.remove('unread');
        });
        
        // Hide notification badge
        const badge = document.querySelector('.notification-badge');
        if (badge) {
            badge.style.display = 'none';
        }
        
        // Close dropdown
        document.getElementById('notification-dropdown').classList.remove('show');
    }
    
    toggleVoiceAssistant() {
        const voiceBtn = document.getElementById('voice-btn');
        const voiceStatus = document.querySelector('.voice-status');
        
        if (voiceBtn.classList.contains('recording')) {
            // Stop recording
            voiceBtn.classList.remove('recording');
            voiceStatus.textContent = 'Click to start voice assistant';
            this.stopVoiceRecording();
        } else {
            // Start recording
            voiceBtn.classList.add('recording');
            voiceStatus.textContent = 'Listening... Click to stop';
            this.startVoiceRecording();
        }
    }
    
    startVoiceRecording() {
        // Simulate voice recording
        console.log('Voice recording started');
        
        // In a real app, this would use the Web Speech API
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            // Initialize speech recognition
            console.log('Speech recognition available');
        }
    }
    
    stopVoiceRecording() {
        console.log('Voice recording stopped');
        // Process recorded audio and generate response
    }
    
    showLoading() {
        this.isLoading = true;
        document.getElementById('loading-overlay').classList.add('show');
    }
    
    hideLoading() {
        this.isLoading = false;
        document.getElementById('loading-overlay').classList.remove('show');
    }
    
    animateStats() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(stat => {
            const finalValue = stat.textContent;
            const isPercentage = finalValue.includes('%');
            const isTime = finalValue.includes('/');
            const isNumber = !isNaN(parseInt(finalValue));
            
            if (isNumber) {
                const target = parseInt(finalValue);
                this.animateNumber(stat, 0, target, 2000);
            } else if (isPercentage) {
                const target = parseFloat(finalValue);
                this.animateNumber(stat, 0, target, 2000, '%');
            } else if (isTime) {
                // For time values like "24/7", just fade in
                stat.style.opacity = '0';
                setTimeout(() => {
                    stat.style.transition = 'opacity 0.5s ease';
                    stat.style.opacity = '1';
                }, 500);
            }
        });
    }
    
    animateNumber(element, start, end, duration, suffix = '') {
        const startTime = performance.now();
        
        const updateNumber = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function
            const easeOutQuart = 1 - Math.pow(1 - progress, 4);
            const current = Math.floor(start + (end - start) * easeOutQuart);
            
            element.textContent = current + suffix;
            
            if (progress < 1) {
                requestAnimationFrame(updateNumber);
            }
        };
        
        requestAnimationFrame(updateNumber);
    }
    
    initializeHealthMonitor() {
        // Initialize health monitoring features
        console.log('Health Monitor initialized');
        
        // Simulate real-time data updates
        this.startHealthDataSimulation();
    }
    
    startHealthDataSimulation() {
        setInterval(() => {
            // Update vital signs with realistic variations
            const vitalValues = document.querySelectorAll('.vital-value');
            if (vitalValues.length > 0) {
                const heartRate = Math.floor(Math.random() * 20) + 65; // 65-85 BPM
                const systolic = Math.floor(Math.random() * 20) + 110; // 110-130
                const diastolic = Math.floor(Math.random() * 10) + 70; // 70-80
                const temp = (Math.random() * 2 + 97.5).toFixed(1); // 97.5-99.5°F
                const oxygen = Math.floor(Math.random() * 3) + 96; // 96-99%
                
                vitalValues[0].textContent = `${heartRate} BPM`;
                vitalValues[1].textContent = `${systolic}/${diastolic}`;
                vitalValues[2].textContent = `${temp}°F`;
                vitalValues[3].textContent = `${oxygen}%`;
            }
        }, 5000); // Update every 5 seconds
    }
    
    initializeOutbreakMap() {
        // Initialize map visualization
        console.log('Outbreak Map initialized');
        
        // In a real app, this would initialize a map library like Leaflet or Google Maps
        // For now, we'll just show the placeholder
    }
    
    initializeVoiceAssistant() {
        // Initialize voice assistant features
        console.log('Voice Assistant initialized');
        
        // Reset voice button state
        const voiceBtn = document.getElementById('voice-btn');
        const voiceStatus = document.querySelector('.voice-status');
        
        voiceBtn.classList.remove('recording');
        voiceStatus.textContent = 'Click to start voice assistant';
    }
    
    initializeSettings() {
        // Load current settings
        const themeSelect = document.getElementById('theme-select');
        const languageSelect = document.getElementById('language-select');
        const emailNotifications = document.getElementById('email-notifications');
        const pushNotifications = document.getElementById('push-notifications');
        const alertFrequency = document.getElementById('alert-frequency');
        
        // Set current values
        themeSelect.value = this.currentTheme;
        languageSelect.value = this.currentLanguage;
        
        // Load saved preferences
        emailNotifications.checked = localStorage.getItem('emailNotifications') !== 'false';
        pushNotifications.checked = localStorage.getItem('pushNotifications') !== 'false';
        alertFrequency.value = localStorage.getItem('alertFrequency') || 'immediate';
        
        // Add event listeners for settings changes
        themeSelect.addEventListener('change', (e) => {
            this.currentTheme = e.target.value;
            this.loadTheme();
        });
        
        languageSelect.addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });
        
        emailNotifications.addEventListener('change', (e) => {
            localStorage.setItem('emailNotifications', e.target.checked);
        });
        
        pushNotifications.addEventListener('change', (e) => {
            localStorage.setItem('pushNotifications', e.target.checked);
        });
        
        alertFrequency.addEventListener('change', (e) => {
            localStorage.setItem('alertFrequency', e.target.value);
        });
    }
    
    loadLanguage() {
        // Load saved language preference
        const savedLanguage = localStorage.getItem('language');
        if (savedLanguage) {
            this.changeLanguage(savedLanguage);
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new DashboardApp();
    
    // Load saved sidebar state
    const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (sidebarCollapsed) {
        document.getElementById('sidebar').classList.add('collapsed');
    }
    
    // Add some interactive features
    dashboard.addQuickActionHandlers();
});

// Add quick action handlers
DashboardApp.prototype.addQuickActionHandlers = function() {
    const quickActions = document.querySelectorAll('.quick-action-btn');
    
    quickActions.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const action = e.currentTarget.querySelector('span').textContent;
            
            switch (action) {
                case 'New Report':
                    this.navigateToPage('health-monitor');
                    break;
                case 'View Map':
                    this.navigateToPage('outbreak-map');
                    break;
                case 'Voice Assistant':
                    this.navigateToPage('voice-assistant');
                    break;
                case 'Export Data':
                    this.exportData();
                    break;
            }
        });
    });
};

// Export data functionality
DashboardApp.prototype.exportData = function() {
    // Simulate data export
    console.log('Exporting data...');
    
    // Show success message
    this.showNotification('Data exported successfully!', 'success');
};

// Show notification
DashboardApp.prototype.showNotification = function(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification-toast ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
};

// Add notification toast styles
const notificationStyles = `
    .notification-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        padding: var(--spacing-md);
        box-shadow: var(--shadow-dropdown);
        display: flex;
        align-items: center;
        gap: var(--spacing-sm);
        z-index: 10000;
        transform: translateX(100%);
        transition: transform var(--transition-normal);
    }
    
    .notification-toast.show {
        transform: translateX(0);
    }
    
    .notification-toast.success {
        border-left: 4px solid var(--success-color);
    }
    
    .notification-toast.info {
        border-left: 4px solid var(--info-color);
    }
    
    .notification-toast i {
        color: var(--success-color);
    }
    
    .notification-toast.info i {
        color: var(--info-color);
    }
`;

// Inject notification styles
const style = document.createElement('style');
style.textContent = notificationStyles;
document.head.appendChild(style); 