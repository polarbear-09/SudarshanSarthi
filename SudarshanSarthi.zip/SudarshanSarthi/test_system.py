#!/usr/bin/env python3
"""
SudarshanSarthi System Test Script
Tests all components and modules to ensure everything is working properly
"""

import asyncio
import requests
import json
import sys
import os
from datetime import datetime

# Test configuration
BASE_URL = "http://localhost:8000"
TEST_TIMEOUT = 10

class SystemTester:
    def __init__(self):
        self.results = []
        self.server_running = False
    
    def log_test(self, test_name: str, success: bool, message: str = ""):
        """Log test result"""
        status = "PASS" if success else "FAIL"
        timestamp = datetime.now().strftime("%H:%M:%S")
        result = f"[{timestamp}] {status} - {test_name}"
        if message:
            result += f" - {message}"
        
        print(result)
        self.results.append({
            "test": test_name,
            "success": success,
            "message": message,
            "timestamp": timestamp
        })
    
    def test_server_connection(self):
        """Test if server is running"""
        try:
            response = requests.get(f"{BASE_URL}/health", timeout=TEST_TIMEOUT)
            if response.status_code == 200:
                self.server_running = True
                self.log_test("Server Connection", True, f"Server running on {BASE_URL}")
                return True
            else:
                self.log_test("Server Connection", False, f"Status code: {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            self.log_test("Server Connection", False, f"Connection failed: {str(e)}")
            return False
    
    def test_root_endpoint(self):
        """Test root endpoint"""
        try:
            response = requests.get(f"{BASE_URL}/", timeout=TEST_TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                if "message" in data and "SudarshanSarthi" in data["message"]:
                    self.log_test("Root Endpoint", True, "Platform info returned")
                    return True
                else:
                    self.log_test("Root Endpoint", False, "Invalid response format")
                    return False
            else:
                self.log_test("Root Endpoint", False, f"Status code: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Root Endpoint", False, f"Error: {str(e)}")
            return False
    
    def test_health_endpoint(self):
        """Test health check endpoint"""
        try:
            response = requests.get(f"{BASE_URL}/health", timeout=TEST_TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "healthy":
                    self.log_test("Health Check", True, "All modules active")
                    return True
                else:
                    self.log_test("Health Check", False, "Health status not healthy")
                    return False
            else:
                self.log_test("Health Check", False, f"Status code: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Error: {str(e)}")
            return False
    
    def test_api_endpoints(self):
        """Test API endpoints"""
        api_endpoints = [
            "/api/v1/weather-risk",
            "/api/v1/news-sentiment", 
            "/api/v1/predict-disease",
            "/api/v1/mobility-risk",
            "/api/v1/health-log",
            "/api/v1/notifications"
        ]
        
        success_count = 0
        for endpoint in api_endpoints:
            try:
                response = requests.get(f"{BASE_URL}{endpoint}", timeout=TEST_TIMEOUT)
                if response.status_code == 200:
                    success_count += 1
                    self.log_test(f"API {endpoint}", True)
                else:
                    self.log_test(f"API {endpoint}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"API {endpoint}", False, f"Error: {str(e)}")
        
        return success_count > 0
    
    def test_integration_endpoints(self):
        """Test integration endpoints"""
        integration_endpoints = [
            "/integration/weather",
            "/integration/news",
            "/integration/health-data",
            "/integration/outbreak-data"
        ]
        
        success_count = 0
        for endpoint in integration_endpoints:
            try:
                response = requests.get(f"{BASE_URL}{endpoint}", timeout=TEST_TIMEOUT)
                if response.status_code == 200:
                    success_count += 1
                    self.log_test(f"Integration {endpoint}", True)
                else:
                    self.log_test(f"Integration {endpoint}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"Integration {endpoint}", False, f"Error: {str(e)}")
        
        return success_count > 0
    
    def test_llm_endpoints(self):
        """Test LLM assistant endpoints"""
        try:
            # Test chat endpoint
            chat_data = {
                "message": "I have a fever and cough",
                "user_id": "test_user_001"
            }
            response = requests.post(
                f"{BASE_URL}/llm/chat",
                json=chat_data,
                timeout=TEST_TIMEOUT
            )
            if response.status_code == 200:
                self.log_test("LLM Chat", True, "Chat response received")
                return True
            else:
                self.log_test("LLM Chat", False, f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("LLM Chat", False, f"Error: {str(e)}")
            return False
    
    def test_admin_endpoints(self):
        """Test admin dashboard endpoints"""
        try:
            # Test login
            login_data = {
                "email": "admin@example.com",
                "password": "admin123"
            }
            response = requests.post(
                f"{BASE_URL}/admin/login",
                json=login_data,
                timeout=TEST_TIMEOUT
            )
            if response.status_code == 200:
                data = response.json()
                if "token" in data:
                    token = data["token"]
                    self.log_test("Admin Login", True, "Login successful")
                    
                    # Test protected endpoint
                    headers = {"Authorization": f"Bearer {token}"}
                    response = requests.get(
                        f"{BASE_URL}/admin/outbreak-reports",
                        headers=headers,
                        timeout=TEST_TIMEOUT
                    )
                    if response.status_code == 200:
                        self.log_test("Admin Reports", True, "Reports fetched")
                        return True
                    else:
                        self.log_test("Admin Reports", False, f"Status: {response.status_code}")
                        return False
                else:
                    self.log_test("Admin Login", False, "No token received")
                    return False
            else:
                self.log_test("Admin Login", False, f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Admin Login", False, f"Error: {str(e)}")
            return False
    
    def test_websocket_endpoint(self):
        """Test WebSocket endpoint availability"""
        try:
            # Just check if the endpoint exists (can't easily test WebSocket without async)
            response = requests.get(f"{BASE_URL}/ws", timeout=TEST_TIMEOUT)
            # WebSocket endpoints typically return 426 or similar for GET requests
            if response.status_code in [426, 400, 405]:
                self.log_test("WebSocket Endpoint", True, "WebSocket endpoint available")
                return True
            else:
                self.log_test("WebSocket Endpoint", False, f"Unexpected status: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("WebSocket Endpoint", False, f"Error: {str(e)}")
            return False
    
    def test_frontend_routes(self):
        """Test frontend route endpoints"""
        frontend_routes = [
            "/dashboard",
            "/outbreak-map", 
            "/feature-audit",
            "/admin-panel"
        ]
        
        success_count = 0
        for route in frontend_routes:
            try:
                response = requests.get(f"{BASE_URL}{route}", timeout=TEST_TIMEOUT)
                if response.status_code in [200, 404]:  # 404 is expected if files don't exist
                    success_count += 1
                    self.log_test(f"Frontend {route}", True, f"Status: {response.status_code}")
                else:
                    self.log_test(f"Frontend {route}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"Frontend {route}", False, f"Error: {str(e)}")
        
        return success_count > 0
    
    def test_file_structure(self):
        """Test if required files exist"""
        required_files = [
            "main.py",
            "api.py",
            "integration.py", 
            "llm_assistant.py",
            "realtime_ws.py",
            "admin_dashboard.py",
            "utils/errors_and_logging.py",
            "requirements.txt"
        ]
        
        success_count = 0
        for file_path in required_files:
            if os.path.exists(file_path):
                success_count += 1
                self.log_test(f"File {file_path}", True)
            else:
                self.log_test(f"File {file_path}", False, "File not found")
        
        return success_count == len(required_files)
    
    def test_google_sheets_setup(self):
        """Test Google Sheets setup script"""
        if os.path.exists("setup_google_sheets.py"):
            self.log_test("Google Sheets Setup Script", True, "Script exists")
            return True
        else:
            self.log_test("Google Sheets Setup Script", False, "Script not found")
            return False
    
    def run_all_tests(self):
        """Run all tests"""
        print("=" * 60)
        print("SUDARSHANSARTHI SYSTEM TEST")
        print("=" * 60)
        print(f"Testing server at: {BASE_URL}")
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 60)
        
        # Test server connection first
        if not self.test_server_connection():
            print("\n[ERROR] Server is not running. Please start the server first:")
            print("python main.py")
            return False
        
        # Run all tests
        self.test_root_endpoint()
        self.test_health_endpoint()
        self.test_api_endpoints()
        self.test_integration_endpoints()
        self.test_llm_endpoints()
        self.test_admin_endpoints()
        self.test_websocket_endpoint()
        self.test_frontend_routes()
        self.test_file_structure()
        self.test_google_sheets_setup()
        
        # Summary
        print("=" * 60)
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results if r["success"])
        failed_tests = total_tests - passed_tests
        
        print(f"TEST SUMMARY:")
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests == 0:
            print("\n[SUCCESS] All tests passed! System is ready.")
            return True
        else:
            print(f"\n[WARNING] {failed_tests} tests failed. Check the details above.")
            return False

def main():
    """Main test function"""
    tester = SystemTester()
    success = tester.run_all_tests()
    
    if success:
        print("\n[SUCCESS] System test completed successfully!")
        sys.exit(0)
    else:
        print("\n[ERROR] System test failed. Please fix the issues above.")
        sys.exit(1)

if __name__ == "__main__":
    main() 