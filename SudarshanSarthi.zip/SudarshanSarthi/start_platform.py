#!/usr/bin/env python3
"""
SudarshanSarthi Platform Startup Script
Comprehensive startup script that ensures everything runs perfectly
"""

import os
import sys
import subprocess
import time
import requests
import json
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('startup.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("startup")

class PlatformStarter:
    def __init__(self):
        self.server_process = None
        self.base_url = "http://localhost:8000"
        self.startup_success = False
    
    def log_step(self, step: str, success: bool, message: str = ""):
        """Log startup step"""
        status = "SUCCESS" if success else "FAILED"
        timestamp = datetime.now().strftime("%H:%M:%S")
        result = f"[{timestamp}] {status} - {step}"
        if message:
            result += f" - {message}"
        
        print(result)
        if success:
            logger.info(f"Step completed: {step} - {message}")
        else:
            logger.error(f"Step failed: {step} - {message}")
    
    def check_python_version(self):
        """Check Python version"""
        version = sys.version_info
        if version.major >= 3 and version.minor >= 8:
            self.log_step("Python Version Check", True, f"Python {version.major}.{version.minor}.{version.micro}")
            return True
        else:
            self.log_step("Python Version Check", False, f"Python {version.major}.{version.minor}.{version.micro} (3.8+ required)")
            return False
    
    def check_dependencies(self):
        """Check if required packages are installed"""
        required_packages = [
            "fastapi",
            "uvicorn", 
            "requests",
            "pydantic",
            "gspread",
            "google-auth",
            "pandas"
        ]
        
        missing_packages = []
        for package in required_packages:
            try:
                __import__(package.replace("-", "_"))
                self.log_step(f"Package {package}", True)
            except ImportError:
                missing_packages.append(package)
                self.log_step(f"Package {package}", False, "Not installed")
        
        if missing_packages:
            self.log_step("Dependencies Check", False, f"Missing: {', '.join(missing_packages)}")
            return False
        else:
            self.log_step("Dependencies Check", True, "All packages available")
            return True
    
    def install_dependencies(self):
        """Install missing dependencies"""
        try:
            self.log_step("Installing Dependencies", True, "Running pip install...")
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                self.log_step("Dependencies Installation", True, "All packages installed")
                return True
            else:
                self.log_step("Dependencies Installation", False, f"Error: {result.stderr}")
                return False
        except Exception as e:
            self.log_step("Dependencies Installation", False, f"Exception: {str(e)}")
            return False
    
    def check_google_credentials(self):
        """Check if Google credentials file exists"""
        if os.path.exists("credentials.json"):
            self.log_step("Google Credentials", True, "credentials.json found")
            return True
        else:
            self.log_step("Google Credentials", False, "credentials.json not found")
            print("\n[INFO] Google credentials not found. Some features may not work.")
            print("To enable Google Sheets integration:")
            print("1. Create a Google Cloud Project")
            print("2. Enable Google Sheets API")
            print("3. Create a service account")
            print("4. Download credentials.json")
            return False
    
    def setup_google_sheets(self):
        """Setup Google Sheets if credentials are available"""
        if not os.path.exists("credentials.json"):
            self.log_step("Google Sheets Setup", False, "No credentials available")
            return False
        
        try:
            self.log_step("Google Sheets Setup", True, "Running setup script...")
            result = subprocess.run(
                [sys.executable, "setup_google_sheets.py"],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                self.log_step("Google Sheets Setup", True, "Spreadsheet created successfully")
                return True
            else:
                self.log_step("Google Sheets Setup", False, f"Error: {result.stderr}")
                return False
        except Exception as e:
            self.log_step("Google Sheets Setup", False, f"Exception: {str(e)}")
            return False
    
    def create_directories(self):
        """Create necessary directories"""
        directories = ["logs", "static", "uploads"]
        
        for directory in directories:
            try:
                os.makedirs(directory, exist_ok=True)
                self.log_step(f"Directory {directory}", True, "Created/verified")
            except Exception as e:
                self.log_step(f"Directory {directory}", False, f"Error: {str(e)}")
                return False
        
        return True
    
    def check_files(self):
        """Check if required files exist"""
        required_files = [
            "main.py",
            "api.py",
            "integration.py",
            "llm_assistant.py", 
            "realtime_ws.py",
            "admin_dashboard.py",
            "utils/errors_and_logging.py"
        ]
        
        missing_files = []
        for file_path in required_files:
            if os.path.exists(file_path):
                self.log_step(f"File {file_path}", True)
            else:
                missing_files.append(file_path)
                self.log_step(f"File {file_path}", False, "Not found")
        
        if missing_files:
            self.log_step("Files Check", False, f"Missing: {', '.join(missing_files)}")
            return False
        else:
            self.log_step("Files Check", True, "All files present")
            return True
    
    def start_server(self):
        """Start the FastAPI server"""
        try:
            self.log_step("Starting Server", True, "Launching FastAPI server...")
            
            # Start server in background
            self.server_process = subprocess.Popen(
                [sys.executable, "main.py"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait for server to start
            time.sleep(5)
            
            # Check if server is running
            try:
                response = requests.get(f"{self.base_url}/health", timeout=10)
                if response.status_code == 200:
                    self.log_step("Server Status", True, "Server running successfully")
                    return True
                else:
                    self.log_step("Server Status", False, f"Status code: {response.status_code}")
                    return False
            except requests.exceptions.RequestException:
                self.log_step("Server Status", False, "Server not responding")
                return False
                
        except Exception as e:
            self.log_step("Starting Server", False, f"Exception: {str(e)}")
            return False
    
    def test_endpoints(self):
        """Test key endpoints"""
        endpoints = [
            ("/", "Root"),
            ("/health", "Health Check"),
            ("/api/v1/weather-risk", "Weather Risk API"),
            ("/integration/weather", "Weather Integration"),
            ("/llm/chat", "LLM Chat"),
            ("/admin/login", "Admin Login")
        ]
        
        success_count = 0
        for endpoint, name in endpoints:
            try:
                if endpoint == "/llm/chat":
                    # POST request for chat
                    response = requests.post(
                        f"{self.base_url}{endpoint}",
                        json={"message": "test", "user_id": "test"},
                        timeout=10
                    )
                elif endpoint == "/admin/login":
                    # POST request for login
                    response = requests.post(
                        f"{self.base_url}{endpoint}",
                        json={"email": "admin@example.com", "password": "admin123"},
                        timeout=10
                    )
                else:
                    # GET request
                    response = requests.get(f"{self.base_url}{endpoint}", timeout=10)
                
                if response.status_code in [200, 422]:  # 422 is OK for validation errors
                    success_count += 1
                    self.log_step(f"Endpoint {name}", True, f"Status: {response.status_code}")
                else:
                    self.log_step(f"Endpoint {name}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_step(f"Endpoint {name}", False, f"Error: {str(e)}")
        
        if success_count > 0:
            self.log_step("Endpoint Testing", True, f"{success_count}/{len(endpoints)} endpoints working")
            return True
        else:
            self.log_step("Endpoint Testing", False, "No endpoints responding")
            return False
    
    def display_startup_info(self):
        """Display startup information"""
        print("\n" + "=" * 60)
        print("SUDARSHANSARTHI HEALTH PLATFORM")
        print("=" * 60)
        print(f"Server URL: {self.base_url}")
        print(f"API Documentation: {self.base_url}/docs")
        print(f"Admin Panel: {self.base_url}/admin-panel")
        print(f"Dashboard: {self.base_url}/dashboard")
        print(f"Outbreak Map: {self.base_url}/outbreak-map")
        print(f"Feature Audit: {self.base_url}/feature-audit")
        print("=" * 60)
        print("Platform is ready!")
        print("Press Ctrl+C to stop the server")
        print("=" * 60)
    
    def run_startup(self):
        """Run complete startup process"""
        print("Starting SudarshanSarthi Health Platform...")
        print("=" * 60)
        
        # Step 1: Environment checks
        if not self.check_python_version():
            return False
        
        if not self.check_dependencies():
            print("\n[INFO] Installing missing dependencies...")
            if not self.install_dependencies():
                return False
        
        # Step 2: File and directory checks
        if not self.create_directories():
            return False
        
        if not self.check_files():
            return False
        
        # Step 3: Google Sheets setup (optional)
        if self.check_google_credentials():
            self.setup_google_sheets()
        
        # Step 4: Start server
        if not self.start_server():
            return False
        
        # Step 5: Test endpoints
        if not self.test_endpoints():
            print("\n[WARNING] Some endpoints may not be working properly")
        
        # Step 6: Display info
        self.display_startup_info()
        
        self.startup_success = True
        return True
    
    def cleanup(self):
        """Cleanup on shutdown"""
        if self.server_process:
            self.log_step("Shutdown", True, "Stopping server...")
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
            self.log_step("Shutdown", True, "Server stopped")

def main():
    """Main startup function"""
    starter = PlatformStarter()
    
    try:
        success = starter.run_startup()
        
        if success:
            # Keep the script running
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\n[INFO] Shutting down...")
        else:
            print("\n[ERROR] Startup failed. Check the logs above.")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n[INFO] Shutdown requested by user")
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
    finally:
        starter.cleanup()
        print("\n[INFO] Platform shutdown complete")

if __name__ == "__main__":
    main() 