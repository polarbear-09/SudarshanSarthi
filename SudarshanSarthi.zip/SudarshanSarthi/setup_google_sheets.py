#!/usr/bin/env python3
"""
SudarshanSarthi Google Sheets Setup Script
Production-ready script to create and configure Google Sheets for the health platform
"""

import gspread
from google.oauth2.service_account import Credentials
import logging
from datetime import datetime
import sys
from typing import List, Dict, Optional

# Configure logging with UTF-8 encoding
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sheets_setup.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class SudarshanSheetsManager:
    """Manages Google Sheets operations for SudarshanSarthi"""
    
    def __init__(self, credentials_file: str = "credentials.json"):
        """Initialize the sheets manager with credentials"""
        self.credentials_file = credentials_file
        self.client = None
        self.spreadsheet = None
        self.spreadsheet_title = "SudarshanSarthi_DataHub"
        
        # Define sheet configurations
        self.sheets_config = {
            "User_Health_Logs": [
                "Timestamp", "UserID", "Symptoms", "RiskScore"
            ],
            "Community_Reports": [
                "Timestamp", "Location", "Event Type", "User Notes"
            ],
            "Outbreak_Data": [
                "Date", "City", "Cases", "Deaths", "Risk Level"
            ],
            "Chatbot_Logs": [
                "Timestamp", "UserID", "Question", "Response", "RiskLevel"
            ],
            "System_Logs": [
                "Timestamp", "Module", "Event Type", "Description"
            ]
        }
    
    def authenticate(self) -> bool:
        """Authenticate with Google Sheets API"""
        try:
            logger.info("Authenticating with Google Sheets API...")
            
            # Define the scope
            scope = [
                'https://www.googleapis.com/auth/spreadsheets',
                'https://www.googleapis.com/auth/drive'
            ]
            
            # Load credentials
            credentials = Credentials.from_service_account_file(
                self.credentials_file, 
                scopes=scope
            )
            
            # Create gspread client
            self.client = gspread.authorize(credentials)
            
            logger.info("[SUCCESS] Authentication successful")
            return True
            
        except FileNotFoundError:
            logger.error(f"[ERROR] Credentials file not found: {self.credentials_file}")
            logger.error("Please ensure credentials.json is in the current directory")
            return False
        except Exception as e:
            logger.error(f"[ERROR] Authentication failed: {str(e)}")
            return False
    
    def create_or_get_spreadsheet(self) -> bool:
        """Create new spreadsheet or get existing one"""
        try:
            logger.info(f"Looking for spreadsheet: {self.spreadsheet_title}")
            
            # Try to open existing spreadsheet
            try:
                self.spreadsheet = self.client.open(self.spreadsheet_title)
                logger.info("[SUCCESS] Found existing spreadsheet")
                return True
            except gspread.SpreadsheetNotFound:
                logger.info("Creating new spreadsheet...")
                
                # Create new spreadsheet
                self.spreadsheet = self.client.create(self.spreadsheet_title)
                
                # Make it accessible to anyone with the link (for development)
                self.spreadsheet.share('', perm_type='anyone', role='writer')
                
                logger.info("[SUCCESS] New spreadsheet created successfully")
                return True
                
        except Exception as e:
            logger.error(f"[ERROR] Failed to create/get spreadsheet: {str(e)}")
            return False
    
    def create_or_clear_worksheet(self, sheet_name: str, headers: List[str]) -> bool:
        """Create worksheet if it doesn't exist, or clear and reset headers"""
        try:
            logger.info(f"Setting up worksheet: {sheet_name}")
            
            # Try to get existing worksheet
            try:
                worksheet = self.spreadsheet.worksheet(sheet_name)
                logger.info(f"Found existing worksheet: {sheet_name}")
                
                # Clear all data
                worksheet.clear()
                logger.info(f"Cleared existing data in: {sheet_name}")
                
            except gspread.WorksheetNotFound:
                # Create new worksheet
                worksheet = self.spreadsheet.add_worksheet(
                    title=sheet_name, 
                    rows=1000, 
                    cols=20
                )
                logger.info(f"Created new worksheet: {sheet_name}")
            
            # Add headers
            worksheet.append_row(headers)
            
            # Format headers (make them bold)
            worksheet.format('A1:Z1', {
                'textFormat': {'bold': True},
                'backgroundColor': {'red': 0.9, 'green': 0.9, 'blue': 0.9}
            })
            
            logger.info(f"[SUCCESS] Worksheet {sheet_name} ready with headers")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to setup worksheet {sheet_name}: {str(e)}")
            return False
    
    def setup_all_worksheets(self) -> bool:
        """Setup all required worksheets"""
        logger.info("Setting up all worksheets...")
        
        success_count = 0
        total_sheets = len(self.sheets_config)
        
        for sheet_name, headers in self.sheets_config.items():
            if self.create_or_clear_worksheet(sheet_name, headers):
                success_count += 1
            else:
                logger.error(f"Failed to setup {sheet_name}")
        
        logger.info(f"[SUCCESS] Setup complete: {success_count}/{total_sheets} worksheets ready")
        return success_count == total_sheets
    
    def get_spreadsheet_url(self) -> Optional[str]:
        """Get the spreadsheet URL"""
        if self.spreadsheet:
            return self.spreadsheet.url
        return None
    
    def add_sample_data(self) -> bool:
        """Add sample data to demonstrate functionality"""
        try:
            logger.info("Adding sample data...")
            
            # Sample data for User_Health_Logs
            user_health_sample = [
                [datetime.now().isoformat(), "user_001", "fever,cough", "0.75"],
                [datetime.now().isoformat(), "user_002", "headache", "0.45"]
            ]
            
            # Sample data for Community_Reports
            community_sample = [
                [datetime.now().isoformat(), "Delhi", "outbreak", "Multiple cases reported"],
                [datetime.now().isoformat(), "Mumbai", "weather", "High humidity alert"]
            ]
            
            # Sample data for Outbreak_Data
            outbreak_sample = [
                ["2024-07-06", "Delhi", "120", "3", "high"],
                ["2024-07-06", "Mumbai", "85", "1", "medium"]
            ]
            
            # Sample data for Chatbot_Logs
            chatbot_sample = [
                [datetime.now().isoformat(), "user_001", "I have a fever", "Please monitor symptoms", "medium"],
                [datetime.now().isoformat(), "user_002", "Is it safe to go out?", "Check local alerts", "low"]
            ]
            
            # Sample data for System_Logs
            system_sample = [
                [datetime.now().isoformat(), "API", "startup", "Server started successfully"],
                [datetime.now().isoformat(), "Database", "connection", "Connected to Google Sheets"]
            ]
            
            # Add sample data to respective sheets
            sample_data = {
                "User_Health_Logs": user_health_sample,
                "Community_Reports": community_sample,
                "Outbreak_Data": outbreak_sample,
                "Chatbot_Logs": chatbot_sample,
                "System_Logs": system_sample
            }
            
            for sheet_name, data in sample_data.items():
                try:
                    worksheet = self.spreadsheet.worksheet(sheet_name)
                    for row in data:
                        worksheet.append_row(row)
                    logger.info(f"Added sample data to {sheet_name}")
                except Exception as e:
                    logger.warning(f"Could not add sample data to {sheet_name}: {str(e)}")
            
            logger.info("[SUCCESS] Sample data added successfully")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Failed to add sample data: {str(e)}")
            return False
    
    def run_setup(self, add_samples: bool = True) -> bool:
        """Run the complete setup process"""
        logger.info("STARTING SudarshanSarthi Google Sheets Setup")
        logger.info("=" * 50)
        
        # Step 1: Authenticate
        if not self.authenticate():
            return False
        
        # Step 2: Create or get spreadsheet
        if not self.create_or_get_spreadsheet():
            return False
        
        # Step 3: Setup all worksheets
        if not self.setup_all_worksheets():
            return False
        
        # Step 4: Add sample data (optional)
        if add_samples:
            self.add_sample_data()
        
        # Step 5: Print results
        self.print_results()
        
        logger.info("=" * 50)
        logger.info("SUCCESS: Setup completed successfully!")
        return True
    
    def print_results(self):
        """Print setup results and spreadsheet information"""
        url = self.get_spreadsheet_url()
        
        print("\n" + "=" * 60)
        print("SUDARSHANSARTHI GOOGLE SHEETS SETUP COMPLETE")
        print("=" * 60)
        print(f"Spreadsheet Title: {self.spreadsheet_title}")
        print(f"Spreadsheet URL: {url}")
        print(f"Created/Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\nWorksheets Created:")
        
        for sheet_name in self.sheets_config.keys():
            print(f"   [SUCCESS] {sheet_name}")
        
        print("\nNext Steps:")
        print("   1. Share the spreadsheet URL with your team")
        print("   2. Update your backend config with the spreadsheet ID")
        print("   3. Test the API endpoints")
        print("=" * 60)

def main():
    """Main function to run the setup"""
    try:
        # Create sheets manager
        manager = SudarshanSheetsManager()
        
        # Run setup
        success = manager.run_setup(add_samples=True)
        
        if success:
            print("\n[SUCCESS] Setup completed successfully!")
            print(f"Access your spreadsheet at: {manager.get_spreadsheet_url()}")
        else:
            print("\n[ERROR] Setup failed. Check the logs for details.")
            sys.exit(1)
            
    except KeyboardInterrupt:
        logger.info("Setup interrupted by user")
        print("\n[WARNING] Setup interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main() 