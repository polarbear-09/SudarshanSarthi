// Admin Dashboard JavaScript
class AdminDashboard {
    constructor() {
        this.currentSection = 'overview';
        this.currentPage = 1;
        this.itemsPerPage = 10;
        this.reports = [];
        this.activeAlerts = [];
        this.charts = {};
        this.init();
    }

    init() {
        this.hideLoading();
        this.setupEventListeners();
        this.loadMockData();
        this.initializeCharts();
        this.updateActiveAlerts();
        this.setupTableSorting();
    }

    hideLoading() {
        setTimeout(() => {
            const loading = document.getElementById('loading');
            loading.classList.add('hidden');
            setTimeout(() => {
                loading.style.display = 'none';
            }, 300);
        }, 1000);
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.dataset.section;
                this.navigateToSection(section);
            });
        });

        // Sidebar toggle
        document.getElementById('sidebarToggle').addEventListener('click', () => {
            this.toggleSidebar();
        });

        // Mobile menu toggle
        document.getElementById('mobileMenuToggle').addEventListener('click', () => {
            this.toggleMobileMenu();
        });

        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            this.toggleTheme();
        });

        // Form submissions
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleUploadSubmit();
        });

        document.getElementById('alertForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAlertSubmit();
        });

        // Search functionality
        document.getElementById('reportSearch').addEventListener('input', (e) => {
            this.filterReports(e.target.value);
        });

        // File upload
        document.getElementById('dataFile').addEventListener('change', (e) => {
            this.handleFileUpload(e);
        });

        // Drag and drop for file upload
        const fileUploadArea = document.querySelector('.file-upload-area');
        fileUploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            fileUploadArea.style.borderColor = 'var(--primary-color)';
            fileUploadArea.style.background = 'var(--surface-hover)';
        });

        fileUploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            fileUploadArea.style.borderColor = 'var(--border)';
            fileUploadArea.style.background = 'var(--background)';
        });

        fileUploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            fileUploadArea.style.borderColor = 'var(--border)';
            fileUploadArea.style.background = 'var(--background)';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                document.getElementById('dataFile').files = files;
                this.handleFileUpload({ target: { files } });
            }
        });
    }

    navigateToSection(section) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.content-section').forEach(sectionEl => {
            sectionEl.classList.remove('active');
        });
        document.getElementById(section).classList.add('active');

        // Update page title
        document.getElementById('pageTitle').textContent = this.getSectionTitle(section);
        this.currentSection = section;

        // Initialize section-specific functionality
        if (section === 'reports') {
            this.renderReportsTable();
        } else if (section === 'insights') {
            this.updateCharts();
        }
    }

    getSectionTitle(section) {
        const titles = {
            'overview': 'Overview',
            'alerts': 'Alerts',
            'upload': 'Upload Data',
            'reports': 'View Reports',
            'insights': 'AI Insights'
        };
        return titles[section] || 'Overview';
    }

    toggleSidebar() {
        const sidebar = document.getElementById('adminSidebar');
        const main = document.querySelector('.admin-main');
        
        sidebar.classList.toggle('collapsed');
        main.classList.toggle('expanded');
    }

    toggleMobileMenu() {
        const sidebar = document.getElementById('adminSidebar');
        sidebar.classList.toggle('show');
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('adminTheme', newTheme);
    }

    loadMockData() {
        // Mock reports data
        this.reports = [
            {
                id: 1,
                date: '2024-01-15',
                organization: 'Apollo Hospitals',
                type: 'COVID-19',
                location: 'Mumbai, Maharashtra',
                cases: 45,
                severity: 'medium',
                status: 'approved'
            },
            {
                id: 2,
                date: '2024-01-14',
                organization: 'Fortis Healthcare',
                type: 'Dengue',
                location: 'Delhi, NCR',
                cases: 23,
                severity: 'high',
                status: 'pending'
            },
            {
                id: 3,
                date: '2024-01-13',
                organization: 'Max Healthcare',
                type: 'Malaria',
                location: 'Bangalore, Karnataka',
                cases: 12,
                severity: 'low',
                status: 'approved'
            },
            {
                id: 4,
                date: '2024-01-12',
                organization: 'Health NGO - Mumbai',
                type: 'Chikungunya',
                location: 'Mumbai, Maharashtra',
                cases: 67,
                severity: 'critical',
                status: 'approved'
            },
            {
                id: 5,
                date: '2024-01-11',
                organization: 'Community Health Initiative',
                type: 'COVID-19',
                location: 'Chennai, Tamil Nadu',
                cases: 34,
                severity: 'medium',
                status: 'rejected'
            }
        ];

        // Mock active alerts
        this.activeAlerts = [
            {
                id: 1,
                title: 'COVID-19 Outbreak Alert',
                message: 'New cases detected in Mumbai region. Please take necessary precautions.',
                type: 'outbreak',
                priority: 'high',
                time: '2 hours ago',
                regions: ['Mumbai']
            },
            {
                id: 2,
                title: 'Dengue Prevention Notice',
                message: 'Dengue cases on the rise. Maintain clean surroundings and use mosquito repellents.',
                type: 'prevention',
                priority: 'medium',
                time: '1 day ago',
                regions: ['Delhi', 'Mumbai']
            },
            {
                id: 3,
                title: 'Vaccination Drive',
                message: 'Free vaccination camp in Bangalore this weekend.',
                type: 'vaccination',
                priority: 'low',
                time: '2 days ago',
                regions: ['Bangalore']
            }
        ];
    }

    initializeCharts() {
        // System Health Chart
        const systemHealthCtx = document.getElementById('systemHealthChart').getContext('2d');
        this.charts.systemHealth = new Chart(systemHealthCtx, {
            type: 'line',
            data: {
                labels: ['Jan 1', 'Jan 2', 'Jan 3', 'Jan 4', 'Jan 5', 'Jan 6', 'Jan 7'],
                datasets: [{
                    label: 'System Uptime',
                    data: [98, 99, 97, 99, 98, 100, 99],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });

        // Prediction Chart
        const predictionCtx = document.getElementById('predictionChart').getContext('2d');
        this.charts.prediction = new Chart(predictionCtx, {
            type: 'bar',
            data: {
                labels: ['COVID-19', 'Dengue', 'Malaria', 'Chikungunya'],
                datasets: [{
                    label: 'Predicted Cases',
                    data: [120, 85, 45, 67],
                    backgroundColor: [
                        '#ef4444',
                        '#f59e0b',
                        '#10b981',
                        '#3b82f6'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Risk Assessment Chart
        const riskCtx = document.getElementById('riskChart').getContext('2d');
        this.charts.risk = new Chart(riskCtx, {
            type: 'doughnut',
            data: {
                labels: ['Low Risk', 'Medium Risk', 'High Risk', 'Critical'],
                datasets: [{
                    data: [30, 40, 20, 10],
                    backgroundColor: [
                        '#10b981',
                        '#f59e0b',
                        '#f97316',
                        '#ef4444'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Geographic Spread Chart
        const spreadCtx = document.getElementById('spreadChart').getContext('2d');
        this.charts.spread = new Chart(spreadCtx, {
            type: 'radar',
            data: {
                labels: ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad'],
                datasets: [{
                    label: 'Active Cases',
                    data: [45, 23, 12, 34, 18, 28],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    pointBackgroundColor: '#3b82f6'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    updateCharts() {
        // Update charts with new data
        if (this.charts.prediction) {
            this.charts.prediction.data.datasets[0].data = [
                Math.floor(Math.random() * 200) + 50,
                Math.floor(Math.random() * 150) + 30,
                Math.floor(Math.random() * 100) + 20,
                Math.floor(Math.random() * 120) + 40
            ];
            this.charts.prediction.update();
        }
    }

    handleUploadSubmit() {
        const formData = new FormData(document.getElementById('uploadForm'));
        const data = {
            organization: formData.get('organization'),
            outbreakType: formData.get('outbreakType'),
            severity: formData.get('severity'),
            location: formData.get('location'),
            cases: formData.get('cases'),
            description: formData.get('description')
        };

        // Simulate API call
        this.simulateUpload(data);
    }

    async simulateUpload(data) {
        try {
            // Show loading state
            const submitBtn = document.querySelector('#uploadForm button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            submitBtn.disabled = true;

            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Add to reports
            const newReport = {
                id: this.reports.length + 1,
                date: new Date().toISOString().split('T')[0],
                organization: data.organization,
                type: data.outbreakType,
                location: data.location,
                cases: parseInt(data.cases),
                severity: data.severity,
                status: 'pending'
            };

            this.reports.unshift(newReport);

            // Reset form
            document.getElementById('uploadForm').reset();
            document.querySelector('.file-upload-area p').textContent = 'Drag and drop files here or click to browse';

            // Show success message
            this.showToast('Data uploaded successfully! Report is under review.', 'success');

            // Navigate to reports section
            this.navigateToSection('reports');

        } catch (error) {
            this.showToast('Upload failed. Please try again.', 'error');
        } finally {
            // Reset button
            const submitBtn = document.querySelector('#uploadForm button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-upload"></i> Upload Data';
            submitBtn.disabled = false;
        }
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            const fileUploadArea = document.querySelector('.file-upload-area p');
            fileUploadArea.textContent = `Selected: ${file.name}`;
            
            // Validate file type
            const allowedTypes = ['.csv', '.xlsx', '.xls'];
            const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
            
            if (!allowedTypes.includes(fileExtension)) {
                this.showToast('Invalid file type. Please upload CSV or Excel files.', 'error');
                event.target.value = '';
                fileUploadArea.textContent = 'Drag and drop files here or click to browse';
            }
        }
    }

    handleAlertSubmit() {
        const formData = new FormData(document.getElementById('alertForm'));
        const data = {
            title: formData.get('alertTitle'),
            type: formData.get('alertType'),
            priority: formData.get('alertPriority'),
            message: formData.get('alertMessage'),
            duration: formData.get('alertDuration'),
            regions: Array.from(document.querySelectorAll('.region-selector input:checked')).map(cb => cb.value)
        };

        if (data.regions.length === 0) {
            this.showToast('Please select at least one region.', 'error');
            return;
        }

        // Show preview modal
        this.showAlertPreview(data);
    }

    showAlertPreview(data) {
        const modal = document.getElementById('alertPreviewModal');
        const preview = document.getElementById('alertPreview');
        
        preview.innerHTML = `
            <div class="alert-preview-content">
                <h4>${data.title}</h4>
                <div class="alert-meta">
                    <span class="alert-type">${data.type}</span>
                    <span class="alert-priority ${data.priority}">${data.priority}</span>
                </div>
                <p>${data.message}</p>
                <div class="alert-details">
                    <strong>Regions:</strong> ${data.regions.join(', ')}
                    <br>
                    <strong>Duration:</strong> ${data.duration} hours
                </div>
            </div>
        `;
        
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    closeAlertPreview() {
        const modal = document.getElementById('alertPreviewModal');
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }

    sendAlert() {
        // Simulate sending alert
        this.showToast('Alert sent successfully to all users!', 'success');
        this.closeAlertPreview();
        document.getElementById('alertForm').reset();
        
        // Add to active alerts
        const formData = new FormData(document.getElementById('alertForm'));
        const newAlert = {
            id: this.activeAlerts.length + 1,
            title: formData.get('alertTitle'),
            message: formData.get('alertMessage'),
            type: formData.get('alertType'),
            priority: formData.get('alertPriority'),
            time: 'Just now',
            regions: Array.from(document.querySelectorAll('.region-selector input:checked')).map(cb => cb.value)
        };
        
        this.activeAlerts.unshift(newAlert);
        this.updateActiveAlerts();
    }

    updateActiveAlerts() {
        const alertsList = document.getElementById('activeAlertsList');
        const alertCount = document.querySelector('.alert-count');
        
        alertCount.textContent = this.activeAlerts.length;
        
        alertsList.innerHTML = this.activeAlerts.map(alert => `
            <div class="active-alert-item">
                <div class="alert-item-header">
                    <span class="alert-title">${alert.title}</span>
                    <span class="alert-time">${alert.time}</span>
                </div>
                <div class="alert-message">${alert.message}</div>
                <div class="alert-meta">
                    <span>Type: ${alert.type}</span>
                    <span>Priority: ${alert.priority}</span>
                    <span>Regions: ${alert.regions.join(', ')}</span>
                </div>
            </div>
        `).join('');
    }

    renderReportsTable() {
        const tbody = document.getElementById('reportsTableBody');
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageReports = this.reports.slice(startIndex, endIndex);

        tbody.innerHTML = pageReports.map(report => `
            <tr>
                <td>${report.date}</td>
                <td>${report.organization}</td>
                <td>${report.type}</td>
                <td>${report.location}</td>
                <td>${report.cases}</td>
                <td><span class="severity-badge ${report.severity}">${report.severity}</span></td>
                <td><span class="status-badge ${report.status}">${report.status}</span></td>
                <td>
                    <button class="btn secondary small" onclick="adminDashboard.viewReport(${report.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn secondary small" onclick="adminDashboard.editReport(${report.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        this.updatePagination();
    }

    updatePagination() {
        const totalPages = Math.ceil(this.reports.length / this.itemsPerPage);
        document.getElementById('currentPage').textContent = this.currentPage;
        document.getElementById('totalPages').textContent = totalPages;
    }

    filterReports(searchTerm) {
        const filteredReports = this.reports.filter(report => 
            report.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
            report.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
            report.location.toLowerCase().includes(searchTerm.toLowerCase())
        );

        // Update table with filtered results
        const tbody = document.getElementById('reportsTableBody');
        tbody.innerHTML = filteredReports.map(report => `
            <tr>
                <td>${report.date}</td>
                <td>${report.organization}</td>
                <td>${report.type}</td>
                <td>${report.location}</td>
                <td>${report.cases}</td>
                <td><span class="severity-badge ${report.severity}">${report.severity}</span></td>
                <td><span class="status-badge ${report.status}">${report.status}</span></td>
                <td>
                    <button class="btn secondary small" onclick="adminDashboard.viewReport(${report.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn secondary small" onclick="adminDashboard.editReport(${report.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    setupTableSorting() {
        document.querySelectorAll('#reportsTable th[data-sort]').forEach(th => {
            th.addEventListener('click', () => {
                const sortBy = th.dataset.sort;
                this.sortReports(sortBy);
            });
        });
    }

    sortReports(sortBy) {
        this.reports.sort((a, b) => {
            if (sortBy === 'date') {
                return new Date(b.date) - new Date(a.date);
            } else if (sortBy === 'cases') {
                return b.cases - a.cases;
            } else {
                return a[sortBy].localeCompare(b[sortBy]);
            }
        });

        this.renderReportsTable();
    }

    viewReport(id) {
        const report = this.reports.find(r => r.id === id);
        if (report) {
            this.showToast(`Viewing report: ${report.organization} - ${report.type}`, 'success');
        }
    }

    editReport(id) {
        const report = this.reports.find(r => r.id === id);
        if (report) {
            this.showToast(`Editing report: ${report.organization} - ${report.type}`, 'success');
        }
    }

    exportReports() {
        // Simulate export functionality
        this.showToast('Reports exported successfully!', 'success');
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.renderReportsTable();
        }
    }

    nextPage() {
        const totalPages = Math.ceil(this.reports.length / this.itemsPerPage);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.renderReportsTable();
        }
    }

    resetUploadForm() {
        document.getElementById('uploadForm').reset();
        document.querySelector('.file-upload-area p').textContent = 'Drag and drop files here or click to browse';
    }

    previewAlert() {
        const formData = new FormData(document.getElementById('alertForm'));
        const data = {
            title: formData.get('alertTitle'),
            type: formData.get('alertType'),
            priority: formData.get('alertPriority'),
            message: formData.get('alertMessage'),
            duration: formData.get('alertDuration'),
            regions: Array.from(document.querySelectorAll('.region-selector input:checked')).map(cb => cb.value)
        };

        if (!data.title || !data.message) {
            this.showToast('Please fill in title and message to preview.', 'error');
            return;
        }

        this.showAlertPreview(data);
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('successToast');
        const toastMessage = document.getElementById('toastMessage');
        
        toastMessage.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    closeToast() {
        const toast = document.getElementById('successToast');
        toast.classList.remove('show');
    }
}

// Global functions for HTML onclick handlers
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = '../index.html';
    }
}

function previousPage() {
    adminDashboard.previousPage();
}

function nextPage() {
    adminDashboard.nextPage();
}

function exportReports() {
    adminDashboard.exportReports();
}

function resetUploadForm() {
    adminDashboard.resetUploadForm();
}

function previewAlert() {
    adminDashboard.previewAlert();
}

function closeAlertPreview() {
    adminDashboard.closeAlertPreview();
}

function sendAlert() {
    adminDashboard.sendAlert();
}

function closeToast() {
    adminDashboard.closeToast();
}

// Initialize admin dashboard when DOM is loaded
let adminDashboard;
document.addEventListener('DOMContentLoaded', () => {
    adminDashboard = new AdminDashboard();
});

// Close modal when clicking outside
document.addEventListener('click', (e) => {
    const modal = document.getElementById('alertPreviewModal');
    if (e.target === modal) {
        adminDashboard.closeAlertPreview();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        adminDashboard.closeAlertPreview();
        adminDashboard.closeToast();
    }
});

// Load saved theme
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('adminTheme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
}); 