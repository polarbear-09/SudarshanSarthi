from typing import Optional

def predict_disease(lat: float, lon: float, symptoms: Optional[str] = None, age: Optional[int] = None, context: Optional[str] = None) -> dict:
    """
    Simulate disease prediction based on location, symptoms, and context.
    """
    # Simulated prediction logic
    predicted_diseases = []
    confidence = 0.75
    risk_level = "medium"
    
    if symptoms:
        symptom_list = [s.strip().lower() for s in symptoms.split(",")]
        if "fever" in symptom_list and "cough" in symptom_list:
            predicted_diseases = ["COVID-19", "Common Cold", "Flu"]
            confidence = 0.85
            risk_level = "high"
        elif "fever" in symptom_list:
            predicted_diseases = ["Common Cold", "Flu", "Dengue"]
            confidence = 0.70
        elif "headache" in symptom_list:
            predicted_diseases = ["Migraine", "Tension Headache", "Sinusitis"]
            confidence = 0.65
    else:
        # Location-based prediction
        if lat > 30 and lon > 70:  # India region
            predicted_diseases = ["Dengue", "Malaria", "Typhoid"]
            confidence = 0.60
        elif lat < 10:  # Tropical region
            predicted_diseases = ["Dengue", "Zika", "Chikungunya"]
            confidence = 0.70
    
    return {
        "location": f"{lat},{lon}",
        "predicted_diseases": predicted_diseases,
        "confidence": confidence,
        "risk_level": risk_level,
        "recommendations": [
            "Monitor symptoms closely",
            "Stay hydrated",
            "Get adequate rest",
            "Consider consulting a healthcare provider"
        ],
        "prevention_tips": [
            "Practice good hygiene",
            "Avoid close contact with sick individuals",
            "Maintain a healthy diet",
            "Get regular exercise"
        ]
    } 