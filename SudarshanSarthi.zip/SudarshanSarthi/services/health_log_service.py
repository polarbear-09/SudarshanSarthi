from typing import Optional, List
from datetime import datetime, timedelta
import uuid

# Simulated database
health_logs = {}

def get_health_log(user_id: str, days: int = 7) -> dict:
    """Get health log entries for a user."""
    user_logs = health_logs.get(user_id, [])
    
    # Filter by days
    cutoff_date = datetime.now() - timedelta(days=days)
    recent_logs = [
        log for log in user_logs 
        if datetime.fromisoformat(log["timestamp"]) > cutoff_date
    ]
    
    return {
        "user_id": user_id,
        "entries": recent_logs,
        "total_entries": len(recent_logs),
        "period_days": days
    }

def create_health_log(entry) -> dict:
    """Create a new health log entry."""
    log_id = str(uuid.uuid4())
    log_entry = {
        "id": log_id,
        "user_id": entry.user_id,
        "symptoms": entry.symptoms,
        "temperature": entry.temperature,
        "notes": entry.notes,
        "timestamp": datetime.now().isoformat()
    }
    
    if entry.user_id not in health_logs:
        health_logs[entry.user_id] = []
    
    health_logs[entry.user_id].append(log_entry)
    
    return {
        "status": "created",
        "log_id": log_id,
        "entry": log_entry
    } 