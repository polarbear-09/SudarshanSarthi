from typing import Optional, List

def get_cat_images(mood: str = "happy", count: int = 3) -> dict:
    """Get cat images based on mood (simulated Cat API response)."""
    
    # Simulated cat images (replace with real Cat API call)
    cat_images = [
        "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400",
        "https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?w=400", 
        "https://images.unsplash.com/photo-1529778873920-4da4926a72c2?w=400"
    ]
    
    mood_messages = {
        "happy": "Here are some happy cats to brighten your day! 😸",
        "sad": "These adorable cats will cheer you up! 🐱",
        "stressed": "Take a moment to relax with these calming cats! 😌"
    }
    
    return {
        "mood": mood,
        "message": mood_messages.get(mood, "Enjoy these cat images!"),
        "images": cat_images[:count],
        "count": len(cat_images[:count]),
        "api_source": "Cat API (simulated)"
    } 