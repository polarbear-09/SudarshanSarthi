from typing import Optional

def get_mobility_risk(lat: float, lon: float, radius_km: float = 5.0) -> dict:
    """
    Simulate mobility and density-based disease spread risk.
    """
    # Simulated mobility data
    population_density = 2500  # people per km²
    mobility_score = 0.7
    public_transport_usage = 0.6
    social_distancing_compliance = 0.8
    
    # Calculate risk based on density and mobility
    if population_density > 2000:
        density_risk = "high"
    elif population_density > 1000:
        density_risk = "medium"
    else:
        density_risk = "low"
    
    if mobility_score > 0.8:
        mobility_risk = "high"
    elif mobility_score > 0.5:
        mobility_risk = "medium"
    else:
        mobility_risk = "low"
    
    overall_risk = "medium"
    if density_risk == "high" and mobility_risk == "high":
        overall_risk = "high"
    elif density_risk == "low" and mobility_risk == "low":
        overall_risk = "low"
    
    return {
        "location": f"{lat},{lon}",
        "radius_km": radius_km,
        "population_density": population_density,
        "mobility_score": mobility_score,
        "public_transport_usage": public_transport_usage,
        "social_distancing_compliance": social_distancing_compliance,
        "density_risk": density_risk,
        "mobility_risk": mobility_risk,
        "overall_risk": overall_risk,
        "spread_probability": 0.65,
        "recommendations": [
            "Avoid crowded places",
            "Use personal transport when possible",
            "Maintain social distancing",
            "Wear masks in public spaces"
        ],
        "hotspots": [
            {"lat": lat + 0.01, "lon": lon + 0.01, "risk": "high", "type": "shopping_center"},
            {"lat": lat - 0.005, "lon": lon - 0.005, "risk": "medium", "type": "public_transport"}
        ]
    } 