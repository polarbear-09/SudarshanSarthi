from typing import Optional

def get_weather_disease_risk(lat: float, lon: float, city: Optional[str] = None) -> dict:
    """
    Simulate disease risk estimation based on weather and pollution data.
    """
    # Simulated logic (replace with real API/data in production)
    risk_level = "medium"
    if lat > 30 and lon > 70:
        risk_level = "high"
    elif lat < 10:
        risk_level = "low"
    return {
        "location": city or f"{lat},{lon}",
        "temperature_c": 32.5,
        "humidity": 68,
        "pm25": 85,
        "pm10": 120,
        "risk_level": risk_level,
        "risk_factors": [
            "High PM2.5 levels",
            "Humidity above 60%",
            "Temperature above 30°C"
        ],
        "suggested_precautions": [
            "Wear a mask outdoors",
            "Avoid strenuous activity",
            "Monitor for respiratory symptoms"
        ]
    } 