from typing import Optional

def analyze_news_sentiment(topic: Optional[str] = "health", region: Optional[str] = None) -> dict:
    """
    Simulate NLP sentiment analysis of health news.
    """
    # Simulated logic (replace with real NLP/news API in production)
    return {
        "topic": topic,
        "region": region or "global",
        "sentiment": "neutral",
        "summary": "Most recent health news are balanced, with some concern about rising cases.",
        "positive_articles": 12,
        "negative_articles": 8,
        "neutral_articles": 20,
        "top_keywords": ["outbreak", "vaccine", "prevention", "cases"],
        "sample_headlines": [
            "Local health authorities urge vaccination as cases rise",
            "Experts say prevention is key to stopping outbreaks",
            "Community rallies to support affected families"
        ]
    } 