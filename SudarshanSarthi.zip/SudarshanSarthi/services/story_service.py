from typing import Optional, List

def get_story_mode_data(user_id: str, chapter: int = 1) -> dict:
    """Get guided character-based walkthrough data."""
    
    chapters = {
        1: {
            "title": "Welcome to SudarshanSarthi",
            "character": "Dr. Maya",
            "message": "Hello! I'm Dr. Maya, your AI health companion. Let's start your health journey together!",
            "actions": [
                {"type": "explore", "text": "Explore the dashboard", "completed": False},
                {"type": "profile", "text": "Complete your health profile", "completed": False}
            ],
            "next_chapter": 2
        },
        2: {
            "title": "Understanding Your Health",
            "character": "Dr. Maya", 
            "message": "Great! Now let's learn about monitoring your health and understanding risk factors.",
            "actions": [
                {"type": "health_log", "text": "Log your first health entry", "completed": False},
                {"type": "risk_assessment", "text": "Complete risk assessment", "completed": False}
            ],
            "next_chapter": 3
        },
        3: {
            "title": "Staying Safe in Your Community",
            "character": "Dr. Maya",
            "message": "Perfect! Now let's learn about community health and outbreak awareness.",
            "actions": [
                {"type": "map", "text": "Explore the outbreak map", "completed": False},
                {"type": "notifications", "text": "Set up health alerts", "completed": False}
            ],
            "next_chapter": None
        }
    }
    
    current_chapter = chapters.get(chapter, chapters[1])
    
    return {
        "user_id": user_id,
        "current_chapter": chapter,
        "chapter_data": current_chapter,
        "total_chapters": len(chapters),
        "progress": (chapter / len(chapters)) * 100
    } 