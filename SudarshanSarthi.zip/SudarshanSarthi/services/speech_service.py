from typing import Optional

def convert_speech_to_text(audio_data: str, language: str = "en") -> dict:
    """Convert speech to text (simulated)."""
    
    # Simulated speech recognition (replace with real speech-to-text API)
    sample_texts = {
        "en": "I'm feeling unwell today with a headache and fever.",
        "es": "Me siento mal hoy con dolor de cabeza y fiebre.",
        "fr": "Je me sens mal aujourd'hui avec un mal de tête et de la fièvre."
    }
    
    detected_text = sample_texts.get(language, sample_texts["en"])
    
    return {
        "text": detected_text,
        "language": language,
        "confidence": 0.85,
        "duration_seconds": 3.2,
        "word_count": len(detected_text.split())
    } 