from typing import Optional, List
from datetime import datetime, timedelta

def get_outbreak_forecast(location: str, days: int = 30) -> dict:
    """Get outbreak forecast timeline."""
    
    timeline = []
    base_date = datetime.now()
    
    for i in range(days):
        date = base_date + timedelta(days=i)
        # Simulated forecast data
        cases = max(0, 100 + (i * 5) + (i % 7 * 10))  # Varying pattern
        risk = "medium" if cases < 200 else "high" if cases < 300 else "critical"
        
        timeline.append({
            "date": date.strftime("%Y-%m-%d"),
            "predicted_cases": cases,
            "risk_level": risk,
            "confidence": 0.75 - (i * 0.01)  # Decreasing confidence over time
        })
    
    return {
        "location": location,
        "forecast_period_days": days,
        "timeline": timeline,
        "summary": {
            "peak_prediction": "2024-02-15",
            "total_predicted_cases": sum(day["predicted_cases"] for day in timeline),
            "average_daily_cases": sum(day["predicted_cases"] for day in timeline) // days
        }
    } 