from typing import Optional, List

def get_dashboard_widgets(user_id: str, widget_types: str = "all") -> dict:
    """Get data for custom dashboard widgets."""
    
    widgets = {
        "health_summary": {
            "type": "health_summary",
            "data": {
                "current_status": "healthy",
                "risk_level": "low",
                "last_checkup": "2024-01-15",
                "next_reminder": "2024-02-15"
            }
        },
        "outbreak_stats": {
            "type": "outbreak_stats", 
            "data": {
                "local_cases": 45,
                "trend": "decreasing",
                "risk_zone": "medium",
                "last_updated": "2024-01-20"
            }
        },
        "weather_risk": {
            "type": "weather_risk",
            "data": {
                "temperature": 25,
                "humidity": 65,
                "risk_factor": "medium",
                "recommendations": ["Stay hydrated", "Avoid crowded places"]
            }
        },
        "mental_health": {
            "type": "mental_health",
            "data": {
                "stress_level": "low",
                "mood": "positive",
                "last_assessment": "2024-01-19",
                "suggestions": ["Continue current routine", "Practice mindfulness"]
            }
        }
    }
    
    if widget_types != "all":
        requested_types = [w.strip() for w in widget_types.split(",")]
        widgets = {k: v for k, v in widgets.items() if v["type"] in requested_types}
    
    return {
        "user_id": user_id,
        "widgets": widgets,
        "total_widgets": len(widgets)
    } 