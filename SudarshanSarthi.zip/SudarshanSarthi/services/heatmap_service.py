from typing import Optional, List

def get_heatmap_data(lat: float, lon: float, zoom: int = 10) -> dict:
    """Get heatmap data for outbreak risk visualization."""
    
    # Simulated heatmap data points
    heatmap_points = [
        {"lat": lat + 0.01, "lon": lon + 0.01, "intensity": 0.8, "risk": "high"},
        {"lat": lat - 0.005, "lon": lon - 0.005, "intensity": 0.6, "risk": "medium"},
        {"lat": lat + 0.02, "lon": lon - 0.01, "intensity": 0.9, "risk": "high"},
        {"lat": lat - 0.01, "lon": lon + 0.02, "intensity": 0.3, "risk": "low"}
    ]
    
    return {
        "center": {"lat": lat, "lon": lon},
        "zoom": zoom,
        "heatmap_points": heatmap_points,
        "total_points": len(heatmap_points),
        "risk_distribution": {
            "high": len([p for p in heatmap_points if p["risk"] == "high"]),
            "medium": len([p for p in heatmap_points if p["risk"] == "medium"]),
            "low": len([p for p in heatmap_points if p["risk"] == "low"])
        }
    } 