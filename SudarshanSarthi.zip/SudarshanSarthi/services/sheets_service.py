"""
Google Sheets Service
Handles reading and writing data to Google Sheets
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import pandas as pd

logger = logging.getLogger(__name__)

# Google Sheets API scopes
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

class SheetsService:
    """Service for interacting with Google Sheets"""
    
    def __init__(self, credentials_file: str = "credentials.json", token_file: str = "token.json"):
        self.credentials_file = credentials_file
        self.token_file = token_file
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Authenticate with Google Sheets API"""
        creds = None
        
        # Load existing token if available
        if os.path.exists(self.token_file):
            try:
                creds = Credentials.from_authorized_user_file(self.token_file, SCOPES)
                logger.info("Loaded existing credentials from token file")
            except Exception as e:
                logger.warning(f"Error loading existing credentials: {e}")
        
        # If no valid credentials available, let user log in
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                    logger.info("Refreshed expired credentials")
                except Exception as e:
                    logger.error(f"Error refreshing credentials: {e}")
                    creds = None
            
            if not creds:
                if not os.path.exists(self.credentials_file):
                    logger.error(f"Credentials file not found: {self.credentials_file}")
                    raise FileNotFoundError(f"Please download credentials.json from Google Cloud Console")
                
                try:
                    flow = InstalledAppFlow.from_client_secrets_file(self.credentials_file, SCOPES)
                    creds = flow.run_local_server(port=0)
                    logger.info("Generated new credentials through OAuth flow")
                except Exception as e:
                    logger.error(f"Error in OAuth flow: {e}")
                    raise
            
            # Save credentials for next run
            try:
                with open(self.token_file, 'w') as token:
                    token.write(creds.to_json())
                logger.info("Saved new credentials to token file")
            except Exception as e:
                logger.error(f"Error saving credentials: {e}")
        
        # Build the service
        try:
            self.service = build('sheets', 'v4', credentials=creds)
            logger.info("Successfully authenticated with Google Sheets API")
        except Exception as e:
            logger.error(f"Error building sheets service: {e}")
            raise
    
    def read_sheet(self, spreadsheet_id: str, range_name: str) -> List[List[Any]]:
        """
        Read data from a Google Sheet
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            range_name: The range to read (e.g., 'Sheet1!A1:D10')
        
        Returns:
            List of rows containing the data
        """
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id,
                range=range_name
            ).execute()
            
            values = result.get('values', [])
            logger.info(f"Successfully read {len(values)} rows from {range_name}")
            return values
            
        except HttpError as error:
            logger.error(f"Error reading sheet: {error}")
            raise
    
    def write_sheet(self, spreadsheet_id: str, range_name: str, values: List[List[Any]]) -> Dict[str, Any]:
        """
        Write data to a Google Sheet
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            range_name: The range to write to (e.g., 'Sheet1!A1')
            values: List of rows to write
        
        Returns:
            Response from the API
        """
        try:
            body = {
                'values': values
            }
            
            result = self.service.spreadsheets().values().update(
                spreadsheetId=spreadsheet_id,
                range=range_name,
                valueInputOption='RAW',
                body=body
            ).execute()
            
            logger.info(f"Successfully wrote {len(values)} rows to {range_name}")
            return result
            
        except HttpError as error:
            logger.error(f"Error writing to sheet: {error}")
            raise
    
    def append_sheet(self, spreadsheet_id: str, range_name: str, values: List[List[Any]]) -> Dict[str, Any]:
        """
        Append data to a Google Sheet
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            range_name: The range to append to (e.g., 'Sheet1!A:A')
            values: List of rows to append
        
        Returns:
            Response from the API
        """
        try:
            body = {
                'values': values
            }
            
            result = self.service.spreadsheets().values().append(
                spreadsheetId=spreadsheet_id,
                range=range_name,
                valueInputOption='RAW',
                insertDataOption='INSERT_ROWS',
                body=body
            ).execute()
            
            logger.info(f"Successfully appended {len(values)} rows to {range_name}")
            return result
            
        except HttpError as error:
            logger.error(f"Error appending to sheet: {error}")
            raise
    
    def get_sheet_info(self, spreadsheet_id: str) -> Dict[str, Any]:
        """
        Get information about a spreadsheet
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
        
        Returns:
            Dictionary containing spreadsheet information
        """
        try:
            result = self.service.spreadsheets().get(
                spreadsheetId=spreadsheet_id
            ).execute()
            
            logger.info(f"Retrieved info for spreadsheet: {result.get('properties', {}).get('title', 'Unknown')}")
            return result
            
        except HttpError as error:
            logger.error(f"Error getting sheet info: {error}")
            raise
    
    def create_sheet(self, title: str) -> str:
        """
        Create a new Google Sheet
        
        Args:
            title: The title of the new spreadsheet
        
        Returns:
            The ID of the created spreadsheet
        """
        try:
            spreadsheet = {
                'properties': {
                    'title': title
                },
                'sheets': [
                    {
                        'properties': {
                            'title': 'Sheet1'
                        }
                    }
                ]
            }
            
            result = self.service.spreadsheets().create(body=spreadsheet).execute()
            spreadsheet_id = result['spreadsheetId']
            
            logger.info(f"Created new spreadsheet: {title} (ID: {spreadsheet_id})")
            return spreadsheet_id
            
        except HttpError as error:
            logger.error(f"Error creating sheet: {error}")
            raise
    
    def read_health_data(self, spreadsheet_id: str, sheet_name: str = "HealthData") -> List[Dict[str, Any]]:
        """
        Read health data from a specific sheet format
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            sheet_name: The name of the sheet containing health data
        
        Returns:
            List of dictionaries containing health data
        """
        try:
            range_name = f"{sheet_name}!A:Z"  # Read all columns
            values = self.read_sheet(spreadsheet_id, range_name)
            
            if not values:
                logger.warning(f"No data found in {sheet_name}")
                return []
            
            # Assume first row contains headers
            headers = values[0]
            data = []
            
            for row in values[1:]:
                # Pad row to match headers length
                row_padded = row + [''] * (len(headers) - len(row))
                row_dict = dict(zip(headers, row_padded))
                data.append(row_dict)
            
            logger.info(f"Successfully read {len(data)} health data records")
            return data
            
        except Exception as e:
            logger.error(f"Error reading health data: {e}")
            raise
    
    def write_health_data(self, spreadsheet_id: str, data: List[Dict[str, Any]], sheet_name: str = "HealthData") -> Dict[str, Any]:
        """
        Write health data to a specific sheet format
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            data: List of dictionaries containing health data
            sheet_name: The name of the sheet to write to
        
        Returns:
            Response from the API
        """
        try:
            if not data:
                logger.warning("No data to write")
                return {}
            
            # Convert data to rows
            headers = list(data[0].keys())
            values = [headers]  # First row is headers
            
            for record in data:
                row = [str(record.get(header, '')) for header in headers]
                values.append(row)
            
            range_name = f"{sheet_name}!A1"
            result = self.write_sheet(spreadsheet_id, range_name, values)
            
            logger.info(f"Successfully wrote {len(data)} health data records")
            return result
            
        except Exception as e:
            logger.error(f"Error writing health data: {e}")
            raise
    
    def append_health_record(self, spreadsheet_id: str, record: Dict[str, Any], sheet_name: str = "HealthData") -> Dict[str, Any]:
        """
        Append a single health record to the sheet
        
        Args:
            spreadsheet_id: The ID of the spreadsheet
            record: Dictionary containing health data
            sheet_name: The name of the sheet to append to
        
        Returns:
            Response from the API
        """
        try:
            # Add timestamp if not present
            if 'timestamp' not in record:
                record['timestamp'] = datetime.now().isoformat()
            
            # Convert to row format
            values = [[str(value) for value in record.values()]]
            
            range_name = f"{sheet_name}!A:A"
            result = self.append_sheet(spreadsheet_id, range_name, values)
            
            logger.info(f"Successfully appended health record: {record.get('id', 'unknown')}")
            return result
            
        except Exception as e:
            logger.error(f"Error appending health record: {e}")
            raise

# Global instance for easy access
sheets_service = None

def get_sheets_service() -> SheetsService:
    """Get or create the global sheets service instance"""
    global sheets_service
    if sheets_service is None:
        sheets_service = SheetsService()
    return sheets_service 