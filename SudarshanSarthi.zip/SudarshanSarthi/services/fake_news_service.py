from typing import Optional

def classify_news(title: str, content: str, source: Optional[str] = None) -> dict:
    """Classify if health news is fake or misleading."""
    
    # Simple fake news detection (replace with real ML model)
    suspicious_keywords = [
        "miracle cure", "secret remedy", "government hiding", "conspiracy",
        "100% effective", "no side effects", "cures everything"
    ]
    
    text_lower = (title + " " + content).lower()
    suspicious_count = sum(1 for keyword in suspicious_keywords if keyword in text_lower)
    
    # Determine classification
    if suspicious_count > 2:
        classification = "likely_fake"
        confidence = 0.85
    elif suspicious_count > 0:
        classification = "suspicious"
        confidence = 0.65
    else:
        classification = "likely_real"
        confidence = 0.75
    
    return {
        "classification": classification,
        "confidence": confidence,
        "suspicious_keywords_found": suspicious_count,
        "analysis": {
            "title_length": len(title),
            "content_length": len(content),
            "source_credibility": "unknown" if not source else "verified"
        },
        "recommendations": [
            "Verify with official health sources",
            "Check multiple reliable sources",
            "Be skeptical of miracle claims"
        ] if classification != "likely_real" else [
            "Information appears credible",
            "Still verify with official sources"
        ]
    } 