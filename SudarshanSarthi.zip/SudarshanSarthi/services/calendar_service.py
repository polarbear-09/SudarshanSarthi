from typing import Optional, List
from datetime import datetime, timedelta

def get_preventive_calendar(week_start: Optional[str] = None) -> dict:
    """Get weekly preventive calendar with health tips."""
    
    if week_start:
        start_date = datetime.strptime(week_start, "%Y-%m-%d")
    else:
        start_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    calendar = []
    tips = [
        "Practice good hand hygiene",
        "Get adequate sleep (7-9 hours)",
        "Exercise regularly",
        "Eat a balanced diet",
        "Stay hydrated",
        "Avoid close contact with sick people",
        "Keep your living space clean"
    ]
    
    for i in range(7):
        date = start_date + timedelta(days=i)
        calendar.append({
            "date": date.strftime("%Y-%m-%d"),
            "day": date.strftime("%A"),
            "tip": tips[i % len(tips)],
            "reminder": f"Health check reminder for {date.strftime('%A')}",
            "completed": False
        })
    
    return {
        "week_start": start_date.strftime("%Y-%m-%d"),
        "week_end": (start_date + timedelta(days=6)).strftime("%Y-%m-%d"),
        "calendar": calendar,
        "total_tips": len(calendar)
    } 