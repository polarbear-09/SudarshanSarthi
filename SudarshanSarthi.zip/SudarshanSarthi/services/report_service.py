from typing import List, Optional
from datetime import datetime
import uuid

def create_report(report_data) -> dict:
    """
    Process and store user health reports.
    """
    report_id = str(uuid.uuid4())
    
    # Simulate report processing
    risk_assessment = "medium"
    if len(report_data.symptoms) > 3:
        risk_assessment = "high"
    elif len(report_data.symptoms) == 1:
        risk_assessment = "low"
    
    # Generate recommendations based on symptoms
    recommendations = []
    if "fever" in report_data.symptoms:
        recommendations.append("Monitor temperature regularly")
        recommendations.append("Stay hydrated")
    if "cough" in report_data.symptoms:
        recommendations.append("Practice good respiratory hygiene")
        recommendations.append("Consider wearing a mask")
    
    return {
        "report_id": report_id,
        "status": "submitted",
        "timestamp": datetime.now().isoformat(),
        "user_id": report_data.user_id,
        "symptoms": report_data.symptoms,
        "location": report_data.location,
        "severity": report_data.severity,
        "risk_assessment": risk_assessment,
        "recommendations": recommendations,
        "next_steps": [
            "Report has been logged",
            "Local health authorities will be notified if needed",
            "Monitor symptoms and update if conditions worsen"
        ],
        "contact_healthcare": risk_assessment == "high"
    } 