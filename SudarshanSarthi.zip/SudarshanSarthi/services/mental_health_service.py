from typing import Dict, List
import re

def analyze_mental_health(text: str, user_id: str) -> dict:
    """Analyze text tone and estimate mental health state."""
    
    # Simple sentiment analysis (replace with real NLP in production)
    text_lower = text.lower()
    
    # Positive indicators
    positive_words = ["happy", "good", "great", "excellent", "wonderful", "amazing", "love", "joy"]
    positive_count = sum(1 for word in positive_words if word in text_lower)
    
    # Negative indicators  
    negative_words = ["sad", "bad", "terrible", "awful", "hate", "angry", "depressed", "anxious", "stress"]
    negative_count = sum(1 for word in negative_words if word in text_lower)
    
    # Stress indicators
    stress_words = ["stress", "worried", "anxious", "tired", "exhausted", "overwhelmed"]
    stress_count = sum(1 for word in stress_words if word in text_lower)
    
    # Determine sentiment
    if positive_count > negative_count:
        sentiment = "positive"
        mental_state = "good"
    elif negative_count > positive_count:
        sentiment = "negative"
        mental_state = "concerning"
    else:
        sentiment = "neutral"
        mental_state = "stable"
    
    # Stress level
    if stress_count > 3:
        stress_level = "high"
    elif stress_count > 1:
        stress_level = "medium"
    else:
        stress_level = "low"
    
    return {
        "user_id": user_id,
        "text_analyzed": text[:100] + "..." if len(text) > 100 else text,
        "sentiment": sentiment,
        "mental_state": mental_state,
        "stress_level": stress_level,
        "confidence": 0.75,
        "recommendations": [
            "Practice deep breathing exercises",
            "Take regular breaks",
            "Connect with friends and family",
            "Consider talking to a mental health professional"
        ] if stress_level in ["medium", "high"] else [
            "Maintain your positive outlook",
            "Continue healthy habits",
            "Support others in your community"
        ]
    } 