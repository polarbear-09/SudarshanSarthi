from typing import Optional

def translate_text(text: str, target_language: str, source_language: str = "auto") -> dict:
    """Translate text to target language (simulated)."""
    
    # Simulated translations (replace with real translation API)
    translations = {
        "es": {
            "Hello": "Hola",
            "How are you feeling today?": "¿Cómo te sientes hoy?",
            "I have a headache": "Tengo dolor de cabeza",
            "Stay safe": "Mantente seguro"
        },
        "fr": {
            "Hello": "Bonjour", 
            "How are you feeling today?": "Comment vous sentez-vous aujourd'hui?",
            "I have a headache": "J'ai mal à la tête",
            "Stay safe": "Restez en sécurité"
        },
        "hi": {
            "Hello": "नमस्ते",
            "How are you feeling today?": "आज आप कैसा महसूस कर रहे हैं?",
            "I have a headache": "मुझे सिरदर्द है",
            "Stay safe": "सुरक्षित रहें"
        }
    }
    
    # Simple translation logic
    target_translations = translations.get(target_language, {})
    translated_text = target_translations.get(text, f"[{text}] - Translation not available")
    
    return {
        "original_text": text,
        "translated_text": translated_text,
        "source_language": source_language,
        "target_language": target_language,
        "confidence": 0.85 if text in target_translations else 0.0
    } 