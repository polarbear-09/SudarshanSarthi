from typing import Optional
from datetime import datetime

def get_local_alerts(lat: float, lon: float, radius_km: float = 10.0) -> dict:
    """Get local risk alerts and notifications."""
    # Simulated local alerts
    alerts = [
        {
            "id": "alert_001",
            "type": "outbreak",
            "severity": "high",
            "title": "COVID-19 Cases Detected",
            "message": "New cases reported in your area. Please take precautions.",
            "location": f"{lat},{lon}",
            "distance_km": 2.5,
            "timestamp": datetime.now().isoformat()
        },
        {
            "id": "alert_002", 
            "type": "weather",
            "severity": "medium",
            "title": "High Humidity Alert",
            "message": "High humidity levels may increase disease transmission risk.",
            "location": f"{lat},{lon}",
            "distance_km": 0.0,
            "timestamp": datetime.now().isoformat()
        }
    ]
    
    return {
        "location": f"{lat},{lon}",
        "radius_km": radius_km,
        "alerts": alerts,
        "total_alerts": len(alerts),
        "high_priority": len([a for a in alerts if a["severity"] == "high"])
    } 