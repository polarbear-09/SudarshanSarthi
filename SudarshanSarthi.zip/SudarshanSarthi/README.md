# SudarshanSarthi Health Platform API

A comprehensive FastAPI backend for the SudarshanSarthi AI-powered health companion platform, designed for outbreak monitoring and personal health management.

## 🚀 Features

### Core Health APIs
- **Weather Risk Analysis** - Disease risk based on weather/pollution data
- **Disease Prediction** - AI-powered disease prediction from symptoms and location
- **Mobility Risk Assessment** - Population density and mobility-based spread estimation
- **Health Logging** - Personal health tracking and symptom logging
- **Mental Health Analysis** - Tone analysis and mental state estimation

### Outbreak Monitoring
- **News Sentiment Analysis** - NLP analysis of health news
- **Heatmap Data** - Area-level outbreak risk visualization
- **Forecast Timeline** - Outbreak prediction and trend analysis
- **Local Notifications** - Real-time health alerts and warnings
- **Fake News Detection** - Health misinformation classification

### User Experience
- **Speech-to-Text** - Voice input for health logging
- **Translation Service** - Multi-language support
- **Cat Mood API** - Therapeutic cat images for stress relief
- **Story Mode** - Guided onboarding experience
- **Dashboard Widgets** - Customizable health dashboard data

### Prevention & Wellness
- **Preventive Calendar** - Weekly health tips and reminders
- **Community Reporting** - User-generated health reports
- **Health Recommendations** - Personalized prevention strategies

## 🛠️ Technology Stack

- **Framework**: FastAPI
- **Language**: Python 3.8+
- **Documentation**: OpenAPI/Swagger
- **CORS**: Enabled for frontend integration
- **Architecture**: Modular with separate routes and services

## 📁 Project Structure

```
SudarshanSarthi/
├── main.py                 # FastAPI application entry point
├── config.py              # Configuration and settings
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── routes/               # API route definitions
│   ├── weather_risk.py
│   ├── news_sentiment.py
│   ├── predict_disease.py
│   ├── mobility_risk.py
│   ├── report.py
│   ├── health_log.py
│   ├── notifications.py
│   ├── mental_health.py
│   ├── cat_mood.py
│   ├── heatmap.py
│   ├── speech_to_text.py
│   ├── forecast.py
│   ├── preventive_calendar.py
│   ├── fake_news.py
│   ├── dashboard_widgets.py
│   ├── translate.py
│   └── story_mode.py
└── services/             # Business logic and data processing
    ├── weather_service.py
    ├── news_service.py
    ├── disease_service.py
    ├── mobility_service.py
    ├── report_service.py
    ├── health_log_service.py
    ├── notification_service.py
    ├── mental_health_service.py
    ├── cat_service.py
    ├── heatmap_service.py
    ├── speech_service.py
    ├── forecast_service.py
    ├── calendar_service.py
    ├── fake_news_service.py
    ├── widget_service.py
    ├── translate_service.py
    └── story_service.py
```

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd SudarshanSarthi
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the development server**
   ```bash
   python main.py
   ```

4. **Access the API**
   - API Base URL: `http://localhost:8000`
   - Interactive Documentation: `http://localhost:8000/docs`
   - Alternative Documentation: `http://localhost:8000/redoc`

## 📚 API Documentation

### Health Check
```bash
GET /
```

### Weather Risk Analysis
```bash
GET /api/weather-risk?lat=28.6139&lon=77.2090
```

### Disease Prediction
```bash
GET /api/predict-disease?lat=28.6139&lon=77.2090&symptoms=fever,cough
```

### Health Logging
```bash
POST /api/health-log
{
  "user_id": "user123",
  "symptoms": ["fever", "headache"],
  "temperature": 38.5,
  "notes": "Feeling unwell since morning"
}
```

### Mental Health Analysis
```bash
POST /api/mental-health
{
  "text": "I'm feeling stressed and overwhelmed today",
  "user_id": "user123"
}
```

## 🔧 Configuration

Edit `config.py` to customize:
- Server host and port
- Debug mode
- Database connections (when implemented)
- API keys and external service configurations

## 🧪 Testing

Test individual endpoints using the interactive documentation at `/docs` or with tools like:
- curl
- Postman
- Insomnia

## 🚀 Production Deployment

1. **Environment Setup**
   ```bash
   export HOST=0.0.0.0
   export PORT=8000
   export DEBUG=false
   ```

2. **Run with Gunicorn**
   ```bash
   pip install gunicorn
   gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
   ```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the API documentation at `/docs`

---

**Built with ❤️ for better health monitoring and outbreak prevention** 