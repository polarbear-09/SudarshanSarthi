from fastapi import APIRouter, Depends, HTTPException, Header, Body, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
import gspread
from google.oauth2.service_account import Credentials
import pandas as pd
import json
import logging
from datetime import datetime, timedelta
import io
import csv
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sudarsansarthi.admin")

# Router for admin endpoints
router = APIRouter()

# --- Google Sheets Configuration ---

# Google Sheets setup
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive'
]

CREDENTIALS_FILE = "credentials.json"  # Update this path
SPREADSHEET_ID = "1YZ97nZYxNCIQikLCdXclBUQPMBE05Qw1U_jtTz72MGQ"  # From setup

class GoogleSheetsManager:
    def __init__(self):
        self.client = None
        self.spreadsheet = None
        
    def connect(self):
        """Connect to Google Sheets"""
        try:
            creds = Credentials.from_service_account_file(CREDENTIALS_FILE, scopes=SCOPES)
            self.client = gspread.authorize(creds)
            self.spreadsheet = self.client.open_by_key(SPREADSHEET_ID)
            logger.info("Google Sheets connection successful")
        except Exception as e:
            logger.error(f"Google Sheets connection failed: {e}")
            raise HTTPException(status_code=500, detail="Database connection failed")
    
    def get_worksheet(self, sheet_name: str):
        """Get worksheet by name"""
        try:
            return self.spreadsheet.worksheet(sheet_name)
        except gspread.WorksheetNotFound:
            # Create worksheet if it doesn't exist
            worksheet = self.spreadsheet.add_worksheet(title=sheet_name, rows=1000, cols=20)
            # Add headers based on sheet name
            if sheet_name == "OutbreakReports":
                worksheet.append_row(["Date", "Region", "Disease", "Cases", "Deaths", "Severity", "Notes"])
            elif sheet_name == "BroadcastLogs":
                worksheet.append_row(["Date", "Region", "Title", "Message"])
            elif sheet_name == "RiskOverrides":
                worksheet.append_row(["Date", "Region", "Disease", "Risk Level", "Valid Until"])
            return worksheet
    
    def append_row(self, sheet_name: str, row_data: List[Any]):
        """Append row to worksheet"""
        worksheet = self.get_worksheet(sheet_name)
        return worksheet.append_row(row_data)
    
    def get_all_records(self, sheet_name: str):
        """Get all records from worksheet"""
        worksheet = self.get_worksheet(sheet_name)
        records = worksheet.get_all_records()
        
        # Convert to proper format based on sheet name
        if sheet_name == "OutbreakReports":
            return [
                {
                    "date": record.get("Date", ""),
                    "region": record.get("Region", ""),
                    "disease": record.get("Disease", ""),
                    "cases": int(record.get("Cases", 0)),
                    "deaths": int(record.get("Deaths", 0)),
                    "severity": record.get("Severity", ""),
                    "notes": record.get("Notes", "")
                }
                for record in records
            ]
        elif sheet_name == "BroadcastLogs":
            return [
                {
                    "date": record.get("Date", ""),
                    "region": record.get("Region", ""),
                    "title": record.get("Title", ""),
                    "message": record.get("Message", "")
                }
                for record in records
            ]
        elif sheet_name == "RiskOverrides":
            return [
                {
                    "date": record.get("Date", ""),
                    "region": record.get("Region", ""),
                    "disease": record.get("Disease", ""),
                    "risk_level": record.get("Risk Level", ""),
                    "valid_until": record.get("Valid Until", "")
                }
                for record in records
            ]
        return records

# Global sheets manager
sheets_manager = GoogleSheetsManager()

# --- Pydantic Models ---

class AdminLogin(BaseModel):
    email: str = Field(..., description="Admin email")
    password: str = Field(..., description="Admin password")

class AdminLoginResponse(BaseModel):
    token: str = Field(..., description="Admin authentication token")
    expires_at: str = Field(..., description="Token expiration time")

class OutbreakReport(BaseModel):
    region: str = Field(..., description="Affected region")
    disease: str = Field(..., description="Disease name")
    cases: int = Field(..., ge=0, description="Number of cases")
    deaths: int = Field(..., ge=0, description="Number of deaths")
    date: str = Field(..., description="Report date (YYYY-MM-DD)")
    severity: str = Field(..., description="Severity level")
    notes: Optional[str] = Field(None, description="Additional notes")
    
    @validator('severity')
    def validate_severity(cls, v):
        if v not in ['low', 'medium', 'high', 'critical']:
            raise ValueError('Severity must be low, medium, high, or critical')
        return v

class BroadcastAlert(BaseModel):
    region: str = Field(..., description="Target region")
    title: str = Field(..., description="Alert title")
    message: str = Field(..., description="Alert message")

class RiskOverride(BaseModel):
    region: str = Field(..., description="Target region")
    disease: str = Field(..., description="Disease name")
    risk_level: str = Field(..., description="Risk level")
    valid_until: str = Field(..., description="Valid until date (YYYY-MM-DD)")
    
    @validator('risk_level')
    def validate_risk_level(cls, v):
        if v not in ['low', 'medium', 'high', 'critical']:
            raise ValueError('Risk level must be low, medium, high, or critical')
        return v

class AnalyticsSummary(BaseModel):
    total_reports: int
    regions_affected: List[str]
    most_affected_disease: str
    average_severity: str
    recent_trend: str

# --- Authentication Dependencies ---

async def verify_admin_token(authorization: str = Header(None)):
    """Verify admin authentication token"""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")
    
    token = authorization.replace("Bearer ", "")
    
    # Mock token validation
    if token != "mock-admin-token":
        raise HTTPException(status_code=401, detail="Invalid admin token")
    
    return {"admin_id": "admin_001", "email": "admin@example.com"}

# --- Admin Endpoints ---

@router.post("/login", response_model=AdminLoginResponse, tags=["Admin Auth"])
async def admin_login(login_data: AdminLogin = Body(...)):
    """Admin login endpoint"""
    
    # Mock authentication
    if login_data.email == "admin@example.com" and login_data.password == "admin123":
        expires_at = (datetime.now() + timedelta(hours=24)).isoformat()
        
        logger.info(f"Admin login successful: {login_data.email}")
        
        return AdminLoginResponse(
            token="mock-admin-token",
            expires_at=expires_at
        )
    else:
        logger.warning(f"Admin login failed: {login_data.email}")
        raise HTTPException(status_code=401, detail="Invalid credentials")

@router.post("/outbreak-report", tags=["Outbreak Reports"])
async def submit_outbreak_report(
    report: OutbreakReport = Body(...),
    admin: Dict = Depends(verify_admin_token)
):
    """Submit new outbreak report"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Prepare row data
        row_data = [
            report.date,
            report.region,
            report.disease,
            str(report.cases),
            str(report.deaths),
            report.severity,
            report.notes or ""
        ]
        
        # Append to Google Sheets
        result = sheets_manager.append_row("OutbreakReports", row_data)
        
        logger.info(f"Outbreak report submitted by {admin['email']}: {report.disease} in {report.region}")
        
        return {
            "status": "success",
            "message": "Outbreak report submitted successfully",
            "report_id": str(uuid.uuid4()),
            "details": report.dict()
        }
        
    except Exception as e:
        logger.error(f"Error submitting outbreak report: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to submit report: {str(e)}")

@router.get("/outbreak-reports", tags=["Outbreak Reports"])
async def get_outbreak_reports(admin: Dict = Depends(verify_admin_token)):
    """Fetch all outbreak reports"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Get all records
        reports = sheets_manager.get_all_records("OutbreakReports")
        
        # Sort by date (latest first)
        reports.sort(key=lambda x: x["date"], reverse=True)
        
        logger.info(f"Outbreak reports fetched by {admin['email']}: {len(reports)} reports")
        
        return {
            "status": "success",
            "total_reports": len(reports),
            "reports": reports
        }
        
    except Exception as e:
        logger.error(f"Error fetching outbreak reports: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch reports: {str(e)}")

@router.get("/export-csv", tags=["Export"])
async def export_csv(admin: Dict = Depends(verify_admin_token)):
    """Export outbreak reports to CSV"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Get all records
        reports = sheets_manager.get_all_records("OutbreakReports")
        
        # Create CSV content
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(["Date", "Region", "Disease", "Cases", "Deaths", "Severity", "Notes"])
        
        # Write data
        for report in reports:
            writer.writerow([
                report["date"],
                report["region"],
                report["disease"],
                report["cases"],
                report["deaths"],
                report["severity"],
                report["notes"]
            ])
        
        # Prepare response
        output.seek(0)
        csv_content = output.getvalue()
        
        logger.info(f"CSV export requested by {admin['email']}: {len(reports)} reports")
        
        return StreamingResponse(
            io.BytesIO(csv_content.encode()),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=outbreak_reports_{datetime.now().strftime('%Y%m%d')}.csv"}
        )
        
    except Exception as e:
        logger.error(f"Error exporting CSV: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to export CSV: {str(e)}")

@router.post("/broadcast", tags=["Broadcasting"])
async def broadcast_alert(
    alert: BroadcastAlert = Body(...),
    admin: Dict = Depends(verify_admin_token)
):
    """Broadcast alert to users"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Log broadcast
        broadcast_data = [
            datetime.now().strftime("%Y-%m-%d"),
            alert.region,
            alert.title,
            alert.message
        ]
        sheets_manager.append_row("BroadcastLogs", broadcast_data)
        
        # TODO: Integrate with WebSocket broadcast from realtime_ws.py
        # For now, we'll simulate the broadcast
        broadcast_message = {
            "id": str(uuid.uuid4()),
            "type": "admin_broadcast",
            "title": alert.title,
            "message": alert.message,
            "region": alert.region,
            "severity": "high",
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Alert broadcasted by {admin['email']}: {alert.title} to {alert.region}")
        
        return {
            "status": "success",
            "message": f"Alert broadcasted to {alert.region}",
            "broadcast_id": broadcast_message["id"],
            "details": broadcast_message
        }
        
    except Exception as e:
        logger.error(f"Error broadcasting alert: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to broadcast alert: {str(e)}")

@router.post("/override-risk", tags=["Risk Management"])
async def override_risk(
    override: RiskOverride = Body(...),
    admin: Dict = Depends(verify_admin_token)
):
    """Override risk prediction for a region"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Store risk override
        override_data = [
            datetime.now().strftime("%Y-%m-%d"),
            override.region,
            override.disease,
            override.risk_level,
            override.valid_until
        ]
        sheets_manager.append_row("RiskOverrides", override_data)
        
        logger.info(f"Risk override set by {admin['email']}: {override.disease} in {override.region}")
        
        return {
            "status": "success",
            "message": f"Risk override set for {override.disease} in {override.region}",
            "override_id": str(uuid.uuid4()),
            "details": override.dict()
        }
        
    except Exception as e:
        logger.error(f"Error setting risk override: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to set risk override: {str(e)}")

@router.get("/analytics-summary", response_model=AnalyticsSummary, tags=["Analytics"])
async def get_analytics_summary(admin: Dict = Depends(verify_admin_token)):
    """Get analytics summary for admin dashboard"""
    
    try:
        # Initialize sheets connection
        sheets_manager.connect()
        
        # Get all reports
        reports = sheets_manager.get_all_records("OutbreakReports")
        
        if not reports:
            return AnalyticsSummary(
                total_reports=0,
                regions_affected=[],
                most_affected_disease="None",
                average_severity="None",
                recent_trend="No data"
            )
        
        # Calculate analytics
        total_reports = len(reports)
        regions_affected = list(set(report["region"] for report in reports))
        
        # Most affected disease
        disease_counts = {}
        for report in reports:
            disease = report["disease"]
            disease_counts[disease] = disease_counts.get(disease, 0) + report["cases"]
        
        most_affected_disease = max(disease_counts.items(), key=lambda x: x[1])[0] if disease_counts else "None"
        
        # Average severity
        severity_scores = {"low": 1, "medium": 2, "high": 3, "critical": 4}
        severity_values = [severity_scores[report["severity"]] for report in reports if report["severity"] in severity_scores]
        avg_severity_score = sum(severity_values) / len(severity_values) if severity_values else 1
        
        # Map score back to severity
        if avg_severity_score <= 1.5:
            average_severity = "low"
        elif avg_severity_score <= 2.5:
            average_severity = "medium"
        elif avg_severity_score <= 3.5:
            average_severity = "high"
        else:
            average_severity = "critical"
        
        # Recent trend (last 7 days vs previous 7 days)
        recent_date = datetime.now() - timedelta(days=7)
        recent_reports = [r for r in reports if datetime.strptime(r["date"], "%Y-%m-%d") >= recent_date]
        previous_reports = [r for r in reports if datetime.strptime(r["date"], "%Y-%m-%d") < recent_date]
        
        if len(recent_reports) > len(previous_reports):
            recent_trend = "increasing"
        elif len(recent_reports) < len(previous_reports):
            recent_trend = "decreasing"
        else:
            recent_trend = "stable"
        
        logger.info(f"Analytics summary requested by {admin['email']}")
        
        return AnalyticsSummary(
            total_reports=total_reports,
            regions_affected=regions_affected,
            most_affected_disease=most_affected_disease,
            average_severity=average_severity,
            recent_trend=recent_trend
        )
        
    except Exception as e:
        logger.error(f"Error generating analytics summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate analytics: {str(e)}")

# Example usage:
# To use this module in your main FastAPI app:
# from admin_dashboard import router as admin_router
# app.include_router(admin_router, prefix="/admin") 