from fastapi import APIRouter, WebSocket, WebSocketDisconnect, BackgroundTasks, Body, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Set
import asyncio
import json
import logging
from datetime import datetime, timedelta
import uuid
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sudarsansarthi.realtime")

# Router for real-time endpoints
router = APIRouter()

# --- Pydantic Models ---

class AlertType(str, Enum):
    OUTBREAK = "outbreak"
    AIR_QUALITY = "air_quality"
    MENTAL_HEALTH = "mental_health"
    ADMIN_BROADCAST = "admin_broadcast"

class SymptomReport(BaseModel):
    user_id: str = Field(..., description="User ID")
    symptoms: List[str] = Field(..., description="List of symptoms")
    location: str = Field(..., description="Location")
    severity: str = Field(..., description="Severity level")
    timestamp: Optional[str] = Field(None, description="Timestamp")

class AdminBroadcast(BaseModel):
    title: str = Field(..., description="Alert title")
    message: str = Field(..., description="Alert message")
    region: str = Field(..., description="Target region")
    alert_type: AlertType = Field(AlertType.ADMIN_BROADCAST, description="Alert type")

class AlertMessage(BaseModel):
    id: str = Field(..., description="Alert ID")
    type: AlertType = Field(..., description="Alert type")
    title: str = Field(..., description="Alert title")
    message: str = Field(..., description="Alert message")
    region: str = Field(..., description="Affected region")
    severity: str = Field(..., description="Severity level")
    timestamp: str = Field(..., description="Timestamp")

# --- WebSocket Connection Manager ---

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.user_regions: Dict[str, str] = {}
        self.connection_tasks: Dict[str, asyncio.Task] = {}
        
    async def connect(self, websocket: WebSocket, user_id: str, region: str):
        """Connect a new WebSocket client"""
        await websocket.accept()
        self.active_connections[user_id] = websocket
        self.user_regions[user_id] = region
        logger.info(f"Client {user_id} connected from {region}")
        
    def disconnect(self, user_id: str):
        """Disconnect a WebSocket client"""
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        if user_id in self.user_regions:
            del self.user_regions[user_id]
        if user_id in self.connection_tasks:
            self.connection_tasks[user_id].cancel()
            del self.connection_tasks[user_id]
        logger.info(f"Client {user_id} disconnected")
        
    async def send_personal_message(self, message: dict, user_id: str):
        """Send message to specific user"""
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error sending message to {user_id}: {e}")
                self.disconnect(user_id)
                
    async def broadcast_to_region(self, message: dict, region: str):
        """Broadcast message to all users in a specific region"""
        disconnected_users = []
        
        for user_id, user_region in self.user_regions.items():
            if user_region.lower() == region.lower():
                try:
                    await self.active_connections[user_id].send_text(json.dumps(message))
                except Exception as e:
                    logger.error(f"Error broadcasting to {user_id}: {e}")
                    disconnected_users.append(user_id)
                    
        # Clean up disconnected users
        for user_id in disconnected_users:
            self.disconnect(user_id)
            
    async def broadcast_to_all(self, message: dict):
        """Broadcast message to all connected users"""
        disconnected_users = []
        
        for user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error broadcasting to {user_id}: {e}")
                disconnected_users.append(user_id)
                
        # Clean up disconnected users
        for user_id in disconnected_users:
            self.disconnect(user_id)

# Global connection manager
manager = ConnectionManager()

# --- Background Task Engine ---

class BackgroundTaskEngine:
    def __init__(self):
        self.tasks: Dict[str, asyncio.Task] = {}
        self.running = False
        
    async def start(self):
        """Start the background task engine"""
        self.running = True
        
        # Start polling tasks
        self.tasks["weather_polling"] = asyncio.create_task(self.poll_weather_api())
        self.tasks["health_news_polling"] = asyncio.create_task(self.poll_health_news())
        self.tasks["alert_simulation"] = asyncio.create_task(self.simulate_alerts())
        
        logger.info("Background task engine started")
        
    async def stop(self):
        """Stop the background task engine"""
        self.running = False
        
        # Cancel all tasks
        for task_name, task in self.tasks.items():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
                
        logger.info("Background task engine stopped")
        
    async def poll_weather_api(self):
        """Poll weather API every 10 seconds"""
        while self.running:
            try:
                # Simulate weather API call
                weather_data = {
                    "temperature": 32 + (datetime.now().second % 10),
                    "humidity": 65 + (datetime.now().second % 15),
                    "air_quality": "moderate"
                }
                
                # Check for significant changes
                if weather_data["temperature"] > 35:
                    alert = AlertMessage(
                        id=str(uuid.uuid4()),
                        type=AlertType.AIR_QUALITY,
                        title="High Temperature Alert",
                        message=f"Temperature has reached {weather_data['temperature']}°C",
                        region="Delhi",
                        severity="moderate",
                        timestamp=datetime.now().isoformat()
                    )
                    await manager.broadcast_to_region(alert.dict(), "Delhi")
                    
                await asyncio.sleep(10)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in weather polling: {e}")
                await asyncio.sleep(10)
                
    async def poll_health_news(self):
        """Poll health news API every 15 seconds"""
        while self.running:
            try:
                # Simulate health news API call
                news_data = {
                    "headlines": [
                        "New COVID variant detected",
                        "Dengue cases on the rise",
                        "Mental health awareness campaign"
                    ]
                }
                
                # Check for outbreak-related news
                if "Dengue" in str(news_data):
                    alert = AlertMessage(
                        id=str(uuid.uuid4()),
                        type=AlertType.OUTBREAK,
                        title="Dengue Outbreak Alert",
                        message="Dengue cases are increasing in your area",
                        region="Mumbai",
                        severity="high",
                        timestamp=datetime.now().isoformat()
                    )
                    await manager.broadcast_to_region(alert.dict(), "Mumbai")
                    
                await asyncio.sleep(15)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in health news polling: {e}")
                await asyncio.sleep(15)
                
    async def simulate_alerts(self):
        """Simulate random alerts every 30 seconds"""
        alert_templates = [
            {
                "type": AlertType.OUTBREAK,
                "title": "Dengue Risk High",
                "message": "Dengue risk is high in your area. Take precautions.",
                "region": "Delhi",
                "severity": "high"
            },
            {
                "type": AlertType.AIR_QUALITY,
                "title": "Poor Air Quality",
                "message": "Air quality has deteriorated. Avoid outdoor activities.",
                "region": "Mumbai",
                "severity": "moderate"
            },
            {
                "type": AlertType.MENTAL_HEALTH,
                "title": "Mental Health Check",
                "message": "Consider taking a mental health break today.",
                "region": "Bangalore",
                "severity": "low"
            }
        ]
        
        while self.running:
            try:
                # Randomly select an alert template
                template = random.choice(alert_templates)
                
                alert = AlertMessage(
                    id=str(uuid.uuid4()),
                    type=template["type"],
                    title=template["title"],
                    message=template["message"],
                    region=template["region"],
                    severity=template["severity"],
                    timestamp=datetime.now().isoformat()
                )
                
                await manager.broadcast_to_region(alert.dict(), template["region"])
                logger.info(f"Simulated alert sent: {alert.title}")
                
                await asyncio.sleep(30)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in alert simulation: {e}")
                await asyncio.sleep(30)

# Global background task engine
task_engine = BackgroundTaskEngine()

# --- WebSocket Endpoint ---

@router.websocket("/ws/alerts")
async def websocket_alerts(websocket: WebSocket):
    """WebSocket endpoint for real-time alerts"""
    user_id = None
    region = None
    
    try:
        # Accept the connection
        await websocket.accept()
        
        # Mock authentication (in real app, validate token)
        auth_message = await websocket.receive_text()
        auth_data = json.loads(auth_message)
        
        user_id = auth_data.get("user_id", f"user_{uuid.uuid4().hex[:8]}")
        region = auth_data.get("region", "Delhi")
        token = auth_data.get("token", "mock_token")
        
        # Mock token validation
        if token != "mock_token":
            await websocket.close(code=4001, reason="Invalid token")
            return
            
        # Connect to manager
        await manager.connect(websocket, user_id, region)
        
        # Send welcome message
        welcome_message = {
            "type": "connection",
            "message": f"Connected to SudarshanSarthi alerts for {region}",
            "user_id": user_id,
            "timestamp": datetime.now().isoformat()
        }
        await websocket.send_text(json.dumps(welcome_message))
        
        # Keep connection alive and handle incoming messages
        while True:
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                # Handle different message types
                if message.get("type") == "ping":
                    await websocket.send_text(json.dumps({"type": "pong", "timestamp": datetime.now().isoformat()}))
                    
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"WebSocket error for {user_id}: {e}")
                break
                
    except Exception as e:
        logger.error(f"WebSocket connection error: {e}")
    finally:
        if user_id:
            manager.disconnect(user_id)

# --- API Endpoints ---

@router.post("/report-symptom", tags=["Symptoms"])
async def report_symptom(
    report: SymptomReport = Body(...),
    background_tasks: BackgroundTasks = None
):
    """Report symptoms and trigger background analysis"""
    
    # Add timestamp if not provided
    if not report.timestamp:
        report.timestamp = datetime.now().isoformat()
    
    # Store report (in-memory for now)
    report_id = str(uuid.uuid4())
    
    # Trigger background analysis
    background_tasks.add_task(analyze_symptom_spike, report)
    
    logger.info(f"Symptom report received: {report.dict()}")
    
    return {
        "status": "success",
        "report_id": report_id,
        "message": "Symptom report submitted for analysis"
    }

@router.post("/admin/broadcast-alert", tags=["Admin"])
async def broadcast_admin_alert(alert: AdminBroadcast = Body(...)):
    """Admin endpoint to broadcast alerts"""
    
    alert_message = AlertMessage(
        id=str(uuid.uuid4()),
        type=alert.alert_type,
        title=alert.title,
        message=alert.message,
        region=alert.region,
        severity="high",
        timestamp=datetime.now().isoformat()
    )
    
    # Broadcast to region
    await manager.broadcast_to_region(alert_message.dict(), alert.region)
    
    logger.info(f"Admin alert broadcasted: {alert.title} to {alert.region}")
    
    return {
        "status": "success",
        "alert_id": alert_message.id,
        "message": f"Alert broadcasted to {alert.region}"
    }

@router.get("/connections/status", tags=["Admin"])
async def get_connection_status():
    """Get status of all connections"""
    return {
        "active_connections": len(manager.active_connections),
        "connected_users": list(manager.active_connections.keys()),
        "regions": list(set(manager.user_regions.values())),
        "timestamp": datetime.now().isoformat()
    }

# --- Background Analysis Functions ---

async def analyze_symptom_spike(report: SymptomReport):
    """Background task to analyze symptom reports for spikes"""
    await asyncio.sleep(2)  # Simulate analysis time
    
    # Simple spike detection logic
    symptom_count = len(report.symptoms)
    severity_score = {"low": 1, "moderate": 2, "high": 3}.get(report.severity, 1)
    
    # Check for potential spike
    if symptom_count >= 3 and severity_score >= 2:
        alert = AlertMessage(
            id=str(uuid.uuid4()),
            type=AlertType.OUTBREAK,
            title="Symptom Spike Detected",
            message=f"Multiple severe symptoms reported in {report.location}",
            region=report.location,
            severity="moderate",
            timestamp=datetime.now().isoformat()
        )
        
        await manager.broadcast_to_region(alert.dict(), report.location)
        logger.info(f"Symptom spike alert sent for {report.location}")

# --- Utility Functions ---

async def broadcast_alert(message: dict):
    """Utility function to broadcast alerts"""
    await manager.broadcast_to_all(message)

# --- Startup and Shutdown Events ---

@router.on_event("startup")
async def startup_event():
    """Start background tasks on startup"""
    await task_engine.start()

@router.on_event("shutdown")
async def shutdown_event():
    """Stop background tasks on shutdown"""
    await task_engine.stop()

# Example usage:
# To use this module in your main FastAPI app:
# from realtime_ws import router as ws_router
# app.include_router(ws_router)

# Test WebSocket connection:
# ws://localhost:8000/ws/alerts
# Send: {"user_id": "test123", "region": "Delhi", "token": "mock_token"} 