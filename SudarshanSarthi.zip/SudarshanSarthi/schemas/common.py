"""
Common Schemas
Shared Pydantic models for API responses and common data structures
"""

from pydantic import BaseModel, Field
from typing import Optional, Any, Dict, List
from datetime import datetime
from enum import Enum

class StatusEnum(str, Enum):
    """API response status enumeration"""
    SUCCESS = "success"
    ERROR = "error"
    WARNING = "warning"

class APIResponse(BaseModel):
    """Standard API response model"""
    status: StatusEnum = StatusEnum.SUCCESS
    message: Optional[str] = None
    data: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    version: str = "1.0.0"

class ErrorResponse(BaseModel):
    """Standard error response model"""
    status: StatusEnum = StatusEnum.ERROR
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    version: str = "1.0.0"

class PaginationParams(BaseModel):
    """Pagination parameters"""
    page: int = Field(default=1, ge=1, description="Page number")
    size: int = Field(default=20, ge=1, le=100, description="Page size")
    total: Optional[int] = Field(default=None, description="Total number of items")

class PaginatedResponse(BaseModel):
    """Paginated response model"""
    status: StatusEnum = StatusEnum.SUCCESS
    data: List[Any]
    pagination: PaginationParams
    timestamp: datetime = Field(default_factory=datetime.now)

class SearchParams(BaseModel):
    """Search parameters"""
    query: Optional[str] = Field(default=None, description="Search query")
    filters: Optional[Dict[str, Any]] = Field(default=None, description="Search filters")
    sort_by: Optional[str] = Field(default=None, description="Sort field")
    sort_order: Optional[str] = Field(default="asc", description="Sort order (asc/desc)")

class HealthStatus(BaseModel):
    """Health check response model"""
    status: str = "healthy"
    service: str
    timestamp: datetime = Field(default_factory=datetime.now)
    version: str = "1.0.0"
    uptime: Optional[float] = None
    dependencies: Optional[Dict[str, str]] = None

class WebSocketMessage(BaseModel):
    """WebSocket message model"""
    type: str
    data: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    user_id: Optional[str] = None

class Notification(BaseModel):
    """Notification model"""
    id: Optional[str] = None
    user_id: str
    title: str
    message: str
    type: str = "info"  # info, warning, error, success
    read: bool = False
    created_at: datetime = Field(default_factory=datetime.now)
    read_at: Optional[datetime] = None

class Location(BaseModel):
    """Location model"""
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    postal_code: Optional[str] = None

class ContactInfo(BaseModel):
    """Contact information model"""
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None

class AuditLog(BaseModel):
    """Audit log entry model"""
    id: Optional[str] = None
    user_id: Optional[str] = None
    action: str
    resource: str
    resource_id: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)

class FeatureFlag(BaseModel):
    """Feature flag model"""
    name: str
    enabled: bool = True
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)

class SystemMetrics(BaseModel):
    """System metrics model"""
    cpu_usage: Optional[float] = None
    memory_usage: Optional[float] = None
    disk_usage: Optional[float] = None
    active_connections: Optional[int] = None
    requests_per_minute: Optional[float] = None
    error_rate: Optional[float] = None
    timestamp: datetime = Field(default_factory=datetime.now) 