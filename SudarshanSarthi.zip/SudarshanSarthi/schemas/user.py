"""
User Schemas
Pydantic models for user-related data structures
"""

from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class UserRole(str, Enum):
    """User role enumeration"""
    USER = "user"
    ADMIN = "admin"
    HEALTHCARE_PROVIDER = "healthcare_provider"
    RESEARCHER = "researcher"

class UserStatus(str, Enum):
    """User status enumeration"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING = "pending"

class User(BaseModel):
    """User model"""
    user_id: Optional[str] = Field(default=None, description="User identifier")
    username: str = Field(..., min_length=3, max_length=20, description="Username")
    email: EmailStr = Field(..., description="Email address")
    full_name: str = Field(..., min_length=2, max_length=100, description="Full name")
    role: UserRole = Field(default=UserRole.USER, description="User role")
    status: UserStatus = Field(default=UserStatus.ACTIVE, description="User status")
    location: Optional[str] = Field(default=None, max_length=200, description="User location")
    phone: Optional[str] = Field(default=None, max_length=20, description="Phone number")
    date_of_birth: Optional[datetime] = Field(default=None, description="Date of birth")
    gender: Optional[str] = Field(default=None, max_length=20, description="Gender")
    emergency_contact: Optional[str] = Field(default=None, max_length=100, description="Emergency contact name")
    emergency_phone: Optional[str] = Field(default=None, max_length=20, description="Emergency contact phone")
    blood_type: Optional[str] = Field(default=None, max_length=5, description="Blood type")
    allergies: List[str] = Field(default_factory=list, description="List of allergies")
    medical_conditions: List[str] = Field(default_factory=list, description="List of medical conditions")
    created_at: datetime = Field(default_factory=datetime.now, description="Account creation date")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update date")
    last_login: Optional[datetime] = Field(default=None, description="Last login date")
    email_verified: bool = Field(default=False, description="Email verification status")
    phone_verified: bool = Field(default=False, description="Phone verification status")

class UserCreate(BaseModel):
    """User creation model"""
    username: str = Field(..., min_length=3, max_length=20, description="Username")
    email: EmailStr = Field(..., description="Email address")
    full_name: str = Field(..., min_length=2, max_length=100, description="Full name")
    password: str = Field(..., min_length=8, description="Password")
    role: UserRole = Field(default=UserRole.USER, description="User role")
    location: Optional[str] = Field(default=None, max_length=200, description="User location")
    phone: Optional[str] = Field(default=None, max_length=20, description="Phone number")
    date_of_birth: Optional[datetime] = Field(default=None, description="Date of birth")
    gender: Optional[str] = Field(default=None, max_length=20, description="Gender")
    emergency_contact: Optional[str] = Field(default=None, max_length=100, description="Emergency contact name")
    emergency_phone: Optional[str] = Field(default=None, max_length=20, description="Emergency contact phone")
    blood_type: Optional[str] = Field(default=None, max_length=5, description="Blood type")
    allergies: List[str] = Field(default_factory=list, description="List of allergies")
    medical_conditions: List[str] = Field(default_factory=list, description="List of medical conditions")

class UserUpdate(BaseModel):
    """User update model"""
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=100, description="Full name")
    location: Optional[str] = Field(default=None, max_length=200, description="User location")
    phone: Optional[str] = Field(default=None, max_length=20, description="Phone number")
    date_of_birth: Optional[datetime] = Field(default=None, description="Date of birth")
    gender: Optional[str] = Field(default=None, max_length=20, description="Gender")
    emergency_contact: Optional[str] = Field(default=None, max_length=100, description="Emergency contact name")
    emergency_phone: Optional[str] = Field(default=None, max_length=20, description="Emergency contact phone")
    blood_type: Optional[str] = Field(default=None, max_length=5, description="Blood type")
    allergies: Optional[List[str]] = Field(default=None, description="List of allergies")
    medical_conditions: Optional[List[str]] = Field(default=None, description="List of medical conditions")
    status: Optional[UserStatus] = Field(default=None, description="User status")

class UserLogin(BaseModel):
    """User login model"""
    username: str = Field(..., description="Username or email")
    password: str = Field(..., description="Password")
    remember_me: bool = Field(default=False, description="Remember login session")

class UserProfile(BaseModel):
    """User profile model (public information)"""
    user_id: str = Field(..., description="User identifier")
    username: str = Field(..., description="Username")
    full_name: str = Field(..., description="Full name")
    role: UserRole = Field(..., description="User role")
    location: Optional[str] = Field(default=None, description="User location")
    created_at: datetime = Field(..., description="Account creation date")
    last_login: Optional[datetime] = Field(default=None, description="Last login date")

class UserSession(BaseModel):
    """User session model"""
    session_id: Optional[str] = Field(default=None, description="Session identifier")
    user_id: str = Field(..., description="User identifier")
    token: str = Field(..., description="Session token")
    expires_at: datetime = Field(..., description="Session expiration date")
    ip_address: Optional[str] = Field(default=None, description="IP address")
    user_agent: Optional[str] = Field(default=None, description="User agent string")
    is_active: bool = Field(default=True, description="Session status")
    created_at: datetime = Field(default_factory=datetime.now, description="Session creation date")

class PasswordReset(BaseModel):
    """Password reset model"""
    email: EmailStr = Field(..., description="Email address")
    token: Optional[str] = Field(default=None, description="Reset token")
    new_password: Optional[str] = Field(default=None, min_length=8, description="New password")
    expires_at: Optional[datetime] = Field(default=None, description="Token expiration date")
    used: bool = Field(default=False, description="Whether token has been used")
    created_at: datetime = Field(default_factory=datetime.now, description="Token creation date")

class EmailVerification(BaseModel):
    """Email verification model"""
    user_id: str = Field(..., description="User identifier")
    email: EmailStr = Field(..., description="Email address")
    token: str = Field(..., description="Verification token")
    expires_at: datetime = Field(..., description="Token expiration date")
    verified: bool = Field(default=False, description="Verification status")
    verified_at: Optional[datetime] = Field(default=None, description="Verification date")
    created_at: datetime = Field(default_factory=datetime.now, description="Token creation date")

class UserPreferences(BaseModel):
    """User preferences model"""
    user_id: str = Field(..., description="User identifier")
    language: str = Field(default="en", description="Preferred language")
    timezone: str = Field(default="UTC", description="Timezone")
    theme: str = Field(default="light", description="UI theme preference")
    notifications_enabled: bool = Field(default=True, description="Enable notifications")
    email_notifications: bool = Field(default=True, description="Email notifications")
    sms_notifications: bool = Field(default=False, description="SMS notifications")
    push_notifications: bool = Field(default=True, description="Push notifications")
    health_reminders: bool = Field(default=True, description="Health reminders")
    outbreak_alerts: bool = Field(default=True, description="Outbreak alerts")
    privacy_level: str = Field(default="standard", description="Privacy level")
    data_sharing: bool = Field(default=False, description="Data sharing consent")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation date")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update date")

class UserActivity(BaseModel):
    """User activity log model"""
    activity_id: Optional[str] = Field(default=None, description="Activity identifier")
    user_id: str = Field(..., description="User identifier")
    activity_type: str = Field(..., description="Type of activity")
    description: str = Field(..., max_length=500, description="Activity description")
    ip_address: Optional[str] = Field(default=None, description="IP address")
    user_agent: Optional[str] = Field(default=None, description="User agent string")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    timestamp: datetime = Field(default_factory=datetime.now, description="Activity timestamp")

class UserDevice(BaseModel):
    """User device model"""
    device_id: Optional[str] = Field(default=None, description="Device identifier")
    user_id: str = Field(..., description="User identifier")
    device_name: str = Field(..., max_length=100, description="Device name")
    device_type: str = Field(..., description="Device type")
    os_version: Optional[str] = Field(default=None, description="Operating system version")
    app_version: Optional[str] = Field(default=None, description="App version")
    push_token: Optional[str] = Field(default=None, description="Push notification token")
    is_active: bool = Field(default=True, description="Device status")
    last_used: datetime = Field(default_factory=datetime.now, description="Last usage date")
    created_at: datetime = Field(default_factory=datetime.now, description="Registration date")

class UserHealthProfile(BaseModel):
    """User health profile model"""
    user_id: str = Field(..., description="User identifier")
    height_cm: Optional[float] = Field(default=None, ge=50, le=300, description="Height in centimeters")
    weight_kg: Optional[float] = Field(default=None, ge=10, le=500, description="Weight in kilograms")
    bmi: Optional[float] = Field(default=None, ge=10, le=100, description="Body Mass Index")
    activity_level: Optional[str] = Field(default=None, description="Activity level")
    smoking_status: Optional[str] = Field(default=None, description="Smoking status")
    alcohol_consumption: Optional[str] = Field(default=None, description="Alcohol consumption")
    diet_type: Optional[str] = Field(default=None, description="Diet type")
    exercise_frequency: Optional[str] = Field(default=None, description="Exercise frequency")
    sleep_hours: Optional[float] = Field(default=None, ge=0, le=24, description="Average sleep hours")
    stress_level: Optional[str] = Field(default=None, description="Stress level")
    family_history: List[str] = Field(default_factory=list, description="Family medical history")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation date")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update date")

    @validator('bmi')
    def calculate_bmi(cls, v, values):
        if 'height_cm' in values and 'weight_kg' in values:
            height = values['height_cm']
            weight = values['weight_kg']
            if height and weight and height > 0:
                return round(weight / ((height / 100) ** 2), 2)
        return v 