"""
Health Schemas
Pydantic models for health-related data structures
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class RiskLevel(str, Enum):
    """Health risk level enumeration"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SymptomSeverity(str, Enum):
    """Symptom severity enumeration"""
    MILD = "mild"
    MODERATE = "moderate"
    SEVERE = "severe"

class VitalSigns(BaseModel):
    """Vital signs model"""
    temperature: Optional[float] = Field(default=None, ge=30, le=45, description="Body temperature in Celsius")
    heart_rate: Optional[int] = Field(default=None, ge=30, le=220, description="Heart rate in BPM")
    blood_pressure_systolic: Optional[int] = Field(default=None, ge=70, le=200, description="Systolic blood pressure")
    blood_pressure_diastolic: Optional[int] = Field(default=None, ge=40, le=130, description="Diastolic blood pressure")
    respiratory_rate: Optional[int] = Field(default=None, ge=8, le=40, description="Respiratory rate per minute")
    oxygen_saturation: Optional[float] = Field(default=None, ge=70, le=100, description="Blood oxygen saturation percentage")
    timestamp: datetime = Field(default_factory=datetime.now)

    @validator('blood_pressure_systolic', 'blood_pressure_diastolic')
    def validate_blood_pressure(cls, v, values):
        if 'blood_pressure_systolic' in values and 'blood_pressure_diastolic' in values:
            systolic = values['blood_pressure_systolic']
            diastolic = values['blood_pressure_diastolic']
            if systolic and diastolic and systolic <= diastolic:
                raise ValueError('Systolic pressure must be higher than diastolic pressure')
        return v

class SymptomLog(BaseModel):
    """Symptom log entry model"""
    symptom: str = Field(..., description="Symptom name")
    severity: SymptomSeverity = Field(default=SymptomSeverity.MILD, description="Symptom severity")
    duration_hours: Optional[int] = Field(default=None, ge=0, description="Duration in hours")
    notes: Optional[str] = Field(default=None, max_length=500, description="Additional notes")
    timestamp: datetime = Field(default_factory=datetime.now)

class HealthData(BaseModel):
    """Health data model"""
    user_id: str = Field(..., description="User identifier")
    symptoms: List[SymptomLog] = Field(default_factory=list, description="List of symptoms")
    vital_signs: Optional[VitalSigns] = Field(default=None, description="Vital signs measurements")
    location: Optional[str] = Field(default=None, max_length=200, description="User location")
    notes: Optional[str] = Field(default=None, max_length=1000, description="Additional health notes")
    timestamp: datetime = Field(default_factory=datetime.now)
    risk_level: Optional[RiskLevel] = Field(default=None, description="Assessed risk level")

class HealthPrediction(BaseModel):
    """Health prediction model"""
    user_id: str = Field(..., description="User identifier")
    risk_level: RiskLevel = Field(..., description="Predicted risk level")
    confidence: float = Field(..., ge=0, le=1, description="Prediction confidence score")
    predicted_diseases: List[str] = Field(default_factory=list, description="List of predicted diseases")
    recommendations: List[str] = Field(default_factory=list, description="Health recommendations")
    symptoms_analyzed: List[str] = Field(default_factory=list, description="Symptoms used for prediction")
    model_version: Optional[str] = Field(default=None, description="ML model version used")
    timestamp: datetime = Field(default_factory=datetime.now)

class DiseaseOutbreak(BaseModel):
    """Disease outbreak model"""
    outbreak_id: Optional[str] = Field(default=None, description="Outbreak identifier")
    disease_name: str = Field(..., description="Name of the disease")
    location: str = Field(..., description="Outbreak location")
    case_count: int = Field(..., ge=0, description="Number of cases")
    severity: RiskLevel = Field(..., description="Outbreak severity")
    start_date: datetime = Field(..., description="Outbreak start date")
    end_date: Optional[datetime] = Field(default=None, description="Outbreak end date")
    status: str = Field(default="active", description="Outbreak status")
    description: Optional[str] = Field(default=None, max_length=1000, description="Outbreak description")
    source: Optional[str] = Field(default=None, description="Data source")
    timestamp: datetime = Field(default_factory=datetime.now)

class HealthAlert(BaseModel):
    """Health alert model"""
    alert_id: Optional[str] = Field(default=None, description="Alert identifier")
    user_id: str = Field(..., description="User identifier")
    alert_type: str = Field(..., description="Type of health alert")
    severity: RiskLevel = Field(..., description="Alert severity")
    title: str = Field(..., max_length=200, description="Alert title")
    message: str = Field(..., max_length=1000, description="Alert message")
    actionable: bool = Field(default=True, description="Whether action is required")
    dismissed: bool = Field(default=False, description="Whether alert was dismissed")
    created_at: datetime = Field(default_factory=datetime.now)
    dismissed_at: Optional[datetime] = Field(default=None, description="When alert was dismissed")

class HealthReport(BaseModel):
    """Health report model"""
    report_id: Optional[str] = Field(default=None, description="Report identifier")
    user_id: str = Field(..., description="User identifier")
    report_type: str = Field(..., description="Type of health report")
    period_start: datetime = Field(..., description="Report period start")
    period_end: datetime = Field(..., description="Report period end")
    summary: str = Field(..., max_length=2000, description="Report summary")
    details: Dict[str, Any] = Field(default_factory=dict, description="Detailed report data")
    recommendations: List[str] = Field(default_factory=list, description="Health recommendations")
    risk_assessment: RiskLevel = Field(..., description="Overall risk assessment")
    generated_at: datetime = Field(default_factory=datetime.now)

class MedicationLog(BaseModel):
    """Medication log entry model"""
    medication_id: Optional[str] = Field(default=None, description="Medication identifier")
    user_id: str = Field(..., description="User identifier")
    medication_name: str = Field(..., max_length=200, description="Medication name")
    dosage: str = Field(..., max_length=100, description="Dosage information")
    frequency: str = Field(..., max_length=100, description="Frequency of administration")
    start_date: datetime = Field(..., description="Start date")
    end_date: Optional[datetime] = Field(default=None, description="End date")
    prescribed_by: Optional[str] = Field(default=None, max_length=200, description="Prescribing doctor")
    notes: Optional[str] = Field(default=None, max_length=500, description="Additional notes")
    active: bool = Field(default=True, description="Whether medication is currently active")
    timestamp: datetime = Field(default_factory=datetime.now)

class VaccinationRecord(BaseModel):
    """Vaccination record model"""
    vaccination_id: Optional[str] = Field(default=None, description="Vaccination identifier")
    user_id: str = Field(..., description="User identifier")
    vaccine_name: str = Field(..., max_length=200, description="Vaccine name")
    dose_number: int = Field(..., ge=1, description="Dose number")
    total_doses: int = Field(..., ge=1, description="Total required doses")
    vaccination_date: datetime = Field(..., description="Date of vaccination")
    next_dose_date: Optional[datetime] = Field(default=None, description="Next dose date")
    administered_by: Optional[str] = Field(default=None, max_length=200, description="Administering healthcare provider")
    batch_number: Optional[str] = Field(default=None, max_length=100, description="Vaccine batch number")
    side_effects: List[str] = Field(default_factory=list, description="Reported side effects")
    timestamp: datetime = Field(default_factory=datetime.now)

class HealthGoal(BaseModel):
    """Health goal model"""
    goal_id: Optional[str] = Field(default=None, description="Goal identifier")
    user_id: str = Field(..., description="User identifier")
    goal_type: str = Field(..., description="Type of health goal")
    title: str = Field(..., max_length=200, description="Goal title")
    description: str = Field(..., max_length=1000, description="Goal description")
    target_value: Optional[float] = Field(default=None, description="Target value")
    current_value: Optional[float] = Field(default=None, description="Current value")
    unit: Optional[str] = Field(default=None, max_length=50, description="Unit of measurement")
    start_date: datetime = Field(..., description="Goal start date")
    target_date: Optional[datetime] = Field(default=None, description="Target completion date")
    completed_date: Optional[datetime] = Field(default=None, description="Actual completion date")
    status: str = Field(default="active", description="Goal status")
    progress_percentage: Optional[float] = Field(default=None, ge=0, le=100, description="Progress percentage")
    created_at: datetime = Field(default_factory=datetime.now) 