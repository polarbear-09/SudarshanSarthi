"""
Alert Schemas
Pydantic models for alert-related data structures
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class AlertType(str, Enum):
    """Alert type enumeration"""
    OUTBREAK = "outbreak"
    HEALTH = "health"
    EMERGENCY = "emergency"
    INFO = "info"
    WEATHER = "weather"
    SYSTEM = "system"

class AlertSeverity(str, Enum):
    """Alert severity enumeration"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertStatus(str, Enum):
    """Alert status enumeration"""
    ACTIVE = "active"
    RESOLVED = "resolved"
    EXPIRED = "expired"
    DISMISSED = "dismissed"

class Alert(BaseModel):
    """Alert model"""
    alert_id: Optional[str] = Field(default=None, description="Alert identifier")
    alert_type: AlertType = Field(..., description="Type of alert")
    severity: AlertSeverity = Field(..., description="Alert severity")
    status: AlertStatus = Field(default=AlertStatus.ACTIVE, description="Alert status")
    title: str = Field(..., max_length=200, description="Alert title")
    message: str = Field(..., max_length=1000, description="Alert message")
    location: Optional[str] = Field(default=None, max_length=200, description="Alert location")
    affected_area: Optional[str] = Field(default=None, max_length=200, description="Affected area")
    disease_name: Optional[str] = Field(default=None, max_length=100, description="Disease name")
    case_count: Optional[int] = Field(default=None, ge=0, description="Number of cases")
    source: Optional[str] = Field(default=None, max_length=200, description="Alert source")
    coordinates: Optional[Dict[str, float]] = Field(default=None, description="Geographic coordinates")
    radius_km: Optional[float] = Field(default=None, ge=0, description="Alert radius in kilometers")
    created_by: Optional[str] = Field(default=None, description="User who created the alert")
    verified: bool = Field(default=False, description="Alert verification status")
    verified_by: Optional[str] = Field(default=None, description="User who verified the alert")
    verified_at: Optional[datetime] = Field(default=None, description="Verification timestamp")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update timestamp")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")
    resolved_at: Optional[datetime] = Field(default=None, description="Resolution timestamp")
    dismissed_at: Optional[datetime] = Field(default=None, description="Dismissal timestamp")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

class AlertCreate(BaseModel):
    """Alert creation model"""
    alert_type: AlertType = Field(..., description="Type of alert")
    severity: AlertSeverity = Field(..., description="Alert severity")
    title: str = Field(..., max_length=200, description="Alert title")
    message: str = Field(..., max_length=1000, description="Alert message")
    location: Optional[str] = Field(default=None, max_length=200, description="Alert location")
    affected_area: Optional[str] = Field(default=None, max_length=200, description="Affected area")
    disease_name: Optional[str] = Field(default=None, max_length=100, description="Disease name")
    case_count: Optional[int] = Field(default=None, ge=0, description="Number of cases")
    source: Optional[str] = Field(default=None, max_length=200, description="Alert source")
    coordinates: Optional[Dict[str, float]] = Field(default=None, description="Geographic coordinates")
    radius_km: Optional[float] = Field(default=None, ge=0, description="Alert radius in kilometers")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")

class AlertUpdate(BaseModel):
    """Alert update model"""
    severity: Optional[AlertSeverity] = Field(default=None, description="Alert severity")
    status: Optional[AlertStatus] = Field(default=None, description="Alert status")
    title: Optional[str] = Field(default=None, max_length=200, description="Alert title")
    message: Optional[str] = Field(default=None, max_length=1000, description="Alert message")
    location: Optional[str] = Field(default=None, max_length=200, description="Alert location")
    affected_area: Optional[str] = Field(default=None, max_length=200, description="Affected area")
    disease_name: Optional[str] = Field(default=None, max_length=100, description="Disease name")
    case_count: Optional[int] = Field(default=None, ge=0, description="Number of cases")
    source: Optional[str] = Field(default=None, max_length=200, description="Alert source")
    coordinates: Optional[Dict[str, float]] = Field(default=None, description="Geographic coordinates")
    radius_km: Optional[float] = Field(default=None, ge=0, description="Alert radius in kilometers")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")

class AlertResponse(BaseModel):
    """Alert response model"""
    alert_id: str = Field(..., description="Alert identifier")
    status: str = Field(..., description="Response status")
    message: str = Field(..., description="Response message")
    timestamp: datetime = Field(default_factory=datetime.now, description="Response timestamp")

class AlertNotification(BaseModel):
    """Alert notification model"""
    notification_id: Optional[str] = Field(default=None, description="Notification identifier")
    alert_id: str = Field(..., description="Alert identifier")
    user_id: str = Field(..., description="User identifier")
    notification_type: str = Field(..., description="Notification type")
    title: str = Field(..., max_length=200, description="Notification title")
    message: str = Field(..., max_length=1000, description="Notification message")
    sent: bool = Field(default=False, description="Whether notification was sent")
    sent_at: Optional[datetime] = Field(default=None, description="Sent timestamp")
    delivered: bool = Field(default=False, description="Whether notification was delivered")
    delivered_at: Optional[datetime] = Field(default=None, description="Delivery timestamp")
    read: bool = Field(default=False, description="Whether notification was read")
    read_at: Optional[datetime] = Field(default=None, description="Read timestamp")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")

class AlertSubscription(BaseModel):
    """Alert subscription model"""
    subscription_id: Optional[str] = Field(default=None, description="Subscription identifier")
    user_id: str = Field(..., description="User identifier")
    alert_types: List[AlertType] = Field(default_factory=list, description="Subscribed alert types")
    severity_levels: List[AlertSeverity] = Field(default_factory=list, description="Subscribed severity levels")
    locations: List[str] = Field(default_factory=list, description="Subscribed locations")
    radius_km: Optional[float] = Field(default=None, ge=0, description="Notification radius in kilometers")
    email_enabled: bool = Field(default=True, description="Email notifications enabled")
    sms_enabled: bool = Field(default=False, description="SMS notifications enabled")
    push_enabled: bool = Field(default=True, description="Push notifications enabled")
    active: bool = Field(default=True, description="Subscription status")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update timestamp")

class AlertTemplate(BaseModel):
    """Alert template model"""
    template_id: Optional[str] = Field(default=None, description="Template identifier")
    name: str = Field(..., max_length=100, description="Template name")
    description: Optional[str] = Field(default=None, max_length=500, description="Template description")
    alert_type: AlertType = Field(..., description="Alert type")
    severity: AlertSeverity = Field(..., description="Default severity")
    title_template: str = Field(..., max_length=200, description="Title template")
    message_template: str = Field(..., max_length=1000, description="Message template")
    variables: List[str] = Field(default_factory=list, description="Template variables")
    is_active: bool = Field(default=True, description="Template status")
    created_by: Optional[str] = Field(default=None, description="Template creator")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update timestamp")

class AlertAnalytics(BaseModel):
    """Alert analytics model"""
    period_start: datetime = Field(..., description="Analytics period start")
    period_end: datetime = Field(..., description="Analytics period end")
    total_alerts: int = Field(..., ge=0, description="Total number of alerts")
    active_alerts: int = Field(..., ge=0, description="Number of active alerts")
    resolved_alerts: int = Field(..., ge=0, description="Number of resolved alerts")
    expired_alerts: int = Field(..., ge=0, description="Number of expired alerts")
    dismissed_alerts: int = Field(..., ge=0, description="Number of dismissed alerts")
    alerts_by_type: Dict[str, int] = Field(default_factory=dict, description="Alerts grouped by type")
    alerts_by_severity: Dict[str, int] = Field(default_factory=dict, description="Alerts grouped by severity")
    alerts_by_location: Dict[str, int] = Field(default_factory=dict, description="Alerts grouped by location")
    average_response_time: Optional[float] = Field(default=None, ge=0, description="Average response time in minutes")
    verification_rate: Optional[float] = Field(default=None, ge=0, le=100, description="Alert verification rate percentage")
    generated_at: datetime = Field(default_factory=datetime.now, description="Analytics generation timestamp")

class AlertFilter(BaseModel):
    """Alert filter model"""
    alert_types: Optional[List[AlertType]] = Field(default=None, description="Filter by alert types")
    severity_levels: Optional[List[AlertSeverity]] = Field(default=None, description="Filter by severity levels")
    statuses: Optional[List[AlertStatus]] = Field(default=None, description="Filter by statuses")
    locations: Optional[List[str]] = Field(default=None, description="Filter by locations")
    date_from: Optional[datetime] = Field(default=None, description="Filter from date")
    date_to: Optional[datetime] = Field(default=None, description="Filter to date")
    verified_only: Optional[bool] = Field(default=None, description="Show only verified alerts")
    created_by: Optional[str] = Field(default=None, description="Filter by creator")
    search_query: Optional[str] = Field(default=None, description="Search in title and message")

    @validator('date_to')
    def validate_date_range(cls, v, values):
        if 'date_from' in values and v and values['date_from']:
            if v < values['date_from']:
                raise ValueError('date_to must be after date_from')
        return v 